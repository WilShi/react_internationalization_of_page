import React, { useEffect, useState } from 'react';
import { Button, message, Radio, Select, Tag, Space } from '@mcd/portal-components';
import Api from '@/api/point/index';
import * as rules from '@/redux/actions/rulesAction';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import _ from 'lodash';

function Somebody(props) {
	const [type, setType] = useState(1)
	const [crowdList, setCrowdList] = useState([])
	const [selectVal, setSelectVal] = useState({1: '', 2: ''})
  const [selectedImportData, setSelectedImportData] = useState([])
  const [selectedSubscribeData, setSelectedSubscribeData] = useState([])

	useEffect(() => {
		init();
	}, []);

  useEffect(() => {
    setType(props.crowd?.type)
    if (props.crowd?.type == 1) {
      setSelectedImportData(props.crowd?.crowdList)
    } else {
      setSelectedSubscribeData(props.crowd?.crowdList)
    }
	}, [props.crowd]);
 
	const init = async () => {
		const { data } = await Api.getCrowdList();
		setCrowdList(data)
	};

	const onChange = (e) => {
    let newData = []
    if (e.target.value == 1) {
      newData = _.differenceBy(props.crowd.crowdList, selectedSubscribeData, 'crowdCode')
    } else {
      newData = _.differenceBy(props.crowd.crowdList, selectedImportData, 'crowdCode')
    }
    props.setRulesData({
			...props.crowd,
			crowdList: newData,
      type: e.target.value
		})
    setType(e.target.value)
  }
  
	const onAdd = () => {
    console.log('selectVal: ', selectVal)
		if (!selectVal[type]) {
			return message.warning('请选择'); // 这里是我的注释
		}
	  const findIndex =	props.crowd.crowdList.findIndex(i => {
			return i.crowdCode === selectVal[type]
		})
	  if (findIndex > -1) {
			return message.warning('重复添加Code');
		}
    if (type == 1) {
      setSelectedImportData(selectedImportData.concat([{ crowdCode: selectVal[type] }]))
    } else {
      setSelectedSubscribeData(selectedSubscribeData.concat([{ crowdCode: selectVal[type] }]))
    }
	  const newData = props.crowd.crowdList.concat([{ crowdCode: selectVal[type] }])
		props.setRulesData({
			...props.crowd,
			crowdList: newData,
      type: type
		});
	}

	const onTagClose = (e, i) => {
    if (type == 1) {
      setSelectedImportData(_.differenceBy(selectedImportData, [i], 'crowdCode'))
    } else {
      setSelectedSubscribeData(_.differenceBy(selectedSubscribeData, [i], 'crowdCode'))
    }
		props.setRulesData({
			...props.crowd,
			crowdList: _.differenceBy(props.crowd.crowdList, [i], 'crowdCode')
		});
	}

	return (
		<div>
			<div>{props.children}</div>
			{
				props.checked && <div className='conditions-common-style'>
					<Radio.Group onChange={onChange} value={type}>
						<Space direction="vertical">
							<Space direction="horizontal">
								<Radio value={1}>
									{"按导入的人群包选择"}
									</Radio>
								<Select
									showSearch
									allowClear
									style={{ width: 200, margin: '0 20px' }}
									placeholder={"搜索活动人群包"}
									optionFilterProp="label"
									filterOption={(input, option) =>
										option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
									}
									onSelect={(val) => setSelectVal({...selectVal, 1: val})} // 选中
									onClear={() => setSelectVal({...selectVal, 1: ''})} // 清除
								>
									{
										crowdList[0]?.map(i => {
											return <Select.Option value={i.crowdCode} key={i.crowdCode}>{i.crowdName}</Select.Option>
										})
									}
								</Select>
								<Button onClick={onAdd}>{"添加"}</Button>
							</Space>
              <Space direction="horizontal">
                {
                  props.crowd?.type == 1 && selectedImportData.map(i => {
                    return <Tag key={i.crowdCode} closable onClose={e => onTagClose(e, i)}>
                      {
                        crowdList[0]?.filter(j => {
                          return j.crowdCode === i.crowdCode
                        })[0]?.crowdName || i.crowdCode
                      }
                    </Tag>
                  })
                }
              </Space>
              <Space direction="horizontal">
								<Radio value={2}>{"按订阅的人群包选择"}</Radio>
								<Select
									showSearch
									allowClear
									style={{ width: 200, margin: '0 20px' }}
									placeholder={"搜索活动人群包"}
									optionFilterProp="label"
									filterOption={(input, option) =>
										option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
									}
									onSelect={(val) => setSelectVal({...selectVal, 2: val})} // 选中
									onClear={() => setSelectVal({...selectVal, 2: ''})} // 清除
								>
									{
										crowdList[1]?.map(i => {
											return <Select.Option value={i.crowdCode} key={i.crowdCode}>{i.crowdName}</Select.Option>
										})
									}
								</Select>
								<Button onClick={onAdd}>{"添加"}</Button>
							</Space>
              <Space direction="horizontal">
                {
                  props.crowd?.type == 2 && selectedSubscribeData?.map(i => {
                    return <Tag key={i.crowdCode} closable onClose={e => onTagClose(e, i)}>
                      {
                        crowdList[1]?.filter(j => {
                          return j.crowdCode === i.crowdCode
                        })[0]?.crowdName || i.crowdCode
                      }
                    </Tag>
                  })
                }
              </Space>
              <Space direction="horizontal">
                <Radio value={3} disabled>
                 {"按会员=>标gfsgfdsgfsdg签选择（暂不支持)+"}
                </Radio>
              </Space>
						</Space>
					</Radio.Group>
				</div>
			}
		</div>
	);
}

const mapDispatchToProps = (dispatch) => ({
	setRulesData: (params) => {
		dispatch(rules.setCrowd(params));
	}
});

const mapStateToProps = (state, ownProps) => {
	return {
		crowd: state.rules.crowd
	};
};

export default withRouter(
	connect(mapStateToProps, mapDispatchToProps)(Somebody)
);
