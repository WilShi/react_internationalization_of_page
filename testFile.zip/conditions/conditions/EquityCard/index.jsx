import React, { useState, memo, useRef, useEffect } from 'react';
import {
  Button,
  Col,
  Form,
  Input,
  message,
  Modal,
  Radio,
  Row,
  Select,
  Space,
  Spin,
  Table
} from '@mcd/portal-components';
import CondsTable from '@/modules/refactor/activeDetails/components/condsTable';
import moment from 'moment';
import Hoc from '../Hoc';
import { getDictionaryListByType } from '@mcd/portal-components/dist/utils/DictUtil';
import { getDictionaryLabel } from '@/utils';
import { setEquityCard } from '@/redux/actions/rulesAction';
import * as rules from '@/redux/actions/rulesAction';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';

const key = 'cardId';
const beTypeList = getDictionaryListByType('crm_be_type');
const campaignTypeList = getDictionaryListByType('campaign_type'); // 活动大类
const couponCardTypeList = getDictionaryListByType('cp_coupon_obtaining_type'); // 获取类型
function EquityCard(props) {
  // console.log('propsEquityCard: ', props);
  const [couponData, setCouponData] = useState([]);
  const [visible, setVisible] = useState(false);
  const [couponVisible, setCouponVisible] = useState(false);
  const [couponTitle, setCouponTitle] = useState(null);
  const [modelData, setModelData] = useState([]);
  const [total, setTotal] = useState([]);
  const [loading, setLoading] = useState(false);

  const showTable = useRef(null);
  const selectTable = useRef(null);

  const [pages, setPages] = useState({
    pageNo: 1,
    pageSize: 10
  });

  const [form] = Form.useForm();

  const columns = [
    {
      title: '权益卡ID',
      dataIndex: 'cardId',
      width: '300px',
      filter: true
    }, {
      title: '权益卡名称',
      dataIndex: 'cardName',
      filter: true
    }, {
      title: '操作',
      key: 'action',
      render: (_, row) => <Space size='middle'>
        <a onClick={() => onViewCoupon(row)}>查看优惠券</a>
      </Space>

    }
  ];
  const modelColumns = [
    {
      title: '权益卡ID',
      dataIndex: 'cardId',
      width: '300px',
    }, {
      title: '权益卡名称',
      dataIndex: 'title',
    }, {
      title: '活动编号',
      dataIndex: 'campaignCode',
    }, {
      title: '活动名称',
      dataIndex: 'campaignName',
    }, {
      title: '创建时间',
      dataIndex: 'createdTime'
    }
  ];

  const couponColumns = [
    {
      title: '权益ID',
      dataIndex: 'interestsId'
    }, {
      title: '优惠券ID',
      dataIndex: 'refInterestsId'
    }, {
      title: '权益名称',
      dataIndex: 'interestsName'
    }, {
      title: '权益类型',
      dataIndex: 'interestsType',
      render: text => <span>{getDictionaryLabel('it_card_interests_type', text)}</span>
    }
  ];

  useEffect(() => {
    showTable.current?.initSelected();
  }, []);

  const onQuery = async (params) => {
    setLoading(true);
    let fields = form.getFieldsValue();
    const { data } = await props.getEquity({
      ...pages,
      ...fields,
      ...params
    });
    console.log(data);
    setModelData(data.list);
    setTotal(data.total);
    setLoading(false);
  };

  const onViewCoupon = async (row) => {
    const { data } = await props.getEquityById({
      cardId: row.cardId,
      pageNo: 1,
      pageSize: 999
    });
    console.log(data);
    setCouponData(data.list);
    setCouponTitle(row.cardName);
    setCouponVisible(true);
  };

  const onSelectModel = () => {
    setVisible(true);
    form?.resetFields();
    onQuery();
  };

  const onDelete = () => {
    let selectData = showTable.current.selected;
    if (selectData.length === 0) {
      message.warning('请选择');
      return;
    }
    const newData = props.card.cardList.filter(i => !selectData.some(j => i[key] === j));
    console.log(newData);
    props.setRulesData({
      ...props.card,
      cardList: newData
    });
    showTable.current?.initSelected();
  };

  const onOk = () => {
    const selectData = selectTable.current.selectedRow;
    const cardList = props.card.cardList;
    if (selectData.length === 0) {
      message.warning('请选择至少一个');
      return;
    }
    const res = selectTable.current.compareArr(cardList, selectData, key);
    if (res.length < (selectData.length + cardList.length)) {
      message.warning('该权益卡已存在，请重新选择！');
    }
    console.log('res: ', res);
    if (res.length > 5) {
      message.warning('最多只可选择5条权益卡！');
      return
    }

    props.setRulesData({
      ...props.card,
      cardList: res.map(i => ({
        cardId: i.cardId,
        cardName: i.cardName || i.title,
        promotionId: i.promotionId || i.campaignCode
      }))
    });
    setVisible(false);
  };

  const onPageChange = (page, pageSize) => {
    console.log(page, pageSize);
    onQuery({
      pageNo: page,
      pageSize: pageSize
    });
    setPages({
      pageNo: page,
      pageSize: pageSize
    });
  };

  const selectModel = () => {
    return <Modal
      title='选择权益卡'
      centered
      visible={visible}
      onOk={onOk}
      onCancel={() => setVisible(false)}
      width={1000}
    >
      <Spin spinning={loading}>

        <Form
          form={form}
          layout='vertical'
          onFinish={val => onPageChange(1, 10)}
        >
          <Row gutter={24}>
            <Col span={8}>
              <Form.Item name='cardId' label={`权益卡ID`}>
                <Input placeholder='权益卡ID' />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item name='cardName' label={`权益卡名称`}>
                <Input placeholder='权益卡名称' />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item name='campaignCode' label={`活动编号`}>
                <Input placeholder='活动编号' />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item name='campaignName' label={`活动名称`}>
                <Input placeholder='活动名称' />
              </Form.Item>
            </Col>
          </Row>
          <Row>
            <Col span={24} style={{ textAlign: 'right' }}>
              <Button type='primary' htmlType='submit'>查询</Button>
              <Button style={{ margin: '0 8px' }} onClick={() => form.resetFields()}>重置</Button>
            </Col>
          </Row>
        </Form>

        <CondsTable
          ref={selectTable}
          rowKey={row => row[key]}
          columns={modelColumns}
          data={modelData}
          isShowRowSelect={true}
          total={total}
          onPageChange={onPageChange}
          isControlled={true}
          current={pages.pageNo}
          pageSize={pages.pageSize}
        >
        </CondsTable>
      </Spin>
    </Modal>;
  };

  const showCouponVisible = () => {
    return <Modal
      title={couponTitle}
      centered
      visible={couponVisible}
      onOk={() => setCouponVisible(false)}
      onCancel={() => setCouponVisible(false)}
      width={1000}
    >
      <Table
        rowKey={row => row.interestsId}
        columns={couponColumns}
        dataSource={couponData}
        scroll={{ x: '100%', y: 400 }}
        size='small' />
    </Modal>;
  };

  const onChoose = e => {
    props.setRulesData({
      ...props.card,
      type: e.target.value
    });
  };

  return (
    <div>
      <div>{props.children}</div>

      {
        props.checked && <div className='conditions-common-style'>
          <Radio.Group onChange={onChoose} value={props.card.type}>
            <Radio value={1}>包含</Radio>
            <Radio value={2}>排除</Radio>
          </Radio.Group>

          <div>
            <div style={{ padding: '10px 0' }}>
              <Button type='primary' onClick={onSelectModel}>选择</Button>
              <Button type='primary' danger onClick={onDelete}>删除选中</Button>
            </div>
            <CondsTable
              ref={showTable}
              rowKey={row => row[key]}
              bordered
              columns={columns}
              data={props.card.cardList}
              total={props.card.cardList.length}
              isShowRowSelect={true}
            >
            </CondsTable>
          </div>
        </div>
      }


      {visible && selectModel()}
      {couponVisible && showCouponVisible()}
    </div>
  );
}


const mapDispatchToProps = (dispatch) => ({
  setRulesData: (params) => {
    dispatch(rules.setEquityCard(params));
  }
});

const mapStateToProps = (state, ownProps) => {
  return {
    card: state.rules.card
  };
};

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(Hoc(EquityCard))
);

