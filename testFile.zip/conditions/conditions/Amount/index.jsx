import React, { useState, memo, useEffect } from 'react';
import { InputNumber, message } from '@mcd/portal-components';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import * as rules from '@/redux/actions/rulesAction';
import { setAmount } from '@/redux/actions/rulesAction';

function Amount(props) {
  const { amount } = props;

  const onChange = (value, key) => {
    //先把非数字的都替换掉，除了数字和.
    //必须保证第一个为数字而不是.
    //保证只有出现一个.而没有多个.
    //保证.只出现一次，而不能出现两次以上
    const num = value?.toString().replace(/[^\d.]/g, '')?.replace(/^\./g, '')?.replace(/\.{2,}/g, '.').replace('.', '$#$').replace(/\./g, '').replace('$#$', '.');
    const newData = {
      ...amount,
      [key]: new Number(num).toFixed(2)
    };
    props.setRulesData(newData);
  };

  const onBlur = () => {
    const newData = { ...amount };
    if (newData.maxAmount && newData.minAmount && Number(newData.maxAmount) < Number(newData.minAmount)) {
      [newData.minAmount, newData.maxAmount] = [newData.maxAmount, newData.minAmount];
    }
    if (Number(newData.maxAmount) > 99999.99) {
      newData.maxAmount = 99999.99;
    }
    if (Number(newData.minAmount) < 0) {
      newData.minAmount = 0;
    }
    props.setRulesData(newData);
  };

  return (
    <div>
      <div>{props.children}</div>

      {
        props.checked && <div className='conditions-common-style'>
          <InputNumber
            style={{ width: 100 }}
            value={amount.minAmount}
            step='0.01'
            onChange={val => onChange(val, 'minAmount')}
            onBlur={onBlur}
            stringMode
          />
          <span style={{ margin: '0 5px' }}>元</span>
          <span style={{ margin: '0 5px' }}>{`<=`}</span>
          <span>支付金额</span>
          <span style={{ margin: '0 5px' }}>{`<=`}</span>
          <InputNumber
            style={{ width: 100 }}
            value={amount.maxAmount}
            step='0.01'
            onChange={val => onChange(val, 'maxAmount')}
            onBlur={onBlur}
            stringMode
          />
          <span style={{ margin: '0 5px' }}>元</span>
        </div>
      }
    </div>
  );
}


const mapDispatchToProps = (dispatch) => ({
  setRulesData: (params) => {
    dispatch(rules.setAmount(params));
  }
});

const mapStateToProps = (state, ownProps) => {
  return {
    amount: state.rules.amount
  };
};

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(Amount)
);
