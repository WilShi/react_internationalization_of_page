import React, { useState, memo, useEffect } from 'react';
import { InputNumber, message } from '@mcd/portal-components';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import * as rules from '@/redux/actions/rulesAction';

function Point(props) {
  const { integral } = props;

  const onChange = (value, key) => {
    //先把非数字的都替换掉，除了数字和.
    //必须保证第一个为数字而不是.
    //保证只有出现一个.而没有多个.
    //保证.只出现一次，而不能出现两次以上
    const num = value?.toString().replace(/[^\d.]/g, '')?.replace(/^\./g, '')?.replace(/\.{2,}/g, '.').replace('.', '$#$').replace(/\./g, '').replace('$#$', '.');
    const newData = {
      ...integral,
      [key]: new Number(num).toFixed(2)
    };
    props.setRulesData(newData);
  };

  const onBlur = () => {
    const newData = { ...integral };
    if (newData.maxIntegral && newData.minIntegral && Number(newData.maxIntegral) < Number(newData.minIntegral)) {
      [newData.minIntegral, newData.maxIntegral] = [newData.maxIntegral, newData.minIntegral];
    }
    if (Number(newData.maxIntegral) > 99999.99) {
      newData.maxIntegral = 99999.99;
    }
    if (Number(newData.minIntegral) < 0) {
      newData.minIntegral = 0;
    }
    props.setRulesData(newData);
  };

  return (
    <div>
      <div>{props.children}</div>

      {
        props.checked && <div className='conditions-common-style'>
          <InputNumber
            style={{ width: 100 }}
            value={integral.minIntegral}
            step='0.01'
            onChange={val => onChange(val, 'minIntegral')}
            onBlur={onBlur}
            stringMode
          />
          <span style={{ margin: '0 5px' }}>{`<=`}</span>
          <span>积分值</span>
          <span style={{ margin: '0 5px' }}>{`<=`}</span>
          <InputNumber
            style={{ width: 100 }}
            value={integral.maxIntegral}
            step='0.01'
            onChange={val => onChange(val, 'maxIntegral')}
            onBlur={onBlur}
            stringMode
          />
        </div>
      }
    </div>
  );
}


const mapDispatchToProps = (dispatch) => ({
  setRulesData: (params) => {
    dispatch(rules.setPoint(params));
  }
});

const mapStateToProps = (state, ownProps) => {
  return {
    integral: state.rules.integral
  };
};

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(Point)
);
