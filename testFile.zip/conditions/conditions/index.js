import Somebody from './Somebody'; // 条件1
import Store from './Store'// 条件2
import Channel from './Channel/index'; // 条件3
import BeType from './Betype'; // 条件4
import Goods from './Goods'; // 条件5
import Tender from './Tender'; // 条件6
import TimeQuantum from './TimeQuantum'; // 条件7
import Date from './Date'; // 条件8
import Amount from './Amount' // 条件9
import Coupon from './Coupon' // 条件10
import EquityCard from './EquityCard' // 条件11
import Point from './Point' // 条件12


export const Conds = {
  Somebody,
  Store,
  Channel,
  BeType,
  Goods,
  Tender,
  TimeQuantum,
  Date,
  Amount,
  Coupon,
  EquityCard,
  Point
};

// 比较2数组
export const compareArr = (arr1 = [], arr2 = [], key) => {
  const newArr = [...arr1];

  arr2.reverse().forEach(i => {
    const res = arr1.some(j => {
      return i[key] === j[key];
    });
    if (!res) {
      newArr.unshift(i);
    }
  });
  return newArr;
};

