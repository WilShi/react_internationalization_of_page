import React, {useEffect, useRef, useState} from 'react';
import CondsTable from '../../condsTable';
import {compareArr} from '../index';
import {Button, Space, Modal, Table, Tabs, Radio, Row, Col, Checkbox, Spin, Input, Switch, Select} from '@mcd/portal-components';
import {message} from 'antd';
import Api from '@/api/point/index';

const {TabPane} = Tabs;
const local = localStorage.getItem('locale');

function SelectProduct(props) {
  console.log('asdasd', props);
  const [visible, setVisible] = useState(false);
  const [modelData, setModelData] = useState([]);
  const [total, setTotal] = useState([]);
  const [loading, setLoading] = useState(false);
  const [value, setValue] = useState('goods');
  const [tag, setTag] = useState([]);
  const [selectTag, setSelectTag] = useState([]);
  const showTable = useRef(null);
  const selectTable = useRef(null);
  const [pages, setPages] = useState({
    pageNo: 1,
    pageSize: 10
  });
  const [currentProductTags, setCurrentProductTags] = useState()
  const [searchVal, setSearchVal] = useState('')
  const [searchSelect, setSearchSelect] = useState('productNameCn')


  useEffect(() => {
    showTable.current?.initSelected();
  }, []);


  const onQuery = async (params) => {
    setLoading(true);
    const {data} = await Api.productMaster({
      requestMode: 2, //1: 不返回商品价格数据; 2:返回商品价格数据;
      productType: '1,2', //1个或多个商品类逗号拼接, 1:单品; 2:套餐;3:商品组; 4:外送费
      // productCodes, //1个或多个商品编号逗号拼接
      ...params
    });
    const handleData = data.productList?.map(i => {
      return {
        productName: i.productNameCn,
        productCode: i.productCode
      };
    });

    setModelData(handleData);
    setTotal(data.total);
    setLoading(false);
  };

  const onGetTag = async () => {
    const { data } = await Api.getTag();
    // 与PCM约定，type为10 供我们使用
    const handleData =  data?.tagList.filter(tag => tag.type == '10') || [];
    setTag(handleData);
  };

  const onSelectModel = () => {
    setValue('goods');
    setVisible(true);
    setSearchVal('');
    onQuery({...pages});
    onGetTag();
  };

  const columnsDialog = [
    {
      title: '商品标签/商品名称',
      dataIndex: 'productName',
      render: (_, row) => {
        if (row.labelId) {
          return <span>
            {row.labelName}
            （标签）
            {/*<TagOutlined style={{ color: '#52c41a' }} />*/}
          </span>;
        }
        return <span>{row.productName}</span>;
      }
    }, {
      title: '商品Code',
      dataIndex: 'productCode',
      render: (_, row) => {
        if (row.labelId) {
          return <span>-</span>;
        }
        return <span>{row.productCode}</span>;
      }
    }
  ]

  const onPageChange = (page, pageSize) => {
    onQuery({
      pageNo: page,
      pageSize: pageSize,
      productTags: searchVal.trim() ? '' : currentProductTags,
      [searchSelect]: searchVal.trim(),
    });
    setPages({
      pageNo: page,
      pageSize: pageSize
    });
  };


  const onChange = (e) => {
    setValue(e.target.value);
    if (e.target.value === '1') {
      onQuery({
        pageNo: 1,
        pageSize: 10
      });
      setPages({
        pageNo: 1,
        pageSize: 10
      });
    }
  };
  const onChangeTag = (key) => {
    const tagArr = key.map(i => {
      return {
        labelId: i,
        labelName: i
      };
    });
    setSelectTag(tagArr);
  };
  const onView = (productTags, tagName) => {
    onQuery({
      pageNo: 1,
      pageSize: 10,
      productTags
    });
    setCurrentProductTags(tagName)
    setPages({
      pageNo: 1,
      pageSize: 10
    });
    setSearchVal('')
  };

  const onSearch = (val) => {

    onQuery({
      pageNo: 1,
      pageSize: 10,
      [searchSelect]: val.trim(),
    });
    setPages({
      pageNo: 1,
      pageSize: 10
    });
  }


  const onOk = () => {
    let selectData = [];
    let compareKey;
    if (value === 'goods') {
      selectData = selectTable.current.selectedRow;
      compareKey = 'productCode';
    } else {
      selectData = selectTag;
      compareKey = 'labelId';
    }
    if (selectData.length === 0) {
      message.warning('请选择至少一个');
      return;
    }
    const res = compareArr(props.product.productList, selectData, compareKey);
    if (res.length < (selectData.length + props.product.productList.length)) {
      message.warning('存在');
    }

    props.setRulesData({
      ...props.product,
      productList: res
    });
    setVisible(false);
  };

  const selectModel = () => {
    return <Modal
      title='选择商品/标签'
      centered
      visible={visible}
      onOk={onOk}
      onCancel={() => setVisible(false)}
      width={1000}
    >
      <Spin spinning={loading}>
        <div style={{display: 'flex', justifyContent: 'space-between', marginBottom: '10px'}}>
          <Radio.Group
            onChange={onChange}
            value={value}
            style={{marginBottom: 0}}>
            <Radio.Button value='goods'>选择商品</Radio.Button>
            <Radio.Button value='tag'>选择标签</Radio.Button>
          </Radio.Group>
          {
            value === 'goods' && <div>
              <Input.Group compact>
                <Select  style={{width: 90}} value={searchSelect} onChange={val => setSearchSelect(val)}>
                  <Select.Option value="productNameCn">按名称</Select.Option>
                  <Select.Option value="productCodes">按Code</Select.Option>
                </Select>
                <Input.Search placeholder={'全局搜索'}
                              allowClear
                              value={searchVal}
                              onChange={e => setSearchVal(e.target.value)}
                              onSearch={onSearch}
                              style={{width: 200, height: '32px'}}/>
              </Input.Group>

            </div>

          }
        </div>
        <Row>
          <Col span={6}>
            <div style={{padding: '10px 0 0 10px'}}>
              {
                value === 'goods' && <>
                  <Row>
                    <div style={{paddingRight: '8px'}}>全部</div>
                    <a onClick={() => onView()}>查看</a>
                  </Row>
                  {
                    tag.map(i => <Row key={i.code}>
                      <div style={{paddingRight: '8px'}}>{i.name}</div>
                      <a onClick={() => onView(i.code, i.name)}>查看</a>
                    </Row>)
                  }
                </>
              }
              {
                value === 'tag' && <Checkbox.Group style={{width: '100%'}} onChange={onChangeTag}>
                  {
                    tag.map(i => <Row key={i.code}>
                      <Checkbox value={i.code}>{i.name}</Checkbox>
                      <a onClick={() => onView(i.code, i.name)}>查看</a>
                    </Row>)
                  }
                </Checkbox.Group>
              }
            </div>
          </Col>
          <Col span={18}>
            <CondsTable
              ref={selectTable}
              rowKey={row => row.labelId || row.productCode}
              columns={columnsDialog}
              data={modelData}
              isShowRowSelect={value === 'goods'}
              total={total}
              onPageChange={onPageChange}
              isControlled={true}
              current={pages.pageNo}
              pageSize={pages.pageSize}
            >
            </CondsTable>
          </Col>
        </Row>

      </Spin>
    </Modal>;
  };




  return (
    <>
      <Button type='primary' onClick={onSelectModel}>选择</Button>
      {visible && selectModel()}
    </>
  );
}



export default SelectProduct