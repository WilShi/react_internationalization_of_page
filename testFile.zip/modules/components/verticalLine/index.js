import React from 'react';
import './index.less';
/**
 *
 * 竖线
 *
 */
export default class VerticalLine extends React.Component {
  constructor(props) {
    super(props);
  }
  render() {
    return <span className="verticalLine" />;
  }
}
