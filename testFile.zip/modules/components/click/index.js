/* eslint-disable jsx-a11y/no-static-element-interactions */
import React from 'react';
import './index.less';
export default class ClickLink extends React.PureComponent {
  constructor(props) {
    super(props);
  }
  /**
   *
   * @param {*} event
   */
  onClick = (event) => {
    this.props.onClick && this.props.onClick(event);
  };
  render() {
    return (
      <span
        className={`${this.props.className}  clickColor`}
        style={{ ...this.props.style }}
        onClick={() => this.onClick(event)}
      >
        {this.props.children}
      </span>
    );
  }
}
