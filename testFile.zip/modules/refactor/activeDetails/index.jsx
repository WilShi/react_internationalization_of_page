import React, { useState, useRef, useEffect } from 'react';
import { Steps, message, Button, Modal, Input } from '@mcd/portal-components';

import First from './components/steps/first';
import Second from './components/steps/second';
import Third from './components/steps/third/index';
import Fourth from './components/steps/fourth/index';
import './index.less';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';

import Api from '@/api/point/index';
import * as rules from '@/redux/actions/rulesAction';
import { getCheckboxStatus } from './config';
import { checkMyPermission } from '@mcd/portal-components/dist/utils/common';


const { Step } = Steps;
const userInfo = JSON.parse(localStorage.getItem('USER_INFO'));// 获取登录名账号信息
function ActiveDetail (props) {
  const firstRef = useRef(null);
  const thirdRef = useRef(null);
  const { activityId, levelNo = 1, haveCheck } = props.match.params || {};
  const [current, setCurrent] = useState(+sessionStorage.getItem(`currentStep${activityId}${levelNo}`) ?? 0);
  console.log('current', current)
  // const [current, setCurrent] = useState(3);
  const [reviewInfo, setReviewInfo] = useState({});
  const [basicInfo, setBasicInfo] = useState({});
  const [checkStatus, setCheckStatus] = useState([]);
  const [copyVisible, setCopyVisible] = useState(false)
  const [title, setTitle] = useState('')

  const steps = [
    { title: '基本信息' },
    { title: '活动规则' },
    { title: '通用设置' },
    { title: '活动复核' }
  ];

  useEffect(() => {
    // 获取最新current
    setCurrent(+sessionStorage.getItem(`currentStep${activityId}${levelNo}`) || 0)
  }, [activityId, levelNo])

  useEffect(() => {
    const id = sessionStorage.getItem('activityId');
    props.initRules();
    if (activityId || id) {
      if (current == 3) {
        setTimeout(() => {
          getActivityData(activityId || id);
        }, 500)
      } else {
        getActivityData(activityId || id);
      }
    }
  }, [current, activityId, levelNo]);

  useEffect(() => {
    return () => {
      sessionStorage.removeItem('activityId');
      sessionStorage.removeItem('levelNo');
      sessionStorage.removeItem(`currentStep${activityId}${levelNo}`);
    };
  }, []);


  const onNext = () => {
    onSave().then(res => {
      if (res === 'SUCCESS') {
        setCurrent(current + 1);
        sessionStorage.setItem(`currentStep${activityId}${levelNo}`, current + 1);
      }
    });
  };

  const onPrev = () => {
    setCurrent(current - 1);
    sessionStorage.setItem(`currentStep${activityId}${levelNo}`, current - 1);
  };

  const onSave = async () => {
    let result = 'FAIL';
    if (current == 0) {
      const data = await firstRef.current.onNext();
      result = data.code == 'SUCCESS' ? 'SUCCESS' : 'FAIL'
      sessionStorage.setItem('activityId', data?.data?.activityId);
      sessionStorage.setItem('levelNo', data?.data?.levelNo);
    }
    if (current == 1) {

      const rulesGenerate = {}
      checkStatus.forEach(i => {
        rulesGenerate[i.key] = props.rules[i.key]
      })
      const params = {
        ...rulesGenerate,
        levelNo: activityId ? +levelNo : sessionStorage.getItem('levelNo'),
        pointRuleId: activityId ? activityId : sessionStorage.getItem('activityId'),
        operationUser: userInfo.nickName
      };
      try {
        const isSelected = checkStatus.some(i => i.checked);
        if (!isSelected) {
          throw Error('至少勾选一个');
        }
        checkStatus.forEach((i, index) => {
          if (!i.checked) {
            params[i.key] = null;
          } else {
            if (!toVerify(i.key)) {
              throw Error(`条件${index + 1}必填`);
            }
          }
        });

        if (params.datePeriod?.timeList?.length > 0) {
          params.datePeriod.timeList = params.datePeriod.timeList.sort((a, b) => {
            return Date.parse('04-23 ' + a.startTime) - Date.parse('04-23 ' + b.startTime)
          })
        }
        if (params.intervalPeriod?.dateList?.length > 0) {
          params.intervalPeriod.dateList = params.intervalPeriod.dateList.sort((a, b) => {
            return Date.parse(a) - Date.parse(b)
          })
        }
        if (params.store && params.store.storeList && params.store.storeList.length > 1000) {
          message.warning('指定餐厅不能大于1000个')
          return
        }
        const data = await Api.createRules(params);
        result = data.code == 'SUCCESS' ? 'SUCCESS' : 'FAIL'

      } catch (e) {
        result = 'FAIL';
        message.warning(e.message);
      }
    }
    if (current == 2) {
      const data = await thirdRef.current.onNext();
      result = data?.code == 'SUCCESS' ? 'SUCCESS' : 'FAIL'
    }
    return result;
  };

  const toVerify = (key) => {
    let required = true;
    switch (key) {
      case 'crowd':
        if (props.rules.crowd.crowdList.length === 0) {
          required = false;
        }
        break;
      case 'amount':
        if (props.rules.amount.minAmount === null
          || props.rules.amount.minAmount === ''
          || props.rules.amount.maxAmount === null
          || props.rules.amount.maxAmount === '') {
          required = false;
        }
        break;
      case 'beType':
        if (props.rules.beType.beTypeList.length === 0) {
          required = false;
        }
        break;
      case 'card':
        if (props.rules.card.cardList.length === 0) {
          required = false;
        }
        break;
      case 'channel':
        if (props.rules.channel.channelList.length === 0) {
          required = false;
        }
        break;
      case 'coupon':
        if (props.rules.coupon.couponList.length === 0) {
          required = false;
        }
        break;
      case 'datePeriod':
        if (props.rules.datePeriod.timeList.length === 0) {
          required = false;
        }
        props.rules.datePeriod.timeList.forEach(i => {
          if (!i.startTime) {
            required = false;
          }
        });
        break;
      case 'intervalPeriod':
        if (props.rules.intervalPeriod.dateList.length === 0
          && props.rules.intervalPeriod.monthList.length === 0
          && props.rules.intervalPeriod.weekList.length === 0) {
          required = false;
        }
        props.rules.intervalPeriod.dateList.forEach(i => {
          if (!i) {
            required = false;
          }
        });
        break;
      case 'product':
        if (props.rules.product.productList.length === 0) {
          required = false;
        }
        break;
      case 'store':
        if (props.rules.store.storeList.length === 0) {
          required = false;
        }
        break;
      case 'tender':
        if (props.rules.tender.tenderList.length === 0) {
          required = false;
        }
        break;
      case 'integral':
        if (!props.rules.integral.minIntegral || !props.rules.integral.maxIntegral) {
          required = false;
        }
        break;
    }
    return required;
  };

  const getActivityData = async (id) => {
    const { data } = await Api.reviewActivity({ activityId: id, levelNo });
    setBasicInfo(data.pointRule);
    setReviewInfo(data);


    // 审核状态    活动状态      可执行的操作
    // 草稿 	      /	        编辑、复制、删除
    // 待审核	      /	        复制、查看、审核
    // 审核驳回	    /	         编辑、复制、删除
    // 审核通过	  待发布	    复制、查看、更新、发布、作废
    // 审核通过	  发布中	    复制、查看、更新、发布、作废
    // 审核通过	  待执行	    复制、查看、更新、作废
    // 审核通过	  执行中	    复制、查看、更新、作废
    // 审核通过	  执行完成	  复制、查看、更新
    // 审核通过	  已作废	    复制、查看、更新
    // verificationStatus 审核状态 0：草稿 1：待审核 2：通过 3：拒绝
    // status  1待发布 2发布中 3发布失败 4待执行 5执行中 6执行完成 7作废
    if (!sessionStorage.getItem(`currentStep${activityId}${levelNo}`) && [1, 2].indexOf(data.pointRule.verificationStatus) > -1) {
      sessionStorage.setItem(`currentStep${activityId}${levelNo}`, 3);
    }


    const res = getCheckboxStatus(data.pointRule.eventType, data);
    setCheckStatus(res);
    props.setAllRules({ ...data, eventType: data.pointRule.eventType });
  };

  const onChange = (checked, index) => {
    const newCheckStatus = [...checkStatus];
    newCheckStatus[index].checked = checked;
    setCheckStatus(newCheckStatus);
  };

  const onBack = () => {
    const { search, pathname } = window.location;
    const backPath = '/point/pointList';
    window.EventBus && window.EventBus.emit('delAppTab', null, pathname + search, backPath);
  };

  const onCopy = () => {
    setCopyVisible(true)
    setTitle(reviewInfo?.pointRule?.title)
  }

  const onCancel = () => {
    setCopyVisible(false)
  }

  const onCopyActivity = async () => {
    let params = {
      description: reviewInfo?.pointRule?.description,
      eventType: reviewInfo?.pointRule?.eventType,
      levelNo: reviewInfo?.pointRule?.levelNo,
      operationUser: reviewInfo?.pointRule?.nickName,
      pointRuleId: reviewInfo?.pointRule?.pointRuleId,
      shortDescription: reviewInfo?.pointRule?.shortDescription,
      title: title
    }
    await Api.copyActivity(params)
    setCopyVisible(false)
    onBack()
  }

  const onAudit = async () => {
    let params = {
      activityTemplateType: 1,
      levelNo: reviewInfo?.pointRule?.levelNo,
      activityId: reviewInfo?.pointRule?.pointRuleId,
      operationUser: userInfo.nickName
    }
    await Api.submitAudit(params)
    onBack()
  }

  const onEdit = () => {
    sessionStorage.setItem(`currentStep${activityId}${levelNo}`, 0)
    setCurrent(0)
  }

  return (
    <div className='activeDetails descriptions'>
      <div className='activeDetails-activeSteps'>
        <Steps type='navigation' current={current}>
          {steps.map(item => (
            <Step key={item.title} title={item.title} />
          ))}
        </Steps>
      </div>

      <div className='steps-content'>
        {current === 0 && <First basicInfo={basicInfo} ref={firstRef} />}
        {current === 1 && <Second checkStatus={checkStatus} onChange={onChange} eventType={basicInfo.eventType} />}
        {current === 2 && <Third ref={thirdRef} reviewInfo={reviewInfo} />}
        {current === 3 && <Fourth checkStatus={checkStatus} reviewInfo={reviewInfo} />}
      </div>

      <div className='steps-action'>
        {/* {current === 0 && <Button onClick={onBack}>取消</Button>} */}
        {current > 0 && !haveCheck ? <Button style={{ margin: '0 8px' }} onClick={() => onPrev()}> 上一步 </Button> : ''}
        {current < steps.length - 1 && <>
          <Button type='primary' onClick={() => onNext()}>下一步</Button>
          <Button onClick={() => onSave()}>保存</Button>
        </>}
        {current === steps.length - 1 && (
          // 活动状态判断
          <>
            {checkMyPermission('loyaltyManage:activeList:audit') && (reviewInfo?.pointRule?.verificationStatus == 0 || reviewInfo?.pointRule?.verificationStatus == 3) ?
              <Button type='primary' onClick={onAudit}>
                提交
              </Button> : ''}
            {/* <Button type='primary' onClick={onBack}>
              返回
            </Button> */}
          </>
        )}
      </div>
      <Modal
        title={'复制活动'}
        visible={copyVisible}
        onOk={onCopyActivity}
        onCancel={onCancel}>
        <div>
          <p>活动名称（{title.length}/32）：</p>
          <Input style={{ width: 300, marginTop: 8 }} allowClear placeholder={`${$t(/*请输入*/ 'please_type')}`}
            value={title} onChange={e => setTitle(e.target.value)} />
        </div>
      </Modal>
    </div>
  );
}


const mapDispatchToProps = (dispatch) => ({
  initRules: () => {
    dispatch(rules.initData());
  },
  setAllRules: (params) => {
    dispatch(rules.setAllRules(params));
  }
});

const mapStateToProps = (state, ownProps) => {
  return {
    rules: state.rules
  };
};

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(ActiveDetail)
);