export const eventTypeMap = new Map([
  [1, ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12']], // oms下单
  [2, ['2', '3']], // 注册
  [3, []],
  [4, []],
  [5, ['1', '3','6', '7', '8', '9', '12']], // ecs下单
  [6, ['1','3', '7', '8']] // 会员登录
])

export const rulesMap = new Map([
  ['1', 'crowd'],
  ['2', 'store'],
  ['3', 'channel'],
  ['4', 'beType'],
  ['5', 'product'],
  ['6', 'tender'],
  ['7', 'datePeriod'],
  ['8', 'intervalPeriod'],
  ['9', 'amount'],
  ['10', 'coupon'],
  ['11', 'card'],
  ['12', 'integral'],
])

export const getCheckboxStatus = (eventType, obj) => {
  const conditions = eventTypeMap.get(eventType)

  return  conditions.map(i => {
    let checked = false
    const key = rulesMap.get(i)
    if (key !== 'no_support' && obj[key]) {
      checked = true
    }
    return {
      checked,
      condition: i,
      key
    }

  })

}