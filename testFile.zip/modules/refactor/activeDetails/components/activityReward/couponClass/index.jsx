import React, {useState, useRef, useImperativeHandle, forwardRef, useEffect, useMemo} from 'react';


import CondsTable from '../../condsTable';
import {
  Button,
  Col,
  Form,
  Input,
  message,
  Modal,
  Radio,
  Row,
  Select,
  Spin,
  Tooltip,
  Space,
  Checkbox,
  InputNumber
} from '@mcd/portal-components';

import Hoc from '../../conditions/Hoc';
import {getDictionaryLabel} from '@/utils';
import {getDictionaryListByType} from '@mcd/portal-components/dist/utils/DictUtil';
import {onExport, onUpload} from '@/utils/excel';


const key = 'couponId';
const beTypeList = getDictionaryListByType('crm_be_type');
const campaignTypeList = getDictionaryListByType('campaign_type'); // 活动大类
const couponCardTypeList = getDictionaryListByType('cp_coupon_obtaining_type'); // 获取类型

function CouponClass(props, ref) {
  const ShyData = useRef()
  const ShyProductCouponData = useRef()
  const [data, setData] = useState([]);
  const [productCouponData, setProductCouponData] = useState([])
  const [type, setType] = useState(1);
  const [visible, setVisible] = useState(false);
  const [loading, setLoading] = useState(false);
  const [modelData, setModelData] = useState([]);
  const [total, setTotal] = useState([]);

  const showTable = useRef(null);
  const selectTable = useRef(null);
  const productCouponTable = useRef(null);

  const [pages, setPages] = useState({
    pageNo: 1,
    pageSize: 10
  });

  const [form] = Form.useForm();

  useEffect(() => {
    props.ruleCoupon?.type == 1 && setData(props.ruleCoupon?.ruleCouponList ?? []);
    props.ruleCoupon?.type == 2 && setProductCouponData(props.ruleCoupon?.ruleCouponList ?? [])
    setType(props.ruleCoupon?.type ?? 1);
  }, [props.ruleCoupon]);

  useEffect(() => {
    props.onSetCoupon({
      type,
      ruleCouponList: type == 1 ? data : productCouponData,
    })
  }, [type, data, productCouponData])

  useEffect(() => {
    ShyData.current = data
    ShyProductCouponData.current = productCouponData
  }, [data, productCouponData])

  const columns = [
    {
      title: '排序',
      dataIndex: 'sort',
      width: '80px',
      render: (_, __, index) => (<span>{index + 1}</span>)
    },
    {
      title: '优惠券ID',
      dataIndex: 'couponId',
      width: '300px',
      filter: true
    }, {
      title: '优惠券名称',
      dataIndex: 'couponName',
      width: '120px',
      filter: true
    }, {
      title: '促销编号',
      dataIndex: 'promotionId',
      width: '120px',
      filter: true
    }, {
      title: '活动名称',
      dataIndex: 'campaignName',
      width: '120px',
      filter: true
    }, {
      title: 'BE_type',
      dataIndex: 'beTypes',
      width: '120px',
      render: types => {
        const typeList = types && types.length ? types.split(',') : []
        const text = typeList?.map((i) => {
          return getDictionaryLabel('crm_be_type', i);
        }).join(',');
        return <Tooltip placement='topLeft' title={text || '-'}>{text || '-'}</Tooltip>;
      }
    }, {
      title: '操作',
      key: 'action',
      width: '180px',
      render: (text, row, ind) => {
        return <Space size="middle">
          <Radio.Group onChange={e => onChange(e, row)} value={row.grantType ?? '1'}>
            <Radio value={'1'}>直塞</Radio>
            {/* <Radio value={'2'} disabled={props?.eventType == 2}>领取</Radio> */}
            <Radio value={'2'} disabled={true}>领取</Radio>
          </Radio.Group>
        </Space>
      },
    },
  ];


  const onChange = (e, row) => {
    row.grantType = e.target.value
    setData([...ShyData.current])
  }


  const modelColumns = [
    {
      title: '优惠券ID',
      dataIndex: 'couponId',
    }, {
      title: '优惠券名称',
      dataIndex: 'title',
    }, {
      title: '活动大类',
      dataIndex: 'campaignType',
      render: text => <span>{getDictionaryLabel('campaign_type', text)}</span>
    }, {
      title: 'BE type',
      dataIndex: 'beTypes',
      render: typeList => {
        const text = typeList?.map((i) => {
          return getDictionaryLabel('crm_be_type', i);
        }).join(',');
        return <Tooltip placement='topLeft' title={text || '-'}>{text || '-'}</Tooltip>;
      }
    }, {
      title: '会员活动名称',
      dataIndex: 'campaignName',
    }, {
      title: '促销编号',
      dataIndex: 'promotionId',
    }, {
      title: '获取类型',
      dataIndex: 'couponCardType',
      render: text => <span>{getDictionaryLabel('cp_coupon_obtaining_type', text)}</span>
    }, {
      title: '剩余数量',
      dataIndex: 'remainQuantity',
    }, {
      title: '优惠券促销类型',
      dataIndex: 'couponPromotionType',
      render: text => <span>{getDictionaryLabel('coupon_promotion_type', text)}</span>
    }, {
      title: '优惠券创建时间',
      dataIndex: 'createdDate',
    }
  ];

  const productCouponDataColumns = [
    {
      title: '购买商品CODE',
      dataIndex: 'productCode',
    }, {
      title: '购买方式',
      dataIndex: 'regularGoods',
      align: 'center',
      width: 200,
      render: (text, row) => {
        return (
          <Radio.Group value={text} onChange={(e) => onChangeTemplate(e, row, 'regularGoods')}>
            <Radio value={2}>正价购买</Radio>
            <Radio value={1}>任意方式</Radio>
          </Radio.Group>
        )
      }
    }, {
      title: '发放优惠券ID',
      dataIndex: 'couponId',
    }, {
      title: '每个商品发放张数',
      dataIndex: 'couponNumber',
      align: 'center',
      render: (text, row) => {
        return <InputNumber min={1} max={9} value={text} onChange={(e) => onChangeTemplate(e, row, 'couponNumber')} />
      }
    }, {
      title: '操作',
      dataIndex: 'operation',
      render: (text, row) => {
        return <Button type="link" onClick={() => onDelectProCoupon(row)}>删除</Button>
      }
    }
  ]

  useEffect(() => {
    showTable.current?.initSelected();
  }, []);


  const onQuery = async (params) => {
    setLoading(true);
    let fields = form.getFieldsValue();
    const {data} = await props.getCoupon({
      ...pages,
      ...fields,
      ...params
    });
    setModelData(data.list);
    setTotal(data.total);
    setLoading(false);
  };

  const onSelectModel = () => {
    setVisible(true);
    onQuery();
  };
  const onDelete = () => {
    let selectData = showTable.current.selected;
    const newData = data.filter(i => !selectData.some(j => i[key] === j));
    setData(newData);
    showTable.current?.initSelected();
  };

  const onOk = () => {
    const selectData = selectTable.current.selectedRow;
    if (selectData.length === 0) {
      message.warning('请选择至少一个');
      return;
    }
    const res = selectTable.current.compareArr(data, selectData, key);

    if (res.length > 10) {
      message.warning('最多选择10个');
      return;
    }

    if (res.length < (selectData.length + data.length)) {
      message.warning('存在');
    }

    const newData = JSON.parse(JSON.stringify(data))
    res.forEach(i => {
      const result = data.some(j => i.couponId === j.couponId)
      if (!result) {
        newData.push(i)
      }
    })

    setData(newData.map(i => ({
      couponId: i.couponId,
      couponName: i.couponName || i.title,
      promotionId: i.promotionId,
      campaignName: i.campaignName,
      beTypes: i.beTypes && i.beTypes.length ? (Array.isArray(i.beTypes) ? i.beTypes.join(',') : i.beTypes) : '',
      grantType: i.grantType
    })))
    setVisible(false);
  };

  const onDelectProCoupon = (row) => {
    const newData = ShyProductCouponData.current.filter(i => !(i.productCode == row.productCode && i.couponId == row.couponId))
    setProductCouponData(newData)
  }

  const onExportTemplate = () => {
    let curTemplate = []
    if (productCouponData.length) {
      productCouponData.forEach(item => [
        curTemplate.push({'购买的商品CODE': item.productCode, '购买方式（1：任意购买；2：正价购买）': item.regularGoods, '发放的优惠券ID': item.couponId, '每个商品发放张数（1~9）': item.couponNumber})
      ])
    } else {
      curTemplate = [{'购买的商品CODE': '', '购买方式（1：任意购买；2：正价购买）': '', '发放的优惠券ID': '', '每个商品发放张数（1~9）': ''}]
    }
    onExport(curTemplate, '优惠券模板');
  }

  const handleUpload = async (e) => {
    onUpload(e.target.files, (res) => {
      if (res.length === 0) {
        message.warning('excel无数据或模版不对');
      } else {
        try {
          if (!validateImportData(res)) {
            return
          }
          let uploadData = []
          res.forEach(item => {
            uploadData.push({productCode: item['购买的商品CODE'].toString().trim(), regularGoods: item['购买方式（1：任意购买；2：正价购买）'], couponId: item['发放的优惠券ID'].toString().trim(), couponNumber: item['每个商品发放张数（1~9）']})
          })
          setProductCouponData(uploadData);
        } catch (e) {
          message.warning('导入失败');
        }
      }
    });
  }

  const onChangeTemplate = (e, row, columnName) => {
    const newData = [].concat(ShyProductCouponData.current)
    newData.forEach((item) => {
      if (item.productCode === row.productCode && item.couponId === row.couponId) {
        item[columnName] = columnName == 'regularGoods' ? e.target.value : e
      }
    })
    setProductCouponData(newData)
  }

  // 导入文件校验
  const validateImportData = (arr) => {
    let flag = true
    for (let i = 0; i < arr.length; i++) {
      if (arr[i]['每个商品发放张数（1~9）'] < 1 || arr[i]['每个商品发放张数（1~9）'] > 9) {
        flag = false
        message.warning('优惠券发放张数限制为1-9，导入失败')
        return
      }
      for (let j = i + 1; j < arr.length; j++) {
        if (arr[i]['购买的商品CODE'] == arr[j]['购买的商品CODE'] && arr[i]['发放的优惠券ID'] == arr[j]['发放的优惠券ID']){
          flag = false
          message.warning('文件中有重复项，导入失败')
          return
          // arr.splice(j,1)
          // j--;
        }
      }
    }
    return flag
    // return arr
  };

  const onPageChange = (page, pageSize) => {
    onQuery({
      pageNo: page,
      pageSize: pageSize
    });
    setPages({
      pageNo: page,
      pageSize: pageSize
    });
  };

  const selectModel = () => {
    return <Modal
      title='选择优惠券'
      centered
      visible={visible}
      onOk={onOk}
      onCancel={() => setVisible(false)}
      width={1000}
    >
      <Spin spinning={loading}>

        <Form
          form={form}
          layout='vertical'
          onFinish={val => onPageChange(1, 10)}
        >
          <Row gutter={24}>
            <Col span={8}>
              <Form.Item name='couponId' label={`优惠券ID`}>
                <Input placeholder='优惠券ID'/>
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item name='campaignType' label={`活动大类`}>
                <Select allowClear
                        style={{width: '100%'}}
                        placeholder={`${$t(/*请选择*/ 'please_select')}${$t(/*活动大类*/ 'activity_categories')}`}>
                  {campaignTypeList.map((i) => (
                    <Select.Option value={i.dictValue} key={i.dictValue}>
                      {i.dictLabelCn}
                    </Select.Option>
                  ))}
                </Select>
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item name='beType' label={`BE Type`}>
                <Select style={{width: '100%'}} placeholder='请选择' allowClear>
                  {beTypeList.map((i) => (
                    <Select.Option value={i.dictValue} key={i.dictValue}>
                      {i.dictLabelCn}
                    </Select.Option>
                  ))}
                </Select>
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item name='couponCardType' label={`获取类型`}>
                <Select style={{width: '100%'}} placeholder='请选择' allowClear>
                  {couponCardTypeList.map((i) => (
                    <Select.Option value={i.dictValue} key={i.dictValue}>
                      {i.dictLabelCn}
                    </Select.Option>
                  ))}
                </Select>
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item name='campaignName' label={`活动名称`}>
                <Input placeholder='活动名称' />
              </Form.Item>
            </Col>
          </Row>
          <Row>
            <Col span={24} style={{textAlign: 'right'}}>
              <Button type='primary' htmlType='submit'>查询</Button>
              <Button style={{margin: '0 8px'}} onClick={() => form.resetFields()}>重置</Button>
            </Col>
          </Row>
        </Form>

        <CondsTable
          ref={selectTable}
          rowKey={row => row[key]}
          columns={modelColumns}
          data={modelData}
          isShowRowSelect={true}
          total={total}
          onPageChange={onPageChange}
          isControlled={true}
          current={pages.pageNo}
          pageSize={pages.pageSize}
        >
        </CondsTable>
      </Spin>
    </Modal>;
  };

  const Table = useMemo(() => {
    return <CondsTable
      style={{marginLeft: '20px'}}
      ref={showTable}
      bordered
      rowKey={row => row.couponId}
      columns={columns}
      data={data}
      // total={props.coupon.couponList.length}
      isShowRowSelect={true}
      isDrag={true}
      pagination={{hideOnSinglePage: true}}
      moveRow={r => {
        setData(r)
      }}
    />
  }, [data])

  const ProductCouponTable = useMemo(() => {
    return <CondsTable
      ref={productCouponTable}
      rowKey={row => row.productCode + row.couponId}
      columns={productCouponDataColumns}
      data={productCouponData}
      pagination={false}>
    </CondsTable>
  }, [productCouponData])

  return (
    <div>
      <div>{props.children}</div>

      {
        props.checked && <div style={{margin: '10px 0'}}>
          {
            props?.eventType !== 2 &&
            <Radio.Group onChange={(e) => setType(e.target.value)} value={type} style={{marginLeft: '20px'}}>
              <Radio value={1}>按次发放</Radio>
              {
                props?.eventType === 1 && <Radio value={2}>按商品数量发放</Radio>
              }
            </Radio.Group>
          }

          { type === 1 && <div>
            <div style={{padding: '10px 0', marginLeft: '20px'}}>
              {
                data.length < 10 &&
                <Button type='primary' onClick={onSelectModel}>选择</Button>
              }
              <Button type='primary' danger onClick={onDelete}>删除选中</Button>
            </div>
            {Table}
            <div style={{textAlign: 'right', marginTop: '10px'}}>剩余添加条数：{10 - data.length}</div>
          </div> }

          { type === 2 && <div style={{marginLeft: '20px'}}>
            <div style={{padding: '10px 0'}}>
              <Button type='primary' style={{height: '32px', border: '#1890ff', background: '#1890ff'}} onClick={onExportTemplate}>模板导出现有设置</Button>
              <a style={{
                display: 'inline-block',
                position: 'relative',
                marginRight: '8px',
                width: '80px',
                height: '32px',
                lineHeight: '32px',
                border: '#1890ff',
                borderRadius: '4px',
                textAlign: 'center',
                background: '#1890ff',
                color: '#fff',
                cursor: 'pointer'
              }}>
                按文件导入
                <input type='file' onChange={handleUpload} onClick={e => e.target.value = ''} style={{
                  width: '80px',
                  height: '32px',
                  position: 'absolute',
                  top: '0',
                  right: '0',
                  cursor: 'pointer',
                  fontSize: 0,
                  opacity: 0
                }}/>
              </a>
            </div>
            {ProductCouponTable}
          </div>}
        </div>
      }
      {visible && selectModel()}
    </div>
  );
}


export default Hoc(CouponClass);
