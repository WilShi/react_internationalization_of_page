import CouponClass from './couponClass'
import EquityClass from './equityClass'
import PointClass from './pointClass'

export const Rewards = {
  CouponClass,
  EquityClass,
	PointClass
}