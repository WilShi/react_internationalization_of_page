import React, {useState, useRef, useEffect} from 'react';

import CondsTable from '../../condsTable';
import {
  Button,
  Col,
  Form,
  Input,
  message,
  Modal, Radio,
  Row,
  Select,
  Space,
  Spin,
  Table,
  Tooltip,
  Checkbox
} from '@mcd/portal-components';

import Hoc from '../../conditions/Hoc';
import {getDictionaryLabel} from '@/utils';
import {getDictionaryListByType} from '@mcd/portal-components/dist/utils/DictUtil';


const key = 'cardId';
const beTypeList = getDictionaryListByType('crm_be_type');
const campaignTypeList = getDictionaryListByType('campaign_type'); // 活动大类
const couponCardTypeList = getDictionaryListByType('cp_coupon_obtaining_type'); // 获取类型

function EquityClass(props, ref) {
  // console.log('------', props)
  const [data, setData] = useState([]);
  const [type, setType] = useState(1);
  const [regularGoods, setRegularGoods] = useState(1);
  const [visible, setVisible] = useState(false);
  const [loading, setLoading] = useState(false);
  const [modelData, setModelData] = useState([]);
  const [total, setTotal] = useState([]);


  const [couponData, setCouponData] = useState([]);
  const [couponVisible, setCouponVisible] = useState(false);
  const [couponTitle, setCouponTitle] = useState(null);


  const showTable = useRef(null);
  const selectTable = useRef(null);

  const [pages, setPages] = useState({
    pageNo: 1,
    pageSize: 10
  });

  const [form] = Form.useForm();


  useEffect(() => {
    setData(props.ruleCard?.ruleCardList ?? []);
    setType(props.ruleCard?.type ?? 1);
    setRegularGoods(props.ruleCard?.regularGoods ?? 1);
  }, [props.ruleCard]);

  useEffect(() => {
    props.onSetCard({
        type,
        ruleCardList: data,
        regularGoods: type === 2 ? regularGoods : null
      }
    )
  }, [type, data, regularGoods])

  const columns = [
    {
      title: '权益卡ID',
      dataIndex: 'cardId',
      width: '350px',
      filter: true
    }, {
      title: '权益卡名称',
      dataIndex: 'cardName',
      filter: true
    }, {
      title: '操作',
      key: 'action',
      render: (_, row) => <Space size='middle'>
        <a onClick={() => onViewCoupon(row)}>查看优惠券</a>
      </Space>

    }
  ];

  const onViewCoupon = async (row) => {
    const {data} = await props.getEquityById({
      cardId: row.cardId,
      pageNo: 1,
      pageSize: 999
    });
    setCouponData(data.list);
    setCouponTitle(row.cardName);
    setCouponVisible(true);
  };

  const modelColumns = [
    {
      title: '权益ID',
      dataIndex: 'cardId',
    }, {
      title: '权益卡名称',
      dataIndex: 'title',
    }, {
      title: '活动编号',
      dataIndex: 'campaignCode',
    }, {
      title: '活动名称',
      dataIndex: 'campaignName',
    }, {
      title: '创建时间',
      dataIndex: 'createdTime'
    }
  ];
  const couponColumns = [
    {
      title: '权益ID',
      dataIndex: 'interestsId'
    }, {
      title: '优惠券ID',
      dataIndex: 'refInterestsId'
    }, {
      title: '权益名称',
      dataIndex: 'interestsName'
    }, {
      title: '权益类型',
      dataIndex: 'interestsType',
      render: text => <span>{getDictionaryLabel('it_card_interests_type', text)}</span>
    }
  ];

  useEffect(() => {
    showTable.current?.initSelected();
  }, []);


  const onQuery = async (params) => {
    setLoading(true);
    let fields = form.getFieldsValue();
    const {data} = await props.getEquity({
      ...pages,
      ...fields,
      ...params
    });
    setModelData(data.list);
    setTotal(data.total);
    setLoading(false);
  };

  const onSelectModel = () => {
    setVisible(true);
    onQuery();
  };
  const onDelete = () => {
    let selectData = showTable.current.selected;
    const newData = data.filter(i => !selectData.some(j => i[key] === j));
    setData(newData);
    showTable.current?.initSelected();
  };

  const onOk = () => {
    const selectData = selectTable.current.selectedRow;
    if (selectData.length === 0) {
      message.warning('请选择至少一个');
      return;
    }
    const res = selectTable.current.compareArr(data, selectData, key);
    if (res.length > 10) {
      message.warning('最多选择10个');
      return;
    }
    if (res.length < (selectData.length + data.length)) {
      message.warning('存在');
    }
    setData(res.map(i => ({
      cardId: i.cardId,
      cardName: i.cardName || i.title,
      promotionId: i.promotionId || i.campaignCode
    })));
    setVisible(false);
  };

  const onPageChange = (page, pageSize) => {
    onQuery({
      pageNo: page,
      pageSize: pageSize
    });
    setPages({
      pageNo: page,
      pageSize: pageSize
    });
  };

  const selectModel = () => {
    return <Modal
      title='选择权益卡'
      centered
      visible={visible}
      onOk={onOk}
      onCancel={() => setVisible(false)}
      width={1000}
    >
      <Spin spinning={loading}>

        <Form
          form={form}
          layout='vertical'
          onFinish={val => onPageChange(1, 10)}
        >
          <Row gutter={24}>
            <Col span={8}>
              <Form.Item name='cardId' label={`权益卡ID`}>
                <Input placeholder='权益卡ID'/>
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item name='cardName' label={`权益卡名称`}>
                <Input placeholder='权益卡名称'/>
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item name='campaignCode' label={`活动编号`}>
                <Input placeholder='活动编号'/>
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item name='campaignName' label={`活动名称`}>
                <Input placeholder='活动名称'/>
              </Form.Item>
            </Col>
          </Row>
          <Row>
            <Col span={24} style={{textAlign: 'right'}}>
              <Button type='primary' htmlType='submit'>查询</Button>
              <Button style={{margin: '0 8px'}} onClick={() => form.resetFields()}>重置</Button>
            </Col>
          </Row>
        </Form>

        <CondsTable
          ref={selectTable}
          rowKey={row => row[key]}
          columns={modelColumns}
          data={modelData}
          isShowRowSelect={true}
          total={total}
          onPageChange={onPageChange}
          isControlled={true}
          current={pages.pageNo}
          pageSize={pages.pageSize}
        >
        </CondsTable>
      </Spin>
    </Modal>;
  };

  const showCouponVisible = () => {
    return <Modal
      title={couponTitle}
      centered
      visible={couponVisible}
      onOk={() => setCouponVisible(false)}
      onCancel={() => setCouponVisible(false)}
      width={1000}
    >
      <Table
        rowKey={row => row.interestsId}
        columns={couponColumns}
        dataSource={couponData}
        scroll={{x: '100%', y: 400}}
        size='small'/>
    </Modal>;
  };

  return (
    <div style={{marginTop: '20px'}}>
      <div>{props.children}</div>

      {
        props.checked && <div style={{margin: '10px 0'}}>
          {
            props?.eventType !== 2 &&
            <Radio.Group onChange={e => setType(e.target.value)} value={type} style={{marginLeft: '20px'}}>
              <Radio value={1}>按次发放</Radio>
              {
                props?.eventType === 1 && <Radio value={2}>按商品数量发放</Radio>
              }
            </Radio.Group>
          }


          <div style={{padding: '10px 0', marginLeft: '20px'}}>
            {data.length < 10 && <Button type='primary' onClick={onSelectModel}>选择</Button>}

            <Button type='primary' danger onClick={onDelete}>删除选中</Button>
          </div>

          <CondsTable
            style={{marginLeft: '20px'}}
            ref={showTable}
            bordered
            rowKey={row => row[key]}
            columns={columns}
            data={data}
            // total={props.coupon.couponList.length}
            isShowRowSelect={true}
            isDrag={true}
            pagination={{hideOnSinglePage: true}}
            moveRow={r => setData(r)}
          />

          <div style={{display: 'flex', justifyContent: 'space-between', marginTop: '10px'}}>
            {
              type === 2 ? <Checkbox
                style={{marginLeft: '30px'}}
                onChange={e => setRegularGoods(e.target.checked ? 2 : 1)}
                checked={regularGoods == 2}
              >非正价商品不计算</Checkbox> : <span></span>
            }
            <div style={{textAlign: 'right'}}>剩余添加条数：{10 - data.length}</div>
          </div>
        </div>
      }


      {visible && selectModel()}
      {couponVisible && showCouponVisible()}
    </div>
  );
}


export default Hoc(EquityClass);