import React, { useEffect, useRef, useState } from 'react';
import Hoc from '../Hoc';
import CondsTable from '../../condsTable';
import { compareArr } from '../index';
import { Button, Space, Modal, Table, Tabs, Radio, Row, Col, Checkbox, Spin, Input, Switch, Select } from '@mcd/portal-components';
import { message } from 'antd';
import { TagOutlined } from '@ant-design/icons';
import * as rules from '@/redux/actions/rulesAction';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { onExport, onUpload } from '@/utils/excel';

const { TabPane } = Tabs;
const local = localStorage.getItem('locale');

function Goods (props) {
  // console.log('propsProduct: ', props);
  const [visible, setVisible] = useState(false);
  const [goodsVisible, setGoodsVisible] = useState(false);
  const [tagTitle, setTagTitle] = useState('');
  const [modelData, setModelData] = useState([]);
  const [total, setTotal] = useState([]);
  const [loading, setLoading] = useState(false);
  const [value, setValue] = useState('goods');
  const [tag, setTag] = useState([]);
  const [selectTag, setSelectTag] = useState([]);
  const showTable = useRef(null);
  const selectTable = useRef(null);
  const [pages, setPages] = useState({
    pageNo: 1,
    pageSize: 10
  });
  const [currentProductTags, setCurrentProductTags] = useState()
  const [searchVal, setSearchVal] = useState('')
  const [searchSelect, setSearchSelect] = useState('productNameCn')


  useEffect(() => {
    showTable.current?.initSelected();
  }, []);


  const onQuery = async (params) => {
    setLoading(true);
    const { data } = await props.getGoods(params);
    const handleData = data.productList?.map(i => {
      return {
        productName: i.productNameCn,
        productCode: i.productCode
      };
    });

    setModelData(handleData);
    setTotal(data.total);
    setLoading(false);
  };

  const onGetTag = async () => {
    const data = await props.getTag();
    setTag(data);
  };

  const onSelectModel = () => {
    setValue('goods');
    setVisible(true);
    setSearchVal('');
    onQuery({ ...pages });
    onGetTag();
  };

  const onDelete = () => {
    let selected = showTable.current.selected;
    if (selected.length === 0) {
      message.warning('请选择');
      return;
    }
    const newData = props.product.productList.filter(i => !selected.some(j => i.labelId === j || i.productCode === j));

    props.setRulesData({
      ...props.product,
      productList: newData
    });
    showTable.current?.initSelected();
  };

  const onDeleteAll = () => {
    props.setRulesData({
      ...props.product,
      productList: []
    });
  }

  const onExportTemplate = () => {
    onExport([{ 'productName': '', 'productCode': '' }], 'productCode');
  }

  const handleUpload = async (e) => {
    onUpload(e.target.files, (res) => {
      if (res.length === 0) {
        message.warning('excel无数据或模版不对');
      } else {
        try {
          let obj = {};
          //  去重
          let uploadData = res.reduce((cur, next) => {
            obj[next.productCode] ? '' : obj[next.productCode] = true && cur.push(next);
            return cur;
          }, []).map(i => ({ productName: i['productName'].toString().trim(), productCode: i['productCode'].toString().trim() }));
          const result = showTable.current.compareArr(props.product.productList, uploadData, 'productCode');
          if (result.length < (uploadData.length + props.product.productList.length)) {
            message.warning('已智能过滤重复数据');
          }
          props.setRulesData({
            ...props.product,
            productList: result.map(i => ({ productName: i.productName, productCode: i.productCode }))
          });
        } catch (e) {
          message.warning('导入失败');
        }
      }
    });
  };

  const columns = [
    {
      title: '商品标签/商品名称',
      dataIndex: 'productName',
      shy: 'labelName',
      filter: true,
      render: (_, row) => {
        if (row.labelId) {
          return <span>
            {row.labelName}
            （标签）
            {/*<TagOutlined style={{ color: '#52c41a' }} />*/}
          </span>;
        }
        return <span>{row.productName}</span>;
      }
    }, {
      title: '商品Code',
      dataIndex: 'productCode',
      shy: 'labelId',
      filter: true,
      render: (_, row) => {
        if (row.labelId) {
          return <span>-</span>;
        }
        return <span>{row.productCode}</span>;
      }
    }, {
      title: '操作',
      key: 'action',
      render: (_, row) => {
        if (row.labelId) {
          return <Space size='middle'>
            <a onClick={() => onViewGoods(row)}>查看商品</a>
          </Space>;
        }
        return <span>-</span>;
      }
    }
  ];


  const columnsDialog = [
    {
      title: '商品标签/商品名称',
      dataIndex: 'productName',
      render: (_, row) => {
        if (row.labelId) {
          return <span>
            {row.labelName}
            （标签）
            {/*<TagOutlined style={{ color: '#52c41a' }} />*/}
          </span>;
        }
        return <span>{row.productName}</span>;
      }
    }, {
      title: '商品Code',
      dataIndex: 'productCode',
      render: (_, row) => {
        if (row.labelId) {
          return <span>-</span>;
        }
        return <span>{row.productCode}</span>;
      }
    }
  ]

  const onPageChange = (page, pageSize) => {
    onQuery({
      pageNo: page,
      pageSize: pageSize,
      productTags: searchVal.trim() ? '' : currentProductTags,
      [searchSelect]: searchVal.trim(),
    });
    setPages({
      pageNo: page,
      pageSize: pageSize
    });
  };


  const onChange = (e) => {
    setValue(e.target.value);
    if (e.target.value === '1') {
      onQuery({
        pageNo: 1,
        pageSize: 10
      });
      setPages({
        pageNo: 1,
        pageSize: 10
      });
    }
  };
  const onChangeTag = (key) => {
    const tagArr = key.map(i => {
      return {
        labelId: i,
        labelName: i
      };
    });
    setSelectTag(tagArr);
  };
  const onView = (productTags, tagName) => {
    onQuery({
      pageNo: 1,
      pageSize: 10,
      productTags
    });
    setCurrentProductTags(tagName)
    setPages({
      pageNo: 1,
      pageSize: 10
    });
    setSearchVal('')
  };

  const onSearch = (val) => {

    onQuery({
      pageNo: 1,
      pageSize: 10,
      [searchSelect]: val.trim(),
    });
    setPages({
      pageNo: 1,
      pageSize: 10
    });
  }

  const onViewGoods = (row) => {
    setCurrentProductTags(row.labelName)
    onView(row.labelId, row.labelName);
    setTagTitle(row.labelName);
    setGoodsVisible(true);
  };

  const onOk = () => {
    let selectData = [];
    let compareKey;
    if (value === 'goods') {
      selectData = selectTable.current.selectedRow;
      compareKey = 'productCode';
    } else {
      selectData = selectTag;
      compareKey = 'labelId';
    }
    if (selectData.length === 0) {
      message.warning('请选择至少一个');
      return;
    }
    const res = compareArr(props.product.productList, selectData, compareKey);
    if (res.length < (selectData.length + props.product.productList.length)) {
      message.warning('存在');
    }

    props.setRulesData({
      ...props.product,
      productList: res
    });
    setVisible(false);
  };

  const selectModel = () => {
    return <Modal
      title='选择商品/标签'
      centered
      visible={visible}
      onOk={onOk}
      onCancel={() => setVisible(false)}
      width={1000}
    >
      <Spin spinning={loading}>
        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '10px' }}>
          <Radio.Group
            onChange={onChange}
            value={value}
            style={{ marginBottom: 0 }}>
            <Radio.Button value='goods'>选择商品</Radio.Button>
            <Radio.Button value='tag'>选择标签</Radio.Button>
          </Radio.Group>
          {
            value === 'goods' && <div>
              <Input.Group compact>
                <Select style={{ width: 90 }} value={searchSelect} onChange={val => setSearchSelect(val)}>
                  <Select.Option value="productNameCn">按名称</Select.Option>
                  <Select.Option value="productCodes">按Code</Select.Option>
                </Select>
                <Input.Search placeholder={'全局搜索'}
                  allowClear
                  value={searchVal}
                  onChange={e => setSearchVal(e.target.value)}
                  onSearch={onSearch}
                  style={{ width: 200 }} />
              </Input.Group>

            </div>

          }
        </div>
        <Row>
          <Col span={6}>
            <div style={{ padding: '10px 0 0 10px' }}>
              {
                value === 'goods' && <>
                  <Row>
                    <div style={{ paddingRight: '8px' }}>全部</div>
                    <a onClick={() => onView()}>查看</a>
                  </Row>
                  {
                    tag.map(i => <Row key={i.code}>
                      <div style={{ paddingRight: '8px' }}>{i.name}</div>
                      <a onClick={() => onView(i.code, i.name)}>查看</a>
                    </Row>)
                  }
                </>
              }
              {
                value === 'tag' && <Checkbox.Group style={{ width: '100%' }} onChange={onChangeTag}>
                  {
                    tag.map(i => <Row key={i.code}>
                      <Checkbox value={i.code}>{i.name}</Checkbox>
                      <a onClick={() => onView(i.code, i.name)}>查看</a>
                    </Row>)
                  }
                </Checkbox.Group>
              }
            </div>
          </Col>
          <Col span={18}>
            <CondsTable
              ref={selectTable}
              rowKey={row => row.labelId || row.productCode}
              columns={columnsDialog}
              data={modelData}
              isShowRowSelect={value === 'goods'}
              total={total}
              onPageChange={onPageChange}
              isControlled={true}
              current={pages.pageNo}
              pageSize={pages.pageSize}
            >
            </CondsTable>
          </Col>
        </Row>

      </Spin>
    </Modal>;
  };
  const showGoodsModel = () => {
    return <Modal
      title={tagTitle}
      centered
      visible={goodsVisible}
      onOk={() => setGoodsVisible(false)}
      onCancel={() => setGoodsVisible(false)}
      width={1000}
    >
      <Spin spinning={loading}>
        <CondsTable
          rowKey={row => row.labelId || row.productCode}
          columns={columnsDialog}
          data={modelData}
          isShowRowSelect={false}
          total={total}
          onPageChange={onPageChange}
        >
        </CondsTable>
      </Spin>
    </Modal>;
  };

  const onChoose = e => {
    props.setRulesData({
      ...props.product,
      type: e.target.value
    });
  };


  return (
    <>
      <div>{props.children}</div>

      {
        props.checked && <div className='conditions-common-style'>
          <Radio.Group onChange={onChoose} value={props.product.type}>
            <Radio value={1}>包含</Radio>
            <Radio value={2}>排除</Radio>
          </Radio.Group>

          <div>
            <div style={{ padding: '10px 0' }}>
              <Button type='primary' onClick={onSelectModel}>选择</Button>
              <Button type='primary' danger onClick={onDelete}>删除选中</Button>
              <Button type='primary' danger onClick={onDeleteAll}>全部删除</Button>
              <Button onClick={onExportTemplate}>下载模版</Button>
              <Button>
                导入
                <input type='file' onChange={handleUpload} onClick={e => e.target.value = ''} style={{
                  width: '80px',
                  height: '32px',
                  position: 'absolute',
                  top: '0',
                  right: '0',
                  cursor: 'pointer',
                  fontSize: 0,
                  opacity: 0
                }} />
              </Button>
            </div>
            <CondsTable
              ref={showTable}
              rowKey={row => row.labelId || row.productCode}
              columns={columns}
              bordered
              data={props.product.productList}
              total={props.product.productList.length}
              isShowRowSelect={true}
            >
            </CondsTable>
          </div>
        </div>
      }

      {visible && selectModel()}
      {goodsVisible && showGoodsModel()}
    </>
  );
}


const mapDispatchToProps = (dispatch) => ({
  setRulesData: (params) => {
    dispatch(rules.setProduct(params));
  }
});

const mapStateToProps = (state, ownProps) => {
  return {
    product: state.rules.product
  };
};

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(Hoc(Goods))
);