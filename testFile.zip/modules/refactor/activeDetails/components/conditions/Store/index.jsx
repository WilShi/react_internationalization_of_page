import React, { useState, memo, useRef, useEffect } from 'react';
import Hoc from '../Hoc';
import CondsTable from '../../condsTable';
import {
  Button,
  Col,
  Form,
  Input,
  Modal,
  Row,
  Select,
  Spin,
  Cascader,
  message,
  Radio,
  Upload
} from '@mcd/portal-components';
import * as rules from '@/redux/actions/rulesAction';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { onExport, onUpload } from '@/utils/excel';


const key = 'storeCode';

function Store (props) {
  const [visible, setVisible] = useState(false);
  const [modelData, setModelData] = useState([]);
  const [total, setTotal] = useState([]);
  const [loading, setLoading] = useState(false);

  const showTable = useRef(null);
  const selectTable = useRef(null);

  const [pages, setPages] = useState({
    pageNo: 1,
    pageSize: 10
  });

  const [form] = Form.useForm();
  const columns = [
    {
      title: '餐厅编号',
      dataIndex: 'storeCode',
      align: 'center',
      filter: true
    }
  ];
  const modelColumns = [
    {
      title: '餐厅编号',
      dataIndex: 'storeCode',
    }, {
      title: 'ops编号',
      dataIndex: 'opsCode',
    }, {
      title: '价格组编号',
      dataIndex: 'priceTierCode',
    }, {
      title: '餐厅名称',
      dataIndex: 'storeNameCn',
    }, {
      title: '省',
      dataIndex: 'provinceName',
    }, {
      title: '市',
      dataIndex: 'cityName',
    }, {
      title: '县/区',
      dataIndex: 'countyName',
    }
  ];

  useEffect(() => {
    showTable.current?.initSelected();
  }, []);

  const onQuery = async (params) => {
    let fields = form.getFieldsValue();
    if (fields.provinces) {
      fields.provinceCode = fields.provinces[0];
      fields.cityCode = fields.provinces[1];
      fields.countyCode = fields.provinces[2];
      delete fields.provinces;
    }
    setLoading(true);
    const { data } = await props.getStore({
      ...pages,
      ...fields,
      ...params
    });
    setModelData(data.content);
    setTotal(data.total);
    setLoading(false);
  };


  const onSelectModel = () => {
    setVisible(true);
    form?.resetFields()
    onQuery();
  };
  const onDelete = () => {
    let selected = showTable.current.selected;
    if (selected.length === 0) {
      message.warning('请选择');
      return;
    }
    const newData = props.store.storeList.filter(i => !selected.some(j => i[key] === j));

    props.setRulesData({
      ...props.store,
      storeList: newData
    });
    showTable.current?.initSelected();
  };

  const handleSelect = (val) => {
    console.log(val);
  };

  const onDeleteAll = () => {
    props.setRulesData({
      ...props.store,
      storeList: []
    });
  }

  const onPageChange = (page, pageSize) => {
    selectTable.current?.initSelected();
    onQuery({
      pageNo: page,
      pageSize: pageSize
    });
    setPages({
      pageNo: page,
      pageSize: pageSize
    });
  };
  const onOk = () => {
    const selectData = selectTable.current.selectedRow;
    if (selectData.length === 0) {
      message.warning('请选择至少一个');
      return;
    }
    const res = selectTable.current.compareArr(props.store.storeList, selectData, key);
    if (res.length < (selectData.length + props.store.storeList.length)) {
      message.warning('存在');
    }
    props.setRulesData({
      ...props.store,
      storeList: res.map(i => ({ storeCode: i.storeCode }))
    });
    setVisible(false);
  };

  const selectModel = () => {
    return <Modal
      title='选择餐厅'
      centered
      visible={visible}
      onOk={onOk}
      onCancel={() => setVisible(false)}
      width={1000}
    >
      <Spin spinning={loading}>

        <Form
          form={form}
          layout='vertical'
          onFinish={val => onPageChange(1, 10)}
        >
          <Row gutter={24}>
            <Col span={8}>
              <Form.Item name='store' label={`餐厅编号/名称`}>
                <Input placeholder='餐厅编号/名称' />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item name='opsCode' label={`OPS编号`}>
                <Input placeholder='OPS编号' />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item name='priceTierCode' label={`价格组编号`}>
                <Input placeholder='价格组编号' />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item name='provinces' label={`省市区`}>
                <Cascader
                  placeholder='请选择'
                  onChange={handleSelect}
                  style={{ width: '100%' }}
                  changeOnSelect
                />
              </Form.Item>
            </Col>
          </Row>
          <Row>
            <Col span={24} style={{ textAlign: 'right' }}>
              <Button type='primary' htmlType='submit'>查询</Button>
              <Button style={{ margin: '0 8px' }} onClick={() => form.resetFields()}>重置</Button>
            </Col>
          </Row>
        </Form>

        <CondsTable
          ref={selectTable}
          rowKey={row => row[key]}
          columns={modelColumns}
          data={modelData}
          isShowRowSelect={true}
          total={total}
          onPageChange={onPageChange}
          isControlled={true}
          current={pages.pageNo}
          pageSize={pages.pageSize}
        >
        </CondsTable>
      </Spin>
    </Modal>;
  };

  const onChoose = e => {
    props.setRulesData({
      ...props.store,
      type: e.target.value
    });
  };

  const handleExport = () => {
    onExport([{ storeCode: '' }], 'storeCode');
  };

  const handleUpload = async (e) => {
    onUpload(e.target.files, (res) => {
      if (res.length === 0) {
        message.warning('excel无数据或模版不对');
      } else {
        try {
          let obj = {};
          //  去重
          let uploadData = res.reduce((cur, next) => {
            obj[next.storeCode] ? '' : obj[next.storeCode] = true && cur.push(next);
            return cur;
          }, []).map(i => ({ storeCode: i['storeCode'].toString().trim() }));

          const result = showTable.current.compareArr(props.store.storeList, uploadData, key);
          if (result.length < (uploadData.length + props.store.storeList.length)) {
            message.warning('已智能过滤重复数据');
          }
          props.setRulesData({
            ...props.store,
            storeList: result.map(i => ({ storeCode: i.storeCode }))
          });
        } catch (e) {
          message.warning('导入失败');
        }
      }
    });
  };


  return (
    <div>
      <div>{props.children}</div>
      {
        props.checked && <div className='conditions-common-style'>
          <Radio.Group onChange={onChoose} value={props.store.type}>
            <Radio value={1}>包含</Radio>
            <Radio value={2}>排除</Radio>
          </Radio.Group>

          <div>
            <div style={{ padding: '10px 0', display: 'flex', alignItems: 'center' }}>
              <Button type='primary' onClick={onSelectModel}>选择</Button>
              <Button type='primary' danger onClick={onDelete}>删除选中</Button>
              <Button type='primary' danger onClick={onDeleteAll}>全部删除</Button>
              <Button onClick={handleExport}>下载模版</Button>
              <Button>
                导入
                <input type='file' onChange={handleUpload} onClick={e => e.target.value = ''}
                  style={{
                    width: '80px',
                    height: '26px',
                    position: 'absolute',
                    top: '0',
                    right: '0',
                    cursor: 'pointer',
                    fontSize: 0,
                    opacity: 0
                  }} /></Button>
            </div>
            <CondsTable
              ref={showTable}
              rowKey={row => row[key]}
              columns={columns}
              bordered
              data={props.store.storeList}
              total={props.store.storeList.length}
              isShowRowSelect={true}
            >
            </CondsTable>
          </div>
        </div>
      }

      {visible && selectModel()}
    </div>
  );
}

const mapDispatchToProps = (dispatch) => (
  {
    setRulesData: (params) => {
      dispatch(rules.setStore(params));
    }
  }
);

const mapStateToProps = (state, ownProps) => {
  return {
    store: state.rules.store
  };
}
  ;

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(Hoc(Store))
);