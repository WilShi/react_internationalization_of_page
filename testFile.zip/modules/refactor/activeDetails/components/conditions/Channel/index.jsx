/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect, useState } from 'react';
import Hoc from '../Hoc';
import { Checkbox, Row, Col, Radio } from '@mcd/portal-components';
import Api from '@/api/point/index';
import * as rules from '@/redux/actions/rulesAction';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';

const local = localStorage.getItem('locale');

function Channel(props) {
  // console.log('propsChannel: ', props);

  const [data, setData] = useState([]);

  useEffect(() => {
    init();
  }, []);

  const init = async () => {
    const { data } = await props.getChannel();
    setData(data);
  };

  const onChoose = e => {
    props.setRulesData({
      ...props.channel,
      type: e.target.value
    });
  };

  const onChange = val => {
    props.setRulesData({
      ...props.channel,
      channelList: val.map(i => ({ channel: i }))
    });
  };

  return (
    <div>
      <div>{props.children}</div>

      {
        props.checked && <div className='conditions-common-style'>
          <Radio.Group onChange={onChoose} value={props.channel.type}>
            <Radio value={1}>包含</Radio>
            <Radio value={2}>排除</Radio>
          </Radio.Group>

          <div style={{ margin: '10px 0' }}>
            <Checkbox.Group
              style={{ width: '100%' }}
              value={props.channel.channelList.map(i => i.channel)}
              onChange={onChange}
            >
              <Row>
                {data?.map((i, index) => (
                  <Col span={6} key={index}>
                    <Checkbox value={i.dictValue}>
                      {local === 'cn' ? i.dictLabelCn : i.dictLabelEn}
                    </Checkbox>
                  </Col>
                ))}
              </Row>
            </Checkbox.Group>
          </div>
        </div>
      }
    </div>
  );
}


const mapDispatchToProps = (dispatch) => (
{
  setRulesData: (params) => {
    dispatch(rules.setChannel(params));
  }
}
);

const mapStateToProps = (state, ownProps) =>
{
  return {
    channel: state.rules.channel
  };
}
;

export default withRouter(
connect(mapStateToProps, mapDispatchToProps)(Hoc(Channel))
);
