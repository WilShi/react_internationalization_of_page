import React from 'react';
import {
  Typography, Checkbox
} from '@mcd/portal-components';

import {Conds} from '../conditions';

const {Title} = Typography;

const eventTypeMap = {
  1: 'OMS下单',
  2: '注册',
  3: '推荐注册',
  4: '添加小会员',
  5: 'ECS下单',
  6: '会员登录'
};


function Second(props) {

  const onChange = (e, index) => {
    props.onChange(e.target.checked, index);
  };

  return (
    <div style={{padding: '20px 30px'}}>
      <Title level={4}>活动类型</Title>
      <div>{eventTypeMap[props?.eventType]}</div>


      <Title level={4}>规则条件</Title>

      {
        props.checkStatus.map((i, index) => {
          switch (i.condition) {
            case '1':
              return <Conds.Somebody key={i.condition} {...i}>
                <Checkbox
                  style={{margin: '8px 0'}}
                  checked={i.checked}
                  onChange={e => onChange(e, index)}
                >条件{index+1}：指定人群下单</Checkbox>
              </Conds.Somebody>;
            case '2':
              return <Conds.Store key={i.condition} {...i}>
                <Checkbox
                  style={{margin: '8px 0'}}
                  checked={i.checked}
                  onChange={e => onChange(e, index)}
                >条件{index + 1}：指定餐厅{eventTypeMap[props?.eventType]}</Checkbox>
              </Conds.Store>;
            case '3':
              return <Conds.Channel key={i.condition} {...i}>
                <Checkbox
                  style={{margin: '8px 0'}}
                  checked={i.checked}
                  onChange={e => onChange(e, index)}
                >条件{index + 1}：指定渠道{eventTypeMap[props?.eventType]}</Checkbox>
              </Conds.Channel>;
            case '4':
              return <Conds.BeType key={i.condition} {...i}>
                <Checkbox
                  style={{margin: '8px 0'}}
                  checked={i.checked}
                  onChange={e => onChange(e, index)}
                >条件{index + 1}：{$t(/*订单符合指定BeType*/ 'assign_beType')}</Checkbox>
              </Conds.BeType>;
            case '5':
              return <Conds.Goods key={i.condition} {...i}>
                <Checkbox
                  style={{margin: '8px 0'}}
                  checked={i.checked}
                  onChange={e => onChange(e, index)}
                >条件{index + 1}：{$t(/*购买指定商品*/ 'assign_product')}</Checkbox>
              </Conds.Goods>;
            case '6':
              return <Conds.Tender key={i.condition} {...i}>
                <Checkbox
                  style={{margin: '8px 0'}}
                  checked={i.checked}
                  onChange={e => onChange(e, index)}
                >条件{index + 1}：{$t(/*使用指定Tender*/ 'assign_tender')}</Checkbox>
              </Conds.Tender>;
            case '7':
              return <Conds.TimeQuantum key={i.condition} {...i}>
                <Checkbox
                  style={{margin: '8px 0'}}
                  checked={i.checked}
                  onChange={e => onChange(e, index)}
                >条件{index + 1}：{$t(/*指定时段内下单*/ 'assign_datePeriod')}</Checkbox>
              </Conds.TimeQuantum>;
            case '8':
              return <Conds.Date key={i.condition} {...i}>
                <Checkbox
                  style={{margin: '8px 0'}}
                  checked={i.checked}
                  onChange={e => onChange(e, index)}
                >条件{index + 1}：{$t(/*指定日期下单*/ 'assign_intervalPeriod')}</Checkbox>
              </Conds.Date>;
            case '9':
              return <Conds.Amount key={i.condition} {...i}>
                <Checkbox
                  style={{margin: '8px 0'}}
                  checked={i.checked}
                  onChange={e => onChange(e, index)}
                >条件{index + 1}：{$t(/*订单支付满指定金额*/ 'assign_amount')}</Checkbox>
              </Conds.Amount>;
            case '10':
              return <Conds.Coupon key={i.condition} {...i}>
                <Checkbox
                  style={{margin: '8px 0'}}
                  checked={i.checked}
                  onChange={e => onChange(e, index)}
                >条件{index + 1}：{$t(/*订单使用指定优惠券*/ 'assign_coupon')}</Checkbox>
              </Conds.Coupon>;
            case '11':
              return <Conds.EquityCard key={i.condition} {...i}>
                <Checkbox
                  style={{margin: '8px 0'}}
                  checked={i.checked}
                  onChange={e => onChange(e, index)}
                >条件{index + 1}：{$t(/*订单使用指定权益卡*/ 'assign_card')}</Checkbox>
              </Conds.EquityCard>;
            case '12':
              return <Conds.Point key={i.condition} {...i}>
                <Checkbox
                  style={{margin: '8px 0'}}
                  checked={i.checked}
                  onChange={e => onChange(e, index)}
                >条件{index + 1}：会员累计积分值</Checkbox>
              </Conds.Point>;
          }
        })
      }
    </div>
  );
}

export default Second;