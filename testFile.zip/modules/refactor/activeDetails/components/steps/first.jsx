import React, { useState, useRef, useImperativeHandle, forwardRef, useEffect, useMemo} from 'react';
  
import { Form, Row, Col, Input, Radio } from '@mcd/portal-components';

import Api from '@/api/point/index';

const { TextArea } = Input;

function First(props, ref) {
  const getUser = JSON.parse(localStorage.getItem("USER_INFO"));// 获取登录名账号信息
  const [form] = Form.useForm()

  const [params, setParams] = useState({})

  const [ title, setTitle ] = useState('')
  const [ shortDescription, setShortDescription ] = useState('')
  const titleLength = useMemo(() => title?.length || 0, [title])
  const shortDescriptionLength = useMemo(() => shortDescription?.length || 0, [shortDescription])

  useEffect(() => {
    setParams({
      eventType: props?.basicInfo?.eventType ?? 1,
      title: props?.basicInfo?.title,
      shortDescription: props?.basicInfo?.shortDescription,
      description: props?.basicInfo?.description,
      pointRuleId: props?.basicInfo?.pointRuleId ?? sessionStorage.getItem('activityId'),
      levelNo: props?.basicInfo?.levelNo ?? sessionStorage.getItem('levelNo'),
      operationUser: getUser.nickName,
    })
    setTitle(props?.basicInfo?.title)
    setShortDescription(props?.basicInfo?.shortDescription)
  }, [props.basicInfo]);

  useEffect(() => {
    form.setFieldsValue(params)
  }, [params])

  // 暴露出去的方法
  useImperativeHandle(ref, () => ({
    onNext: async () => {
      await form.validateFields()
      let paramsProp = form.getFieldValue()
      paramsProp.pointRuleId = props?.basicInfo?.pointRuleId ?? sessionStorage.getItem('activityId')
      paramsProp.levelNo = props?.basicInfo?.levelNo ?? sessionStorage.getItem('levelNo')
      paramsProp = { ...params, ...paramsProp }
      setParams(paramsProp)
      const data = await Api.createBasicInfo(paramsProp)
      return data
    },
  }));

  return (
    <div className="common-edit">
      <Form layout="vertical" form={form} initialValues={params}>
        <Row>
          <Col span={24}>
            <Form.Item
              label={$t(/*事件类型*/ 'event_type')}
              name="eventType"
              rules={[{ required: true, message: `${$t('promotion_select_tip')} ${$t('event_type')}` }]}>
              <Radio.Group disabled={params.pointRuleId}>
                <Radio value={1}>OMS下单</Radio>
                <Radio value={2}>注册</Radio>
                <Radio value={3} disabled>推荐注册</Radio>
                <Radio value={4} disabled>添加小会员</Radio>
                <Radio value={5}>ECS下单</Radio>
                <Radio value={6}>会员登录</Radio>
              </Radio.Group>
            </Form.Item>
          </Col>
        </Row>
        <Row>
          <Col span={24}>
            <Form.Item
              label={$t(/*会员活动名称*/ 'member_activity_name') + '（' + $t(/*已输入${n}字*/ 'inputted').replace('${n}',`${titleLength}/32`) + '）'}
              name="title"
              rules={[{ required: true, message: $t('promotion_name_input_tip') }]}>
              <Input className="input" maxLength={32} onChange={e => setTitle(e.target.value)}/>
            </Form.Item>
          </Col>
        </Row>
        <Row>
          <Col span={24}>
            <Form.Item
              label={'会员活动描述' + '（' + $t(/*已输入${n}字*/ 'inputted').replace('${n}',`${shortDescriptionLength}/32`) + '）'}
              name="shortDescription">
              <TextArea className="textArea" maxLength={32} rows={2} onChange={e => setShortDescription(e.target.value)}/>
            </Form.Item>
          </Col>
        </Row>
        <Row>
          <Col span={24}>
            <Form.Item
              label={'活动规则地址'}
              name="description">
              <TextArea className="textArea" maxLength={2000} rows={6}/>
            </Form.Item>
          </Col>
        </Row>
      </Form>
    </div>
  )

}

export default forwardRef(First)
