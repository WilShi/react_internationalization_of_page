import React, { useState, useRef, useImperativeHandle, forwardRef, useEffect, } from 'react';
import { Row, Col, DatePicker, Checkbox, InputNumber, Divider, message, Modal } from '@mcd/portal-components';
import { ExclamationCircleOutlined } from '@ant-design/icons';
import moment from 'moment';
import { Rewards } from '../../activityReward'
import { Limits } from '../../limits'
import './index.less'
import Api from '@/api/point/index';

const { confirm } = Modal;
const { RangePicker } = DatePicker
const dateFormat = 'YYYY-MM-DD'
const eventTypeMap = {
  1: 'OMS下单',
  2: '注册',
  3: '推荐注册',
  4: '添加小会员',
  5: 'ECS下单',
  6: '会员登录'
};

function Third (props, ref) {
  const getUser = JSON.parse(localStorage.getItem("USER_INFO"));// 获取登录名账号信息
  const pointRef = useRef()
  const couponRef = useRef()
  const equityRef = useRef()
  const hitCountRef = useRef()
  const consumeSumRef = useRef()
  const everyCountRef = useRef()
  const productRangeRef = useRef()
  const [ruleCoupon, setRuleCoupon] = useState(null)
  const [ruleCard, setRuleCard] = useState(null)
  const [personTime, setPersonTime] = useState([])
  const [userTime, setUserTime] = useState([])
  const [ranChecked, setRanChecked] = useState(false)
  const [ranValue, setRanValue] = useState('5')
  const [initFrequency, setInitFrequency] = useState({})
  const [limitQty, setLimitQty] = useState({
    1: '',
    2: '',
    3: '',
    4: '',
    5: '',
    6: '',
    7: '',
    8: ''
  })
  const [rewardsChecked, setRewardsChecked] = useState({
    'coupon': false,
    'equity': false,
    'point': false
  })
  const [limitsChecked, setLimitsChecked] = useState({
    'hitCount': false,
    'consumeSum': false,
    'everyCount': false,
    'productRange': false,
    'hitCountDisabled': false,
    'consumeDisabled': false,
    'everyCountDisabled': false,
    'productRangeDisabled': false,
  })
  const [params, setParams] = useState({
    levelNo: '',
    operationUser: getUser.nickName,
    pointRuleId: '',
    startTime: '', // 活动时间-开始时间
    endTime: '', // 活动时间-结束时间
    activityRestrictionsList: []// 活动频次,
  })
  const personTimeList = [{
    type: '1', text: '设置活动最大参与人次'
  },
  {
    type: '2', text: '设置每天最大参与人次'
  },
  {
    type: '3', text: '设置每周最大参与人次'
  },
  {
    type: '4', text: '设置每月最大参与人次'
  }]

  const userTimeList = [{
    type: '5', text: '同一用户最大参与次数'
  },
  {
    type: '6', text: '同一用户每日参与次数'
  },
  {
    type: '7', text: '同一用户每周参与次数'
  },
  {
    type: '8', text: '同一用户每月参与次数'
  },
  {
    type: '9', text: '相同手机号用户不可重复参与活动'
  }]


  useEffect(() => {
    // 初始化数据
    let userTimeTep = []
    let personTimeTep = []
    let limitQtyTep = {}
    props?.reviewInfo?.activityFrequencyList?.forEach(item => {
      if (item.type >= 1 && item.type <= 4) {
        personTimeTep.push(item.type + '')
      } else if (item.type >= 5 && item.type <= 9) {
        userTimeTep.push(item.type + '')
      } else if (item.type == 10) {
        setRanChecked(true)
        setRanValue(item.limitQty)
      }
      limitQtyTep[item.type] = item.limitQty
    })

    setInitFrequency(limitQtyTep)
    setLimitQty({ ...limitQtyTep })
    let startTimeTep = props?.reviewInfo?.pointRule?.startTime ? moment(props?.reviewInfo?.pointRule?.startTime).format('YYYY-MM-DD HH:mm:ss') : ''
    let endTimeTep = props?.reviewInfo?.pointRule?.endTime ? moment(props?.reviewInfo?.pointRule?.endTime).format('YYYY-MM-DD HH:mm:ss') : ''
    setPersonTime(personTimeTep)
    setUserTime(userTimeTep)
    setRewardsChecked({
      'coupon': props?.reviewInfo?.ruleCoupon ? true : false,
      'equity': props?.reviewInfo?.ruleCard ? true : false,
      'point': props?.reviewInfo?.ruleExpireType || props?.reviewInfo?.ruleGrantType ? true : false
    })
    // 奖励限制回显
    setLimitsChecked({
      'hitCount': props?.reviewInfo?.rewardLimit?.maxCount ? true : false,
      'consumeSum': props?.reviewInfo?.rewardLimit?.maxAmount ? true : false,
      'everyCount': props?.reviewInfo?.rewardLimit?.everyCount ? true : false,
      'productRange': props?.reviewInfo?.rewardLimit?.maxGoodsCount ? true : false,
      'hitCountDisabled': props?.reviewInfo?.rewardLimit?.maxCount ? true : false,
      'consumeDisabled': props?.reviewInfo?.rewardLimit?.maxAmount ? true : false,
      'everyCountDisabled': props?.reviewInfo?.rewardLimit?.everyCount ? true : false,
      'productRangeDisabled': props?.reviewInfo?.rewardLimit?.maxGoodsCount ? true : false,
    })

    setParams({
      ...{
        startTime: startTimeTep,
        endTime: endTimeTep,
        levelNo: props?.reviewInfo?.pointRule?.levelNo,
        pointRuleId: props?.reviewInfo?.pointRule?.pointRuleId
      }
    })
    setRuleCard(props.reviewInfo.ruleCard)
    setRuleCoupon(props.reviewInfo.ruleCoupon)
  }, [props.reviewInfo])

  // 暴露出去的方法
  useImperativeHandle(ref, () => ({
    onNext: async () => {
      // 活动频次
      let checkLimit = personTime.concat(userTime)
      let activityRestrictionsList = []
      for (let i = 0; i < checkLimit.length; i++) {
        if (checkLimit[i] != 9 && !limitQty[checkLimit[i]]) {
          message.warning('请完善人次限制！')
          return
        }
        activityRestrictionsList.push({
          limitQty: checkLimit[i] != 9 ? limitQty[checkLimit[i]] : 0,
          type: checkLimit[i],
          used: 1
        })
      }
      // 随机对照实验
      if (ranChecked) {
        if (!ranValue) {
          return message.warning('请完善实验组分流比例！')
        } else {
          activityRestrictionsList.push({
            limitQty: ranValue,
            type: '10',
            used: 1
          })
        }
      }
      // 活动奖励
      let pointClass = rewardsChecked['point'] ? pointRef.current.pointClassParams() : {}
      let couponClass = rewardsChecked['coupon'] ? ruleCoupon : {}
      let equityClass = rewardsChecked['equity'] ? ruleCard : {}
      let count = limitsChecked['hitCount'] ? hitCountRef.current : {}
      let amount = limitsChecked['consumeSum'] ? consumeSumRef.current : {}
      let everyCount = limitsChecked['everyCount'] ? everyCountRef.current : {}
      let productRange = limitsChecked['productRange'] ? productRangeRef.current : {}
      let productLimit = limitsChecked['productRange'] ? productRangeRef.current?.productLimit : {}
      let rewardLimit = { ...amount, ...count, ...everyCount, ...productRange }


      let paramsTem = {
        ...params,
        activityRestrictionsList: activityRestrictionsList,
        pointAttribute: pointClass?.pointAttribute,
        pointRuleExpireType: pointClass?.pointRuleExpireType,
        pointRuleGrantType: pointClass?.pointRuleGrantType,
        pointTender: pointClass?.pointTender,
        pointProduct: pointClass?.pointProduct,
        // ...pointClass,
        ruleCoupon: couponClass,
        ruleCard: equityClass,
        rewardLimit,
        productLimit,
        operationUser: getUser.nickName
      }

      // console.log(paramsTem)
      // return

      paramsTem.startTime = paramsTem.startTime ? moment(paramsTem.startTime).format('YYYY-MM-DD') + ' 00:00:00' : ''
      paramsTem.endTime = paramsTem.endTime ? moment(paramsTem.endTime).format('YYYY-MM-DD') + ' 23:59:59' : ''
      setParams(paramsTem)

      // 必填校验
      if (!validatePointClass(paramsTem)) {
        return
      }


      if (paramsTem.pointRuleGrantType?.type == 1 || paramsTem.pointRuleGrantType?.type == 2) {
        paramsTem.pointProduct = null
      }
      if (paramsTem.pointRuleGrantType?.type == 1 || paramsTem.pointRuleGrantType?.type == 3) {
        paramsTem.pointTender = null
      }



      const data = await Api.createCommonInfo(paramsTem)
      return data
    },
  }));

  const validatePointClass = (paramsTem) => {
    if (!rewardsChecked['point'] && !rewardsChecked['coupon'] && !rewardsChecked['equity']) {
      message.warning('至少选择一个活动奖励')
      return false
    }
    if (rewardsChecked['point']) {
      if (!paramsTem.pointRuleGrantType || !paramsTem.pointRuleGrantType.type) {
        message.warning('至少选择一个发放方式')
        return false
      }

      if (!paramsTem.pointRuleGrantType.pointNum || !paramsTem.pointRuleGrantType.pointType || !paramsTem.pointRuleGrantType.pointTypeName) {
        message.warning('请完善发放方式')
        return false
      }
      if (paramsTem.pointRuleGrantType.type == 2 && !paramsTem.pointRuleGrantType.amount) {
        message.warning('请完善发放方式')
        return false
      }

      if (!paramsTem.pointRuleExpireType || !paramsTem.pointRuleExpireType.type) {
        message.warning('至少选择一个过期方式')
        return false
      }

      if ((paramsTem.pointRuleExpireType.type == 1 || paramsTem.pointRuleExpireType.type == 2) && !paramsTem.pointRuleExpireType.num) {
        message.warning('请完善过期方式')
        return false
      }
      if (paramsTem.pointRuleExpireType.type == 3 && !paramsTem.pointRuleExpireType.expireDate) {
        message.warning('请完善过期方式')
        return false
      }

      if (!paramsTem.pointAttribute) {
        message.warning('至少选择一个财务结算方式')
        return false
      }
    }
    if (rewardsChecked['coupon']) {
      if (!paramsTem.ruleCoupon?.ruleCouponList.length) {
        message.warning('请选择优惠券')
        return false
      }
      if (paramsTem.ruleCoupon.type == 2) {
        let flag = true
        for (let i = 0; i < paramsTem.ruleCoupon.ruleCouponList.length; i++) {
          if (!paramsTem.ruleCoupon.ruleCouponList[i].couponNumber) {
            flag = false
            message.warning('请填写优惠券发放张数')
            return
          }
        }
        return flag
      }
    }
    if (rewardsChecked['equity'] && !paramsTem.ruleCard?.ruleCardList.length) {
      message.warning('请选择权益卡')
      return false
    }
    if (!paramsTem.startTime && !paramsTem.endTime) {
      message.warning('请填写活动时间')
      return false
    }
    if (limitsChecked['hitCount'] && (!paramsTem.rewardLimit?.maxCount || !paramsTem.rewardLimit?.minCount)) {
      message.warning('请填写奖励发放限制')
      return false
    }
    if (limitsChecked['consumeSum'] && (!paramsTem.rewardLimit?.maxAmount || !paramsTem.rewardLimit?.minAmount)) {
      message.warning('请填写奖励发放限制')
      return false
    }
    if (limitsChecked['everyCount'] && !paramsTem.rewardLimit?.everyCount) {
      message.warning('请填写奖励发放限制')
      return false
    }
    if (limitsChecked['productRange'] && (!paramsTem.rewardLimit?.maxGoodsCount || !paramsTem.rewardLimit?.minGoodsCount)) {
      message.warning('请填写奖励发放限制')
      return false
    }
    return true
  }

  const onChangeActivityTime = (date, dateString) => {
    setParams({ ...params, ...{ startTime: dateString[0], endTime: dateString[1] } })
  }

  const onChangePersonTime = (e) => {
    setPersonTime(e)
  }

  const onChangeUserTime = (e) => {
    console.log('e', e);
    setUserTime(e)
  }

  const onChangePersonTimeQty = (type, val) => {
    setLimitQty({ ...limitQty, ...{ [type]: val } })
  }

  const onChangeUserTimeQty = (type, val) => {
    setLimitQty({ ...limitQty, ...{ [type]: val } })
  }

  const onChangeRewards = (e, key) => {
    setRewardsChecked({ ...rewardsChecked, ...{ [key]: e.target.checked } })
  }
  const onChangeLimits = (e, key) => {
    setLimitsChecked({ ...limitsChecked, ...{ [key]: e.target.checked } })
  }

  const disabledDate = (current) => {
    return current && ((moment(current).year() < moment().format("YYYY")) || (moment(current).year() > moment().add(2, 'y').format("YYYY")))
  }

  const onSetCoupon = (val) => {
    setRuleCoupon(val)
  }
  const onSetCard = (val) => {
    setRuleCard(val)
  }
  const openExperiment = (e) => {

    console.log(params.levelNo)
    if (params.levelNo !== 1) {
      // v2及以上版本
      confirm({
        title: ' ',
        icon: <ExclamationCircleOutlined />,
        content: '关闭随机试验后不可再次启动，确认关闭吗？',
        onOk () {
          setRanChecked(false)
        },
        onCancel () {
          console.log('Cancel');
        },
      });
    } else {
      if (e.target.checked) {
        setPersonTime([])
        setUserTime(['5'])
        setLimitQty({ 5: '1' })
      }
      setRanChecked(e.target.checked)
    }
  }

  return (
    <div className="third-container">
      <Row>
        <Col span={24}>
          <p className="title">活动奖励</p>
          <div className="ml-20">
            <Rewards.CouponClass ref={couponRef} ruleCoupon={props.reviewInfo.ruleCoupon}
              eventType={props.reviewInfo?.pointRule?.eventType} checked={rewardsChecked['coupon']}
              onSetCoupon={onSetCoupon}>
              <Checkbox checked={rewardsChecked['coupon']}
                onChange={(e) => onChangeRewards(e, 'coupon')}>优惠券类</Checkbox>
            </Rewards.CouponClass>
            <Rewards.EquityClass ref={equityRef} ruleCard={props.reviewInfo.ruleCard}
              eventType={props.reviewInfo?.pointRule?.eventType} checked={rewardsChecked['equity']}
              onSetCard={onSetCard}>
              <Checkbox checked={rewardsChecked['equity']}
                onChange={(e) => onChangeRewards(e, 'equity')}>权益卡类</Checkbox>
            </Rewards.EquityClass>
            <Rewards.PointClass ref={pointRef} reviewInfo={props.reviewInfo}
              eventType={props.reviewInfo?.pointRule?.eventType} checked={rewardsChecked['point']}>
              <Checkbox checked={rewardsChecked['point']}
                onChange={(e) => onChangeRewards(e, 'point')}>Point类</Checkbox>
            </Rewards.PointClass>
          </div>
        </Col>
      </Row>
      <Divider />
      <Row>
        <Col span={8}>
          <p className="title"><span className="col-red">* </span>活动时间</p>
          <RangePicker className="ml-20" disabledDate={disabledDate} format={dateFormat}
            value={[params.startTime ? moment(params.startTime, dateFormat) : '', params.endTime ? moment(params.endTime, dateFormat) : '']}
            onChange={onChangeActivityTime} />
        </Col>
      </Row>
      <Divider />
      {
        // oms下单或者ecs下单才有奖励限制
        (props.reviewInfo?.pointRule?.eventType == 1 || props.reviewInfo?.pointRule?.eventType == 5) &&
        <>
          <Row>
            <Col span={24}>
              <p className="title">奖励发放限制</p>
              <div className="ml-20">
                <Limits.HitCount ref={hitCountRef} reviewInfo={props.reviewInfo} checked={limitsChecked['hitCount']}>
                  <Checkbox checked={limitsChecked['hitCount']}
                    onChange={(e) => onChangeLimits(e, 'hitCount')} disabled={limitsChecked['hitCountDisabled']}>用户累计命中N次发放</Checkbox>
                </Limits.HitCount>
                <Limits.ConsumeSum ref={consumeSumRef} reviewInfo={props.reviewInfo}
                  checked={limitsChecked['consumeSum']}>
                  <Checkbox checked={limitsChecked['consumeSum']}
                    onChange={(e) => onChangeLimits(e, 'consumeSum')} disabled={limitsChecked['consumeDisabled']}>用户累计消费金额满M元发放</Checkbox>
                </Limits.ConsumeSum>
                <Limits.EveryCount ref={everyCountRef} reviewInfo={props.reviewInfo}
                  checked={limitsChecked['everyCount']}>
                  <Checkbox checked={limitsChecked['everyCount']}
                    onChange={(e) => onChangeLimits(e, 'everyCount')} disabled={limitsChecked['everyCountDisabled']}>用户每命中X次发放</Checkbox>
                </Limits.EveryCount>
                <Limits.ProductRange ref={productRangeRef} reviewInfo={props.reviewInfo}
                  checked={limitsChecked['productRange']}>
                  <Checkbox checked={limitsChecked['productRange']}
                    onChange={(e) => onChangeLimits(e, 'productRange')} disabled={limitsChecked['productRangeDisabled']}>用户累计购买Y个商品发放</Checkbox>
                </Limits.ProductRange>
              </div>
            </Col>
          </Row>
          <Divider />
          <Row>
            <Col span={24}>
              <p className="title">随机对照实验</p>
              <div className="ml-20">
                <Checkbox checked={ranChecked} disabled={
                  params.levelNo !== 1 && !ranChecked
                }
                  onChange={e => openExperiment(e)}>开启随机对照试验</Checkbox>
                {
                  ranChecked && <div>
                    实验组分流比例：
                    <InputNumber min={1} max={99} value={ranValue} onChange={(e) => setRanValue(e)}
                      step="1" precision={2} /> %
                  </div>
                }
                <p style={{ color: 'red' }}>注：开启后每个会员只能命中1次本活动，进入实验组的会员命中活动但不发放奖励。</p>
              </div>
            </Col>
          </Row>
          <Divider />
        </>
      }
      <Row>
        <Col span={16}>
          <p className="title">活动人次限制</p>
          <Checkbox.Group className="ml-20" value={personTime} onChange={onChangePersonTime}>
            {personTimeList.map(item => {
              return (
                <Row className="mb-10" key={item.type}>
                  <Col>
                    <Checkbox value={item.type} disabled={(params.levelNo !== 1 && initFrequency[item.type]) || ranChecked}>{item.text}：</Checkbox>
                  </Col>
                  <Col>
                    <InputNumber min={1} max={1000000000} value={limitQty[item.type]}
                      onChange={(e) => onChangePersonTimeQty(item.type, e)} disabled={ranChecked} />
                  </Col>
                </Row>
              )
            })}
          </Checkbox.Group>
        </Col>
      </Row>
      <Divider />
      <Row>
        <Col span={16}>
          <p className="title">用户参与限制</p>
          <Checkbox.Group className="ml-20" value={userTime} onChange={onChangeUserTime}>
            {userTimeList.map(item => {
              return (
                props.reviewInfo?.pointRule?.eventType != 6 ? <Row className="mb-10" key={item.type}>
                  <Col>
                    <Checkbox value={item.type} disabled={initFrequency[item.type]}>{item.text}{item.type != 9 ? '：' : ''}</Checkbox>
                  </Col>
                  {item.type != 9 && <Col>
                    <InputNumber min={1} max={1000} value={limitQty[item.type]}
                                 onChange={(e) => onChangeUserTimeQty(item.type, e)}/>
                  </Col>}
                </Row> : item.type != 9 && <Row className="mb-10" key={item.type}>
                  <Col>
                    <Checkbox value={item.type} disabled={(params.levelNo !== 1 && initFrequency[item.type]) || ranChecked}>{item.text}{item.type != 9 ? '：' : ''}</Checkbox>
                  </Col>
                  {item.type != 9 && <Col>
                    <InputNumber min={1} max={1000} value={limitQty[item.type]}
                      onChange={(e) => onChangeUserTimeQty(item.type, e)} disabled={ranChecked} />
                  </Col>}
                </Row>
              )
            })}
          </Checkbox.Group>
        </Col>
      </Row>
      <Divider />
      <Row gutter={30}>
        <Col span={16}>
          <p className="title">发布方式</p>
          <p className="ml-20">审核后自动发布</p>
        </Col>
      </Row>
    </div>
  )
}

export default forwardRef(Third)
