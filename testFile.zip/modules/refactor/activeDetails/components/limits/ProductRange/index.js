import React, { useState, useImperativeHandle, forwardRef, useRef } from 'react';
import { Badge, InputNumber, message, Modal } from '@mcd/portal-components';
import Product from '../../activityReward/user-defined/product';

function ProductRange(props, ref) {
  console.log('发放奖励',props)
  const [rewardLimit, setRewardLimit] = useState(props?.reviewInfo?.rewardLimit ?? {})
  const [visiblePro, setVisiblePro] = useState(false)
  const [productLimit, setProductLimit] = useState(props?.reviewInfo?.productLimit)

  const productRef = useRef()

  const onChange = (value, key) => {
    const newData = {
      ...rewardLimit,
      [key]: value
    };
    setRewardLimit(newData);
  }


  useImperativeHandle(ref, () => ({
    maxGoodsCount: rewardLimit.maxGoodsCount,
    minGoodsCount: rewardLimit.minGoodsCount,
    productLimit
  }))

  const onSavePro = () => {
    console.log('productRef.current.refs.pointProduct', productRef.current.refs.pointProduct)
    setProductLimit(productRef.current.refs.pointProduct)
    setVisiblePro(false)
  }

  const ModalProduct = () => {
    return <Modal
      title="自定义配置"
      centered
      visible={visiblePro}
      onOk={onSavePro}
      onCancel={() => setVisiblePro(false)}
      width={800}
    >
      <Product ref={productRef} pointProduct={productLimit} hiddenTop></Product>
    </Modal>
  }

  return (
    <div style={{marginTop: '20px'}}>
      <div>{props.children}</div>

      {
        props.checked &&
        <div style={{margin: '20px 30px'}}>
          <span style={{margin: '0 5px'}}>购买</span>
          <InputNumber
            style={{width: 100}}
            value={rewardLimit.minGoodsCount}
            onChange={val => onChange(val, 'minGoodsCount')}
            precision={0}
            min={1}
            max={99999}
          />
          <span style={{margin: '0 5px'}}>～</span>
          <InputNumber
            style={{width: 100}}
            value={rewardLimit.maxGoodsCount}
            onChange={val => onChange(val, 'maxGoodsCount')}
            precision={0}
            min={rewardLimit.minGoodsCount ?? 1}
            max={99999}
          />
          <span style={{margin: '0 5px'}}>
            个（
            {/*<a onClick={()=>setVisiblePro(true)}>指定商品</a>*/}
             <Badge count={productLimit?.productList.length || '全部'} size="small" offset={[-12, 0]}>
                <a onClick={() => setVisiblePro(true)} style={{marginRight: '30px'}}>指定商品</a>
              </Badge>
            ）发放
          </span>
        </div>
      }

      {ModalProduct()}
    </div>
  );
}

export default forwardRef(ProductRange)