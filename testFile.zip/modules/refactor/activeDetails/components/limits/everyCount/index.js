import React, { useState, useImperativeHandle, forwardRef } from 'react';
import { InputNumber, message } from '@mcd/portal-components';

function EveryCount(props, ref) {
  const [rewardLimit, setRewardLimit] = useState(props?.reviewInfo?.rewardLimit ?? {})

  const onChange = (value) => {
    console.log(value);
    const newData = {
      ...rewardLimit,
      everyCount: value
    };
    setRewardLimit(newData);
  }


  useImperativeHandle(ref, () => ({
    everyCount: rewardLimit.everyCount,
  }))

  return (
    <div style={{marginTop: '20px'}}>
      <div>{props.children}</div>

      {
        props.checked &&
        <div style={{margin: '20px 30px'}}>
          <span style={{margin: '0 5px'}}>每</span>
          <InputNumber
            style={{width: 100}}
            value={rewardLimit.everyCount}
            onChange={val => onChange(val)}
            precision={0}
            min={1}
            max={99999}
          />
          <span style={{margin: '0 5px'}}>次命中发放</span>
        </div>
      }

    </div>
  );
}

export default forwardRef(EveryCount)