import React, { useState, useImperativeHandle, forwardRef } from 'react';
import { InputNumber, message } from '@mcd/portal-components';

function ConsumeSum(props, ref) {
  const [rewardLimit, setRewardLimit] = useState(props?.reviewInfo?.rewardLimit ?? {})

  const onChange = (value, key) => {
    //先把非数字的都替换掉，除了数字和.
    //必须保证第一个为数字而不是.
    //保证只有出现一个.而没有多个.
    //保证.只出现一次，而不能出现两次以上
    const num = value?.toString().replace(/[^\d.]/g, '')?.replace(/^\./g, '')?.replace(/\.{2,}/g, '.').replace('.', '$#$').replace(/\./g, '').replace('$#$', '.');
    const newData = {
      ...rewardLimit,
      [key]: num ? +num : num
    };
    if (newData.maxAmount > 99999.99) {
      newData.maxAmount = 99999.99
    }
    setRewardLimit(newData);
  }


  useImperativeHandle(ref, () => ({
    maxAmount: rewardLimit.maxAmount,
    minAmount: rewardLimit.minAmount
  }))

  return (
    <div style={{marginTop: '20px'}}>
      <div>{props.children}</div>

      {
        props.checked &&
        <div style={{margin: '20px 30px'}}>
          <InputNumber
            style={{width: 100}}
            value={rewardLimit.minAmount}
            step='0.01'
            onChange={val => onChange(val, 'minAmount')}
            precision={2}
            stringMode
            min={0}
            max={99999.99}
          />
          <span style={{margin: '0 5px'}}>元</span>
          <span style={{margin: '0 5px'}}>{`<=`}</span>
          <span>累计消费金额</span>
          <span style={{margin: '0 5px'}}>{`<=`}</span>
          <InputNumber
            style={{width: 100}}
            value={rewardLimit.maxAmount}
            step='0.01'
            onChange={val => onChange(val, 'maxAmount')}
            precision={2}
            stringMode
            min={rewardLimit.minAmount ?? 0}
            max={99999.99}
          />
          <span style={{margin: '0 5px'}}>元</span>
        </div>
      }

    </div>
  );
}

export default forwardRef(ConsumeSum)