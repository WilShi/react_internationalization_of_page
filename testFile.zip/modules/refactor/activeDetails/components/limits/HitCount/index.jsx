import React, {useState, forwardRef, useImperativeHandle} from 'react';
import { InputNumber, message } from '@mcd/portal-components';

function HitCount(props, ref) {

  const [rewardLimit, setRewardLimit] = useState(props?.reviewInfo?.rewardLimit ?? {})

  const onChange = (value, key) => {
    //先把非数字的都替换掉，除了数字和.
    //保证不会出现小数
    const num = value?.toString().replace(/[^\d.]/g, '').replace(/\.\d*/g, '');
    const newData = {
      ...rewardLimit,
      [key]: num ? +num : num
    };
    if (newData.maxCount > 999) {
      newData.maxCount = 999
    }
    setRewardLimit(newData)
  }

  useImperativeHandle(ref, () => ({
    maxCount: rewardLimit.maxCount,
    minCount: rewardLimit.minCount
  }))

  return (
    <div>
      <div>{props.children}</div>

      {
        props.checked &&
        <div style={{margin: '20px 30px'}}>
          <InputNumber
            style={{width: 100}}
            value={rewardLimit.minCount}
            onChange={val => onChange(val, 'minCount')}
            min={0}
            max={999}
          />
          <span style={{margin: '0 5px'}}>次</span>
          <span style={{margin: '0 5px'}}>{`<=`}</span>
          <span>累计命中次数</span>
          <span style={{margin: '0 5px'}}>{`<=`}</span>
          <InputNumber
            style={{width: 100}}
            value={rewardLimit.maxCount}
            onChange={val => onChange(val, 'maxCount')}
            min={rewardLimit.minCount ?? 0}
            max={999}
          />
          <span style={{margin: '0 5px'}}>次</span>
        </div>
      }
    </div>
  );
}

export default forwardRef(HitCount)