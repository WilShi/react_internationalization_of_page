import HitCount from './HitCount'
import ConsumeSum from './ConsumeSum'
import EveryCount from './everyCount';
import ProductRange from './ProductRange';

export const Limits = {
  HitCount,
  ConsumeSum,
  EveryCount,
  ProductRange,
}