import React, { useRef, useState } from 'react';
import { Button, Modal, Input, Form, Space, message } from '@mcd/portal-components';

import Api from '@/api/point/index';

const subscribePackageModal = (props) => {
  const getUser = JSON.parse(localStorage.getItem("USER_INFO"));// 获取登录名账号信息
  const formRef = useRef(null);
  const [isEffective, setIsEffective] = useState(true) // 是否提示CODE无效
  
  const onSubscribe = async () => {
    let params = formRef.current.getFieldsValue()
    params = {
      ...params,
      operationUser: getUser.nickName
    }
    if (!params.crowdCode) {
      message.warning('请输入人群包CODE！')
      return
    }
    if (!params.crowdName) {
      message.warning('请输入人群包名称！')
      return
    }
    const { data } = await Api.subscribeCrowd(params)
    setIsEffective(data)
    if (data) {
      props.onClose()
      props.onRefresh()
    }
  }
  return (
    <Modal
      title={'订阅人群包'}
      visible={props.visible}
      onCancel={() => props.onClose()}
      footer={[
        <Button type="primary" onClick={onSubscribe}>确定</Button>,
        <Button onClick={() => props.onClose()}>取消</Button>
      ]}>
      <Form
        ref={formRef}
        name="basic"
        labelAlign="left"
        labelCol={{ span: 5 }}
        wrapperCol={{ span: 19 }}>
        <Form.Item label="人群包CODE">
          <Space>
            <Form.Item name="crowdCode" noStyle>
              <Input placeholder={'输入人群包CODE'} style={{'width': '200px'}} allowClear/>
            </Form.Item>
            {!isEffective && <span style={{'color': 'red'}}>CODE无效！</span>}
          </Space>
        </Form.Item>
        <Form.Item label="人群包名称" name="crowdName">
          <Input placeholder={'输入人群包名称'} style={{'width': '200px'}} allowClear/>
        </Form.Item>
      </Form>
  </Modal>
  );
};

export default subscribePackageModal;
