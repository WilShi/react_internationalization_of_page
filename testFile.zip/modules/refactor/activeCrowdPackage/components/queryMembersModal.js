import React, { useRef, useState } from 'react';
import { Button, Modal, Input, Form, Space, message } from '@mcd/portal-components';

import Api from '@/api/point/index';

const queryMembersModal = (props) => {
  const formRef = useRef(null);
  const [data, setData] = useState('')

  const onQuery = async () => {
    let params = formRef.current.getFieldsValue()
    params = {
      ...params,
      crowdCode: props.code
    }
    if (!params.customerId) {
      message.warning('请输入会员编号！')
      return
    }
    const { data } = await Api.belongCustomer(params)
    setData(data)
  }
  
  return (
    <Modal
      title={'查询所属会员'}
      visible={props.visible}
      onCancel={() => props.onClose()}
      footer={[
        <Button key="close" onClick={() => props.onClose()}>{$t(/*关闭*/'crm_close')}</Button>
      ]}>
      <Form
        ref={formRef}
        name="basic"
        labelAlign="left"
        labelCol={{ span: 4 }}
        wrapperCol={{ span: 20 }}>
        <Form.Item label="会员编号" >
          <Space>
            <Form.Item name="customerId" noStyle>
              <Input placeholder={'输入会员编号'} style={{'width': '200px'}} allowClear/>
            </Form.Item>
            <Button onClick={onQuery}>查询</Button>
          </Space>
        </Form.Item>
      </Form>
      <div>
       {data === true && <span style={{'color': '#0b8235'}}>查询成功</span>}
       {data === false && <span style={{'color': 'red'}}>当前会员不在本人群包中</span>}
      </div>
  </Modal>
  );
};

export default queryMembersModal;
