import React, { useEffect, useState } from 'react';
import { Button, Modal, Table } from '@mcd/portal-components';

import Api from '@/api/point/index';

const queryMembersModal = (props) => {
  const getUser = JSON.parse(localStorage.getItem("USER_INFO"));// 获取登录名账号信息
  const [activityList, setActivityList] = useState([])
  const columns = [{
    title: '活动名称',
    render: (text, row) => {
      return (
        <span>{row}</span>
      )
    }
  }]

  useEffect(() => {
    getActivityList()
  }, [])

  const getActivityList = async () => {
    const { data } = await Api.getPointRuleName({ crowdCode: props.code })
    if (data && data.length) {
      setActivityList(data)
    }
  }

  const onSure = async () => {
    await Api.cancelCrowd({crowdCode: props.code, operationUser: getUser.nickName})
    props.onClose()
    props.onRefresh()
  }

  return (
    <Modal
      title={'取消订阅'}
      visible={props.visible}
      onCancel={() => props.onClose()}
      footer={!activityList.length ? [
        <Button type="primary" onClick={onSure}>确定</Button>,
        <Button onClick={() => props.onClose()}>取消</Button>
      ] : [
        <Button key="close" onClick={() => props.onClose()}>{$t(/*关闭*/'crm_close')}</Button>
      ]}>
      { activityList.length ? <div>
        <div style={{'color': 'red', 'marginBottom': '10px'}}>当前人群包正在被以下活动使用，无法取消订阅！</div>
        <Table
          rowKey={row => row}
          columns={columns}
          dataSource={activityList}
        />
      </div> : <div>确认取消订阅吗？</div>}
      
  </Modal>
  );
};

export default queryMembersModal;
