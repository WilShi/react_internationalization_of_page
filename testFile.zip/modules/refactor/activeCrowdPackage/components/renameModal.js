import React, { useRef, useState } from 'react';
import { Button, Modal, Input, Form, Space, message } from '@mcd/portal-components';

import Api from '@/api/point/index';

const renameModal = (props) => {
  const getUser = JSON.parse(localStorage.getItem("USER_INFO"));// 获取登录名账号信息
  const formRef = useRef(null);
  const [nameLength, setNameLength] = useState(0)

  const onRename = async () => {
    let params = formRef.current.getFieldsValue()
    params = {
      ...params,
      id: props.id,
      operationUser: getUser.nickName
    }
    if (!params.crowdName) {
      message.warning('请输入新名称！')
      return
    }
    await Api.updateCrowd(params)
    props.onClose()
    props.onRefresh()
  }
  
  return (
    <Modal
      title={'重命名'}
      visible={props.visible}
      onCancel={() => props.onClose()}
      footer={[
        <Button type="primary" onClick={onRename}>确定</Button>,
        <Button onClick={() => props.onClose()}>取消</Button>
      ]}>
      <Form
        ref={formRef}
        name="basic"
        labelAlign="left"
        labelCol={{ span: 4 }}
        wrapperCol={{ span: 20 }}>
        <Form.Item label="新名称" >
          <Space>
            <Form.Item name="crowdName" noStyle>
              <Input placeholder={'输入新名称'} style={{'width': '200px'}} maxLength={10} onChange={(e) => setNameLength(e.target.value.length || 0)} allowClear/>
            </Form.Item>
            <span style={{'marginLeft': '10px'}}>{nameLength}/10</span>
          </Space>
        </Form.Item>
      </Form>
  </Modal>
  );
};

export default renameModal;
