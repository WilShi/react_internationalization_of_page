import React, { useState, useRef, useEffect } from 'react';
  
import { Form, Row, Col, Input, Button, Table, Space } from '@mcd/portal-components';
import { getTableHeight } from '@mcd/portal-components/dist/utils/table';

import Api from '@/api/point/index';
import moment from 'moment'

import SubscribePackageModal from './components/subscribePackageModal'
import RenameModal from './components/renameModal'
import QueryMembersModal from './components/queryMembersModal'
import CancelSubscribeModal from './components/cancelSubscribeModal'

function ActiveCrowdPackage(props, ref) {
  const formRef = useRef(null);
  const [crowdList, setCrowdList] = useState([])
  const [paginationData, setPaginationData] = useState({
    pageNo: 1,
    pageSize: 50,
    total: 0
  })
  const [subscribeVisible, setSubscribeVisible] = useState(false)
  const [renameVisible, setRenameVisible] = useState(false)
  const [queryMembersVisible, setQueryMembersVisible] = useState(false)
  const [cancelVisible, setCancelVisible] = useState(false)
  const [curId, setCurId] = useState('')

  const columns = [
    {
      title: 'CODE',
      dataIndex: 'crowdCode',
    }, {
      title: '人群包名称',
      dataIndex: 'crowdName',
    }, {
      title: '创建人',
      dataIndex: 'createdUser',
    }, {
      title: '创建时间',
      dataIndex: 'createdDate',
      render: text => <span>{text ? moment(new Date(text)).format('YYYY-MM-DD HH:mm') : '-'}</span>
    }, {
      title: '最近更新时间',
      dataIndex: 'updatedDate',
      render: text => <span>{text ? moment(new Date(text)).format('YYYY-MM-DD HH:mm') : '-'}</span>
    }, {
      title: '覆盖会员数',
      dataIndex: 'count',
      render: (text, row) => {
        return (
          <Button type="link" onClick={() => toQueryMembers(row.crowdCode)}>{text}</Button>
        )
      }
    }, {
      title: '操作',
      dataIndex: 'couponId',
      render: (text, row) => {
        return (
          <Space>
            <Button type="link" onClick={() => toRename(row.id)}>重命名</Button>
            {row.synchType !=0 && <Button type="link" onClick={() => toCancel(row.crowdCode)}>取消订阅</Button>}
          </Space>
        )
      }
    }, 
  ]

  useEffect(() => {
    queryCrowdList(1, 50)
  }, [])

  const toRename = (id) => {
    setRenameVisible(true)
    setCurId(id)
  }

  const toQueryMembers = (id) => {
    setQueryMembersVisible(true)
    setCurId(id)
  }

  const toCancel = (id) => {
    setCancelVisible(true)
    setCurId(id)
  }

  const queryCrowdList = async (pageNo = paginationData.pageNo, pageSize = paginationData.pageSize) => {
    let params = formRef.current.getFieldsValue()
    params = {
      pageSize,
      pageNo,
      ...params
    }
    const { data } = await Api.getCrowdListCondition(params)
    setCrowdList(data.content)
    setPaginationData({
      pageNo: data.pageNo,
      pageSize: data.pageSize,
      total: data.total
    })
  }

  const onReset = () => {
    formRef.current.resetFields()
  }

  return (
    <div className="table-container">
      <Form
        ref={formRef}
        name="basic"
        className="search-form"
        onFinish={queryCrowdList}
        layout="vertical"
        size="middle">
        <div className="search-area">
          <Row gutter={30}>
            <Col span={6}>
              <Form.Item label={`人群包CODE`} name='crowdCode'>
                <Input placeholder={'请输入人群包CODE'} allowClear/>
              </Form.Item>
            </Col>
            <Col span={6}>
              <Form.Item label={`人群包名称`} name='crowdName'>
                <Input placeholder={'请输入人群包名称'} allowClear/>
              </Form.Item>
            </Col>
            <Col span={6}>
              <Form.Item label={`创建人`} name='operationUser'>
                <Input placeholder={'请输入创建人'} allowClear/>
              </Form.Item>
            </Col>
            <Col span={24}>
              <Button type="primary" onClick={() => queryCrowdList(1, 50)}>{$t('portal_search')}</Button>
              <Button onClick={onReset}>{$t('portal_reset')}</Button>
            </Col>
          </Row>
        </div>
      </Form>
      <div className='table-top-wrap'>
        <div className='table-top'>
          <Button type="primary" onClick={() => setSubscribeVisible(true)}>订阅人群包</Button>
        </div>
        <Table
          rowKey={row => row.crowdCode}
          columns={columns}
          dataSource={crowdList}
          scroll={{
            x: '100%',
            y: `calc(100vh - ${getTableHeight('portal-point', 425)}px)`,
          }}
          pagination={paginationData}
          onChange={(pagination) => queryCrowdList(pagination.pageNo, pagination.pageSize)}
        />
      </div>
      { subscribeVisible && <SubscribePackageModal visible={subscribeVisible} onClose={() => setSubscribeVisible(false)} onRefresh={() => queryCrowdList(1, 50)}></SubscribePackageModal>}    
      { renameVisible && <RenameModal visible={renameVisible} onClose={() => setRenameVisible(false)} onRefresh={() => queryCrowdList(1, 50)} id={curId}></RenameModal>}
      { queryMembersVisible && <QueryMembersModal visible={queryMembersVisible} onClose={() => setQueryMembersVisible(false)} code={curId}></QueryMembersModal>}
      { cancelVisible && <CancelSubscribeModal visible={cancelVisible} onClose={() => setCancelVisible(false)} onRefresh={() => queryCrowdList(1, 50)} code={curId}></CancelSubscribeModal>}
    </div>
  )
}

export default ActiveCrowdPackage
