import {Input, Form, Row, Col, Table, Button, TableFilter, message} from '@mcd/portal-components';
import React, {useState, useRef} from 'react';

// @ts-ignore
import Api from '@/api/point/index';

import './index.less';
import moment from 'moment';
import { useDidRecover } from 'react-router-cache-route'

function ActiveRecord() {
    const [queryModel, setQueryModel] = useState({
        current: 1,
        pageSize: 10,
        total: 0
    });
    const [data, setData] = useState([]);

    const formRef = useRef(null);

    const pointMap = {
        1001: '麦当劳积分',
        1002: '麦咖啡积点',
        1003: '甜品站积点',
        1004: '会员日积点',
        1005: '打卡活动积点',
    };

    const columns = [
        // {
        //   title: '手机号',
        //   dataIndex: 'phone',
        //   key: 'phone',
        //   render: text => <span>{text || '-'}</span>
        // },
        {
            title: '顾客编号',
            dataIndex: 'customerId',
            key: 'customerId'
        },
        {
            title: '参与活动ID',
            dataIndex: 'activityId',
            key: 'activityId'
        },
        {
            title: 'Point类',
            dataIndex: 'currency',
            key: 'currency',
            render: text => <span>{pointMap[text] || '-'}</span>
        },
        {
            title: '优惠券类',
            dataIndex: 'couponCode',
            key: 'couponCode',
            render: text => <div style={{maxWidth: '300px'}}>{text || '-'}</div>
        },
        {
            title: '权益卡类',
            dataIndex: 'cardCode',
            key: 'cardCode',
            render: text => <div style={{maxWidth: '300px'}}>{text || '-'}</div>
        },
        {
            title: '参与时间',
            dataIndex: 'createdDate',
            key: 'createdDate',
            render: text => <span>{text ? moment(text).format('YYYY-MM-DD HH:mm:ss') : '-'}</span>
        }
    ];


    const getList = async (
        pageNo = queryModel.current,
        pageSize = queryModel.pageSize
    ) => {
        let params = formRef.current.getFieldsValue();

        params = {pageNo, pageSize, ...params};

        if (pageNo == 1) {
            params.turnPage = 1
        } else if (pageNo > queryModel.current) {
            params.turnPage = 1
            params.createdDate = data[data.length - 1].createdDate
            params.snowflakeId = data[data.length - 1].snowflakeId
        } else if (pageNo < queryModel.current){
            params.turnPage = 0
            params.createdDate = data[0].createdDate
            params.snowflakeId = data[0].snowflakeId
        } else {
            params.turnPage = 1
        }

        const {data: dataList} = await Api.getRecordList(params);
        setData(dataList.records);
        setQueryModel({
            current: pageNo,
            pageSize: pageSize,
            total: dataList.total
        });

    };

    const onFinish = (finish) => {
        getList(1, 10);
    };

    useDidRecover(() => {
      getList();
    })

    const onReset = () => {
        formRef.current.resetFields();
    };

    return (
        <div className='table-container'>
            <Form
                ref={formRef}
                name='basic'
                className='search-form'
                onFinish={onFinish}
                layout='vertical'
                size='middle'
            >
                <div className='search-area'>
                    <Row gutter={30}>
                        {/*<Col span={6}>*/}
                        {/*  <Form.Item label={`手机号`} name='phone'>*/}
                        {/*    <Input placeholder={'请输入手机号'} allowClear />*/}
                        {/*  </Form.Item>*/}
                        {/*</Col>*/}

                        <Col span={6}>
                            <Form.Item label={`顾客编号`} name='customerId'>
                                <Input placeholder={'请输入顾客编号'} allowClear/>
                            </Form.Item>
                        </Col>
                        <Col span={6}>
                            <Form.Item label={`参与活动ID`} name='activityId'>
                                <Input placeholder={'请输入参与活动ID'} allowClear/>
                            </Form.Item>
                        </Col>
                        <Col span={6}>
                            <Form.Item label={`优惠券CODE`} name='couponCode'>
                                <Input placeholder={'请输入优惠券CODE'} allowClear/>
                            </Form.Item>
                        </Col>
                        <Col span={6}>
                            <Form.Item label={`权益卡CODE`} name='cardCode'>
                                <Input placeholder={'请输入权益卡CODE'} allowClear/>
                            </Form.Item>
                        </Col>

                        <Col span={24}>
                            <Button type='primary' htmlType='submit'>{
// @ts-ignore
                                $t('portal_search')}</Button>
                            <Button onClick={onReset}>{

// @ts-ignore
                                $t('portal_reset')}</Button>
                        </Col>
                    </Row>
                </div>
            </Form>
            <div className='table-top-wrap'>
                <div className='table-top'>
                    <div>最近6个月内活动记录</div>
                </div>
                <Table
                    rowKey={row => row.snowflakeId}
                    columns={columns}
                    dataSource={data}
                    pagination={{...queryModel, showLessItems: true}}
                    onChange={pagination => {
                        if (pagination.current ==  1) {
                            getList(pagination.current, pagination.pageSize);
                        } else if (Math.abs(pagination.current - queryModel.current) <= 1) {
                            getList(pagination.current, pagination.pageSize);
                        } else {
                            message.warn('请使用上下页按钮进行操作!!!');
                        }
                    }}
                    scroll={{x: '100%'}}
                />
            </div>
        </div>
    );
}

export default ActiveRecord;