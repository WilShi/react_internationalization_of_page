import React from 'react';

const crowdPackageList = () => {
    return (
        <div className="Home">
            人群包配置
        </div>
    );
}

export default crowdPackageList;