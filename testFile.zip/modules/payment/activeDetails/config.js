export const eventTypeMap = new Map([
  [20, ['1', '2', '3', '6','7' ,'8', '9', '4', '5']]
])

export const rulesMap = new Map([
  ['1', 'crowd'], // 人群
  ['2', 'store'], // 餐厅
  ['3', 'channel'], // 渠道
  ['4', 'beType'], // betype
  ['5', 'product'], // 商品
  ['6', 'tender'], // 支付方式
  ['7', 'datePeriod'], // 时间段
  ['8', 'intervalPeriod'], // 日期
  ['9', 'amount'], // 金额
  ['10', 'coupon'], // 优惠券
  ['11', 'card'], // 权益卡
])

export const getCheckboxStatus = (eventType, obj) => {
  const conditions = eventTypeMap.get(eventType)

  return  conditions.map(i => {
    let checked = false
    const key = rulesMap.get(i)
    if (key !== 'no_support' && obj[key]) {
      checked = true
    }
    return {
      checked,
      condition: i,
      key
    }

  })
}