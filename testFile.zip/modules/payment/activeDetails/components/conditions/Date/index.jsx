import React, { useState, memo } from 'react';
import { Button, Checkbox, Col, DatePicker, InputNumber, message, Radio, Row, Space } from '@mcd/portal-components';
import { getDictionaryListByType } from '@mcd/portal-components/dist/utils/DictUtil';
import { CloseCircleTwoTone } from '@ant-design/icons';
import moment from 'moment';
import * as rules from '@/redux/actions/rulesAction';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import Hoc from '@/modules/refactor/activeDetails/components/conditions/Hoc';

const week = getDictionaryListByType('product_week');
const mouth = getDictionaryListByType('point-mouth-frequency');
const local = localStorage.getItem('locale');

function Date(props) {
  // console.log('propsDate: ', props);

  const setDateList = () => {
    props.setRulesData({
      ...props.intervalPeriod,
      dateList: props.intervalPeriod.dateList
    });
  };

  const onChange = async (val, index) => {
    props.intervalPeriod.dateList[index] = val;
    setDateList();
  };

  const onDelete = index => {
    props.intervalPeriod.dateList.splice(index, 1);
    setDateList();
  };

  const onAdd = () => {
    props.intervalPeriod.dateList.push('');
    setDateList();
  };

  const onChoose = e => {
    props.setRulesData({
      ...props.intervalPeriod,
      type: e.target.value
    });
  };

  return (
    <div>
      <div>{props.children}</div>

      {
        props.checked && <div className='conditions-common-style'>
          <Radio.Group onChange={onChoose} value={props.intervalPeriod.type}>
            <Radio value={1}>包含</Radio>
            <Radio value={2} disabled>排除</Radio>
          </Radio.Group>

          <div style={{ display: 'flex', justifyContent: 'flex-start', margin: '10px 0' }}>
            <div style={{ width: '50px', lineHeight: '18px' }}>每周：</div>
            <Checkbox.Group
              style={{ width: '100%' }}
              onChange={val => props.setRulesData({
                ...props.intervalPeriod,
                weekList: val
              })}
              value={props.intervalPeriod.weekList.map(i => i + '')}>
              {
                week.map(i => <Checkbox value={i.dictValue} key={i.dictValue}
                                        style={{ marginLeft: '8px', width: '60px' }}>
                  {local === 'cn' ? i.dictLabelCn : i.dictLabelEn}
                </Checkbox>)
              }
            </Checkbox.Group>
          </div>

          <div style={{ display: 'flex', justifyContent: 'flex-start', margin: '10px 0' }}>
            <div style={{ width: '50px', lineHeight: '18px' }}>每月：</div>
            <Checkbox.Group
              style={{ width: '100%' }}
              onChange={val => props.setRulesData({
                ...props.intervalPeriod,
                monthList: val
              })}
              value={props.intervalPeriod.monthList.map(i => i + '')}>
              {
                mouth && mouth.map(i => <Checkbox value={i.dictValue} key={i.dictValue}
                                         style={{ marginLeft: '8px', width: '60px' }}>
                  {local === 'cn' ? i.dictLabelCn : i.dictLabelEn}
                </Checkbox>)
              }
            </Checkbox.Group>
          </div>

          <div style={{ display: 'flex', justifyContent: 'flex-start' }}>
            <div style={{ width: '50px', lineHeight: '32px' }}>每年：</div>
            <div style={{ width: 'calc(100% - 50px)' }}>
              {
                props.intervalPeriod.dateList.map((i, index) => <Space key={index}>
                    <div style={{ display: 'flex', justifyContent: 'flex-start' }}>
                      <DatePicker onChange={(_, val) => onChange(val, index)}
                                  value={i ? moment(i, 'MM-DD') : ''} format={'MM-DD'}/>
                      <div style={{ display: 'flex', alignItems: 'center' }}>
                        <CloseCircleTwoTone
                          twoToneColor='red'
                          style={{ fontSize: '18px', margin: '0 4px', cursor: 'pointer' }}
                          onClick={() => onDelete(index)} />
                      </div>
                    </div>
                  </Space>
                )
              }
              <Button onClick={onAdd}>添加</Button>
            </div>

          </div>
        </div>
      }
    </div>
  );
}


const mapDispatchToProps = (dispatch) => ({
  setRulesData: (params) => {
    dispatch(rules.setDate(params));
  }
});

const mapStateToProps = (state, ownProps) => {
  return {
    intervalPeriod: state.rules.intervalPeriod
  };
};

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(Date)
);