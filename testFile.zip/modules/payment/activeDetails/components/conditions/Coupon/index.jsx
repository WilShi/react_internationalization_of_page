import React, { useState, memo, useRef, useEffect } from 'react';
import { Button, Col, Form, Input, message, Modal, Radio, Row, Select, Spin, Tooltip } from '@mcd/portal-components';
import CondsTable from '@/modules/refactor/activeDetails/components/condsTable';
import moment from 'moment';
import Hoc from '../Hoc';
import { getDictionaryListByType } from '@mcd/portal-components/dist/utils/DictUtil';
import { getDictionaryLabel } from '@/utils';
import * as rules from '@/redux/actions/rulesAction';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';

const key = 'couponId';
const beTypeList = getDictionaryListByType('crm_be_type');
const campaignTypeList = getDictionaryListByType('campaign_type'); // 活动大类
const couponCardTypeList = getDictionaryListByType('cp_coupon_obtaining_type'); // 获取类型
function Coupon(props) {
  // console.log('propsCoupon: ', props);
  const [visible, setVisible] = useState(false);
  const [modelData, setModelData] = useState([]);
  const [total, setTotal] = useState([]);
  const [loading, setLoading] = useState(false);

  const showTable = useRef(null);
  const selectTable = useRef(null);

  const [pages, setPages] = useState({
    pageNo: 1,
    pageSize: 10
  });

  const [form] = Form.useForm();

  const columns = [
    {
      title: '优惠券ID',
      dataIndex: 'couponId',
      width: '300px',
      filter: true
    }, {
      title: '优惠券名称',
      dataIndex: 'couponName',
      filter: true
    }, {
      title: '促销编号',
      dataIndex: 'promotionId',
      filter: true
    }
  ];

  const modelColumns = [
    {
      title: '优惠券ID',
      dataIndex: 'couponId',
      width: '300px',
    }, {
      title: '优惠券名称',
      dataIndex: 'title',
    }, {
      title: '活动大类',
      dataIndex: 'campaignType',
      render: text => <span>{getDictionaryLabel('campaign_type', text)}</span>
    }, {
      title: 'BE type',
      dataIndex: 'beTypes',
      render: typeList => {
        const text = typeList?.map((i) => {
          return getDictionaryLabel('crm_be_type', i);
        }).join(',');
        return <Tooltip placement='topLeft' title={text || '-'}>{text || '-'}</Tooltip>;
      }
    }, {
      title: '会员活动名称',
      dataIndex: 'campaignName',
    }, {
      title: '促销编号',
      dataIndex: 'promotionId',
    }, {
      title: '获取类型',
      dataIndex: 'couponCardType',
      render: text => <span>{getDictionaryLabel('cp_coupon_obtaining_type', text)}</span>
    }, {
      title: '剩余数量',
      dataIndex: 'remainQuantity',
    }, {
      title: '优惠券促销类型',
      dataIndex: 'couponPromotionType',
      render: text => <span>{getDictionaryLabel('coupon_promotion_type', text)}</span>
    }, {
      title: '优惠券创建时间',
      dataIndex: 'createdDate',
    }
  ];

  useEffect(() => {
    showTable.current?.initSelected();
  }, []);

  const onQuery = async (params) => {
    setLoading(true);
    let fields = form.getFieldsValue();
    const { data } = await props.getCoupon({
      ...pages,
      ...fields,
      ...params
    });
    console.log(data);
    setModelData(data.list);
    setTotal(data.total);
    setLoading(false);
  };

  const onSelectModel = () => {
    setVisible(true);
    form?.resetFields()
    onQuery();
  };

  const onDelete = () => {
    let selectData = showTable.current.selected;
    if (selectData.length === 0) {
      message.warning('请选择');
      return;
    }
    const newData = props.coupon.couponList.filter(i => !selectData.some(j => i[key] === j));
    props.setRulesData({
      ...props.coupon,
      couponList: newData
    });
    showTable.current?.initSelected();
  };

  const onOk = () => {
    const selectData = selectTable.current.selectedRow;
    console.log('selectData',selectData);
    if (selectData.length === 0) {
      message.warning('请选择至少一个');
      return;
    }
    const res = selectTable.current.compareArr(props.coupon.couponList, selectData, key);
    console.log('res',res);
    if (res.length < (selectData.length + props.coupon.couponList.length)) {
      message.warning('存在');
    }

    props.setRulesData({
      ...props.coupon,
      couponList: res.map(i => ({
        couponId: i.couponId,
        couponName: i.couponName || i.title,
        promotionId: i.promotionId
      }))
    });

    setVisible(false);
  };

  const onPageChange = (page, pageSize) => {
    console.log(page, pageSize);
    onQuery({
      pageNo: page,
      pageSize: pageSize
    });
    setPages({
      pageNo: page,
      pageSize: pageSize
    });
  };

  const selectModel = () => {
    return <Modal
      title='选择优惠券'
      centered
      visible={visible}
      onOk={onOk}
      onCancel={() => setVisible(false)}
      width={1000}
    >
      <Spin spinning={loading}>

        <Form
          form={form}
          layout='vertical'
          onFinish={val => onPageChange(1, 10)}
        >
          <Row gutter={24}>
            <Col span={8}>
              <Form.Item name='couponId' label={`优惠券ID`}>
                <Input placeholder='优惠券ID' />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item name='campaignType' label={$t(/*活动大类*/ 'activity_categories')}>
                <Select allowClear
                        style={{ width: '100%' }}
                        placeholder={`${$t(/*请选择*/ 'please_select')}${$t(/*活动大类*/ 'activity_categories')}`}>
                  {campaignTypeList.map((i) => (
                    <Select.Option value={i.dictValue} key={i.dictValue}>
                      {i.dictLabelCn}
                    </Select.Option>
                  ))}
                </Select>
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item name='beType' label={`BE Type`}>
                <Select style={{ width: '100%' }} placeholder='请选择' allowClear>
                  {beTypeList.map((i) => (
                    <Select.Option value={i.dictValue} key={i.dictValue}>
                      {i.dictLabelCn}
                    </Select.Option>
                  ))}
                </Select>
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item name='couponCardType' label={`获取类型`}>
                <Select style={{ width: '100%' }} placeholder='请选择' allowClear>
                  {couponCardTypeList.map((i) => (
                    <Select.Option value={i.dictValue} key={i.dictValue}>
                      {i.dictLabelCn}
                    </Select.Option>
                  ))}
                </Select>
              </Form.Item>
            </Col>
          </Row>
          <Row>
            <Col span={24} style={{ textAlign: 'right' }}>
              <Button type='primary' htmlType='submit'>查询</Button>
              <Button style={{ margin: '0 8px' }} onClick={() => form.resetFields()}>重置</Button>
            </Col>
          </Row>
        </Form>

        <CondsTable
          ref={selectTable}
          rowKey={row => row[key]}
          columns={modelColumns}
          data={modelData}
          isShowRowSelect={true}
          total={total}
          onPageChange={onPageChange}
          isControlled={true}
          current={pages.pageNo}
          pageSize={pages.pageSize}
        >
        </CondsTable>
      </Spin>
    </Modal>;
  };

  const onChoose = e => {
    props.setRulesData({
      ...props.coupon,
      type: e.target.value
    });
  };

  return (
    <div>
      <div>{props.children}</div>

      {
        props.checked && <div className='conditions-common-style'>
          <Radio.Group onChange={onChoose} value={props.coupon.type}>
            <Radio value={1}>包含</Radio>
            <Radio value={2} disabled>排除</Radio>
          </Radio.Group>

          <div>
            <div style={{ padding: '10px 0' }}>
              <Button type='primary' onClick={onSelectModel}>选择</Button>
              <Button type='primary' danger onClick={onDelete}>删除选中</Button>
            </div>
            <CondsTable
              ref={showTable}
              bordered
              rowKey={row => row[key]}
              columns={columns}
              data={props.coupon.couponList}
              total={props.coupon.couponList.length}
              isShowRowSelect={true}
            >
            </CondsTable>
          </div>

        </div>
      }


      {visible && selectModel()}
    </div>
  );
}

const mapDispatchToProps = (dispatch) => ({
  setRulesData: (params) => {
    dispatch(rules.setCoupon(params));
  }
});

const mapStateToProps = (state, ownProps) => {
  return {
    coupon: state.rules.coupon
  };
};

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(Hoc(Coupon))
);

