/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect, useState } from 'react';
import Hoc from '../Hoc';
import { TimePicker, Row, Col, Button, Radio } from '@mcd/portal-components';
import moment from 'moment';
import { CloseCircleTwoTone } from '@ant-design/icons';
import * as rules from '@/redux/actions/rulesAction';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';

const local = localStorage.getItem('locale');

function TimeQuantum(props) {
  // console.log('propsTimeQuantum: ', props);

  const [data, setData] = useState([
    {
      startTime: '',
      endTime: ''
    }
  ]);

  useEffect(() => {
    init();
  }, []);

  const init = async () => {

  };

  const setTimeList = () => {
    props.setRulesData({
      ...props.datePeriod,
      timeList: props.datePeriod.timeList
    });
  }

  const onChange = (val, index) => {
    props.datePeriod.timeList[index].startTime = val[0];
    props.datePeriod.timeList[index].endTime = val[1];
    setTimeList()
  };

  const onAdd = () => {
    props.datePeriod.timeList.push({
      startTime: '',
      endTime: ''
    });
    setTimeList()
  };

  const onDelete = index => {
    props.datePeriod.timeList.splice(index, 1);
    setTimeList()
  };

  const onChoose = e => {
    props.setRulesData({
      ...props.datePeriod,
      type: e.target.value
    });
  };

  return (
    <div>
      <div>{props.children}</div>

      {
        props.checked && <div className='conditions-common-style'>
          <Radio.Group onChange={onChoose} value={props.datePeriod.type}>
            <Radio value={1}>包含</Radio>
            <Radio value={2} disabled>排除</Radio>
          </Radio.Group>

          <div style={{marginTop: '10px'}}>
            <Row gutter={[16, 24]}>
              {
                props.datePeriod.timeList.map((item, index) => <Col span={8} key={index}>
                  <div style={{ display: 'flex', justifyContent: 'flex-start' }}>
                    <TimePicker.RangePicker
                      style={{ width: '80%' }}
                      value={[
                        item.startTime ? moment(item.startTime, 'HH:mm:ss') : '',
                        item.endTime ? moment(item.endTime, 'HH:mm:ss') : ''
                      ]}
                      onChange={(_, val) => onChange(val, index)} />
                    {
                      props.datePeriod.timeList.length > 1 && <div style={{ display: 'flex', alignItems: 'center' }}>
                        <CloseCircleTwoTone
                          twoToneColor='red'
                          style={{ fontSize: '18px', marginLeft: '8px', cursor: 'pointer' }}
                          onClick={() => onDelete(index)} />
                      </div>
                    }
                  </div>
                </Col>)
              }
            </Row>
            <Button onClick={onAdd}>添加</Button>
          </div>
        </div>
      }


    </div>
  );
}

const mapDispatchToProps = (dispatch) => ({
  setRulesData: (params) => {
    dispatch(rules.setTimeQuantum(params));
  }
});

const mapStateToProps = (state, ownProps) => {
  return {
    datePeriod: state.rules.datePeriod
  };
};

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(Hoc(TimeQuantum))
);
