/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect, useState } from 'react';
import Hoc from '../Hoc';
import { Checkbox, Row, Col, Radio } from '@mcd/portal-components';
import * as rules from '@/redux/actions/rulesAction';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';

const local = localStorage.getItem('locale');

function Betype(props) {
  // console.log('propsBetype: ', props);
  const [data, setData] = useState([]);

  useEffect(() => {
    init();
  }, []);

  const init = async () => {
    const { data } = await props.getBeType();
    setData(data ?? []);
  };

  const onChange = val => {
    props.setRulesData({
      ...props.beType,
      beTypeList: val.map(i => ({ beType: i }))
    });
  };

  const onChoose = e => {
    props.setRulesData({
      ...props.beType,
      type: e.target.value
    });
  }

  return (
    <div>
      <div>{props.children}</div>

      {
        props.checked && <div className='conditions-common-style'>
          <Radio.Group onChange={onChoose} value={props.beType.type}>
            <Radio value={1}>包含</Radio>
            <Radio value={2} disabled>排除</Radio>
          </Radio.Group>
          <div style={{margin: '10px 0'}}>
            <Checkbox.Group
              style={{ width: '100%' }}
              value={props.beType.beTypeList.map(i => i.beType)}
              onChange={onChange}
            >
              <Row>
                {data?.map((i, index) => (
                  <Col span={6} key={index}>
                    <Checkbox value={i.dictValue}>
                      {local === 'cn' ? i.dictLabelCn : i.dictLabelEn}
                    </Checkbox>
                  </Col>
                ))}
              </Row>
            </Checkbox.Group>
          </div>
        </div>

      }


    </div>
  );
}

const mapDispatchToProps = (dispatch) => ({
  setRulesData: (params) => {
    dispatch(rules.setBeType(params));
  }
});

const mapStateToProps = (state, ownProps) => {
  return {
    beType: state.rules.beType
  };
};

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(Hoc(Betype))
);

