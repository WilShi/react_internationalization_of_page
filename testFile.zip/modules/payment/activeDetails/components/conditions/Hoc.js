import React from 'react';
import { Radio } from '@mcd/portal-components';
import Api from '@/api/point/index';

export default function Hoc(WrappedComponent) {
  return class HocFactory extends React.Component {
    constructor(props) {
      super(props);
    }

    getBeType = async () => await Api.getDictType('crm_be_type');// 获取betype
    getChannel = async () => await Api.getDictType('portal_channels');// 获取渠道
    getGoods = async (params = {}) => {
      return await Api.productMaster({
        requestMode: 2, //1: 不返回商品价格数据; 2:返回商品价格数据;
        productType: '1,2', //1个或多个商品类逗号拼接, 1:单品; 2:套餐;3:商品组; 4:外送费
        // productCodes, //1个或多个商品编号逗号拼接
        // productNameCn: '乌', // 商品名称中文
        ...params
      });
    };
    getTag = async () => {
      const { data } = await Api.getTag();
      // 与PCM约定，type为10 供我们使用
      return data?.tagList.filter(tag => tag.type == '10') || [];
    };
    getTender = async (params) => await Api.getPaymentPayType(params); // 支付网关支付方式
    getStore = async (params) => await Api.getStoreList(params);
    getCoupon = async (params) => {
      const data = await Api.getCouponList(params);
      // 与后端约定，promotionId为空时传""
      data.data.list?.forEach(i => {
        if (!i.promotionId) {
          i.promotionId = '';
        }
      });
      return data;
    };
    getEquity = async (params) => await Api.getInterestsList({...params, status: 3});
    getEquityById = async (params) => await Api.getInterestsById(params);


    render() {
      const fn = {
        getBeType: this.getBeType,
        getChannel: this.getChannel,
        getGoods: this.getGoods,
        getTag: this.getTag,
        getTender: this.getTender,
        getStore: this.getStore,
        getCoupon: this.getCoupon,
        getEquity: this.getEquity,
        getEquityById: this.getEquityById
      };
      return (
        <>
          <WrappedComponent
            {...this.props}
            {...fn}
            ref={ref => this.refs = ref}
          >
            <div>{this.props.children}</div>
          </WrappedComponent>
        </>
      );
    }

  };
}
