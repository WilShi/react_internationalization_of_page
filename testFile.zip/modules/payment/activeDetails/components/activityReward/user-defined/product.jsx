import React, {useEffect, useRef, useState, forwardRef, useImperativeHandle} from 'react';
import Hoc from '../../conditions/Hoc';
import CondsTable from '../../condsTable';
import {compareArr} from '../../conditions/index';
import {Button, Space, Modal, Table, Tabs, Radio, Row, Col, Checkbox, Spin, message} from '@mcd/portal-components';
import {TagOutlined} from '@ant-design/icons';
import * as rules from '@/redux/actions/rulesAction';
import {withRouter} from 'react-router-dom';

const {TabPane} = Tabs;
const local = localStorage.getItem('locale');

function Goods(props, ref) {
  // console.log('propsProduct: ', props);
  const [type, setType] = useState(props.pointProduct?.type ?? 1);
  const [regularGoods, setRegularGoods] = useState(props.pointProduct?.regularGoods ?? 1);
  const [productList, setProductList] = useState(props.pointProduct?.productList ?? []);
  const [visible, setVisible] = useState(false);
  const [goodsVisible, setGoodsVisible] = useState(false);
  const [tagTitle, setTagTitle] = useState('');
  const [modelData, setModelData] = useState([]);
  const [total, setTotal] = useState([]);
  const [loading, setLoading] = useState(false);
  const [value, setValue] = useState('goods');
  const [tag, setTag] = useState([]);
  const [selectTag, setSelectTag] = useState([]);

  const showTable = useRef(null);
  const selectTable = useRef(null);

  const [pages, setPages] = useState({
    pageNo: 1,
    pageSize: 10
  });

  useEffect(() => {
    showTable.current?.initSelected();
  }, []);


  //设置暴露给父组件的值
  useImperativeHandle(ref, () => ({
    'pointProduct': {
      type,
      productList,
      // 目前只有麦咖啡积点才有非正价商品
      regularGoods
    }
  }));


  const onQuery = async (params) => {
    setLoading(true);
    const {data} = await props.getGoods(params);
    const handleData = data.productList?.map(i => {
      return {
        productName: i.productNameCn,
        productCode: i.productCode
      };
    });

    setModelData(handleData);
    setTotal(data.total);
    setLoading(false);
  };

  const onGetTag = async () => {
    const data = await props.getTag();
    setTag(data);
  };

  const onSelectModel = () => {
    setValue('goods');
    setVisible(true);
    onQuery({...pages});
    onGetTag();
  };

  const onDelete = () => {
    let selected = showTable.current.selected;
    if (selected.length === 0) {
      message.warning('请选择');
      return;
    }
    const newData = productList.filter(i => !selected.some(j => i.labelId === j || i.productCode === j));

    setProductList(newData)
    showTable.current?.initSelected();
  };

  const columns = [
    {
      title: '商品标签/商品名称',
      dataIndex: 'productName',
      shy: 'labelName',
      filter: true,
      render: (_, row) => {
        if (row.labelId) {
          return <span>
            {row.labelName}
            （标签）
            {/*<TagOutlined style={{ color: '#52c41a' }} />*/}
          </span>;
        }
        return <span>{row.productName}</span>;
      }
    }, {
      title: '商品Code',
      dataIndex: 'productCode',
      shy: 'labelId',
      filter: true,
      render: (_, row) => {
        if (row.labelId) {
          return <span>-</span>;
        }
        return <span>{row.productCode}</span>;
      }
    }, {
      title: '操作',
      key: 'action',
      render: (_, row) => {
        if (row.labelId) {
          return <Space size='middle'>
            <a onClick={() => onViewGoods(row)}>查看商品</a>
          </Space>;
        }
        return <span>-</span>;
      }
    }
  ];

  const onPageChange = (page, pageSize) => {
    onQuery({
      pageNo: page,
      pageSize: pageSize
    });
    setPages({
      pageNo: page,
      pageSize: pageSize
    });
  };


  const onChange = (e) => {
    setValue(e.target.value);
    if (e.target.value === '1') {
      onQuery({
        pageNo: 1,
        pageSize: 10
      });
      setPages({
        pageNo: 1,
        pageSize: 10
      });
    }
  };
  const onChangeTag = (key) => {
    const tagArr = key.map(i => {
      return {
        labelId: i,
        labelName: i
      };
    });
    setSelectTag(tagArr);
  };
  const onView = (productTags) => {
    onQuery({
      pageNo: 1,
      pageSize: 10,
      productTags
    });
    setPages({
      pageNo: 1,
      pageSize: 10
    });
  };

  const onViewGoods = (row) => {
    onView(row.labelId);
    setTagTitle(row.labelName);
    setGoodsVisible(true);
  };

  const onOk = () => {
    let selectData = [];
    let compareKey;
    if (value === 'goods') {
      selectData = selectTable.current.selectedRow;
      compareKey = 'productCode';
    } else {
      selectData = selectTag;
      compareKey = 'labelId';
    }
    if (selectData.length === 0) {
      message.warning('请选择至少一个');
      return;
    }
    const res = compareArr(productList, selectData, compareKey);
    if (res.length < (selectData.length + productList.length)) {
      message.warning('存在');
    }

    setProductList(res)
    setVisible(false);
  };

  const selectModel = () => {
    return <Modal
      title='选择商品/标签'
      centered
      visible={visible}
      onOk={onOk}
      onCancel={() => setVisible(false)}
      width={1000}
    >
      <Spin spinning={loading}>

        <Radio.Group
          onChange={onChange}
          value={value}
          style={{marginBottom: 0}}>
          <Radio.Button value='goods'>选择商品</Radio.Button>
          <Radio.Button value='tag'>选择标签</Radio.Button>
        </Radio.Group>
        <Row>
          <Col span={6}>
            <div style={{padding: '10px 0 0 10px'}}>
              {
                value === 'goods' && <>
                  <Row>
                    <div>全部</div>
                    <a onClick={() => onView()}>查看</a>
                  </Row>
                  {
                    tag.map(i => <Row key={i.code}>
                      <div>{i.name}</div>
                      <a onClick={() => onView(i.code)}>查看</a>
                    </Row>)
                  }
                </>
              }
              {
                value === 'tag' && <Checkbox.Group style={{width: '100%'}} onChange={onChangeTag}>
                  {
                    tag.map(i => <Row key={i.code}>
                      <Checkbox value={i.code}>{i.name}</Checkbox>
                      <a onClick={() => onView(i.code)}>查看</a>
                    </Row>)
                  }
                </Checkbox.Group>
              }
            </div>
          </Col>
          <Col span={18}>
            <CondsTable
              ref={selectTable}
              rowKey={row => row.labelId || row.productCode}
              columns={columns.slice(0, -1)}
              data={modelData}
              isShowRowSelect={value === 'goods'}
              total={total}
              onPageChange={onPageChange}
              isControlled={true}
              current={pages.pageNo}
              pageSize={pages.pageSize}
            >
            </CondsTable>
          </Col>
        </Row>

      </Spin>
    </Modal>;
  };
  const showGoodsModel = () => {
    return <Modal
      title={tagTitle}
      centered
      visible={goodsVisible}
      onOk={() => setGoodsVisible(false)}
      onCancel={() => setGoodsVisible(false)}
      width={1000}
    >
      <Spin spinning={loading}>
        <CondsTable
          rowKey={row => row.labelId || row.productCode}
          columns={columns.slice(0, -1)}
          data={modelData}
          isShowRowSelect={false}
          total={total}
          onPageChange={onPageChange}
        >
        </CondsTable>
      </Spin>
    </Modal>;
  };

  const onChoose = e => {
    setType(e.target.value)
  };


  return (
    <>

      <div className='conditions-common-style'>
        <Radio.Group onChange={onChoose} value={type}>
          <Radio value={1}>包含</Radio>
          <Radio value={2}>排除</Radio>
          <Radio value={3}>全部</Radio>
        </Radio.Group>

        <div>
          <div style={{padding: '10px 0'}}>
            <Button type='primary' onClick={onSelectModel} style={{marginRight: '10px'}}>选择</Button>
            <Button type='primary' danger onClick={onDelete}>删除选中</Button>
          </div>
          <CondsTable
            ref={showTable}
            rowKey={row => row.labelId || row.productCode}
            columns={columns}
            bordered
            data={productList}
            total={productList.length}
            isShowRowSelect={true}
          >
          </CondsTable>
        </div>

        {
          props.pointType == 20 && <Checkbox
            style={{marginTop: '10px'}}
            onChange={e => setRegularGoods(e.target.checked ? 2 : 1)}
            checked={regularGoods == 2}
          >非正价商品不计算</Checkbox>
        }
      </div>

      {visible && selectModel()}
      {goodsVisible && showGoodsModel()}
    </>
  );
}


export default Hoc(forwardRef(Goods));