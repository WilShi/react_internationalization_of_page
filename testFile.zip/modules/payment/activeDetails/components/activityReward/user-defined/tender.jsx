import React, {useEffect, useRef, useState, useImperativeHandle, forwardRef,} from 'react';
import Hoc from '../../conditions/Hoc';
import CondsTable from '../../condsTable';
import {Button, message, Col, Modal, Input, Row, Spin, Form, Select, Radio, Checkbox} from '@mcd/portal-components';
import moment from 'moment';
import * as rules from '@/redux/actions/rulesAction';
import {withRouter} from 'react-router-dom';
import {connect} from 'react-redux';
import {onExport, onUpload} from '@/utils/excel';
import Api from '@/api/point/index';
import _ from "lodash";

const local = localStorage.getItem('locale');
function TenderCode(props, ref) {
  // console.log('propsTenderCode: ', props);
  const [type, setType] = useState(props.pointTender?.type ?? 1);
  const [tenderList, setTenderList] = useState(props.pointTender?.tenderList ?? []);
  // ecs tender
  const [ecsVisible, setECSVisible] = useState(false);
  const [ecsTender, setEcsTender] = useState([]);
  const [ecsModelData, setEcsModelData] = useState([]);
  // oms tender
  const [visible, setVisible] = useState(false);
  const [modelData, setModelData] = useState([]);
  const [total, setTotal] = useState([]);
  const [loading, setLoading] = useState(false);

  const showTable = useRef(null);
  const selectTable = useRef(null);

  const [pages, setPages] = useState({
    pageNo: 1,
    pageSize: 10
  });

  const [form] = Form.useForm();

  //设置暴露给父组件的值
  useImperativeHandle(ref, () => ({
    'pointTender': {
      type,
      tenderList
    }
  }));

  const columns = [
    {
      title: 'Tender Code',
      dataIndex: 'tenderCode',
      align: 'center',
      filter: true
    }
  ];

  const modelColumns = [
    {
      title: 'Tender Code',
      dataIndex: 'tenderCode',
    }, {
      title: 'tender名称',
      dataIndex: 'tenderName',
    }, {
      title: '渠道',
      dataIndex: 'channel'
    }, {
      title: '渠道编号',
      dataIndex: 'channelCode'
    }, {
      title: '付款渠道',
      dataIndex: 'payChannel'
    }, {
      title: '是否可以开发票',
      dataIndex: 'invoiceAllowed',
      render: text => <span>{text ? '可开票' : '不可开票'}</span>
    }, {
      title: '修改时间',
      dataIndex: 'updatedDate',
      render: text => <span>{moment(text).format('YYYY-MM-DD')}</span>
    }
  ];

  useEffect(() => {
    showTable.current?.initSelected();
  }, []);

  const onQuery = async (params) => {
    let fields = form.getFieldsValue();
    setLoading(true);
    const {data: {orderPaymentTender, totalCount}} = await props.getTender({
      ...pages,
      ...fields,
      ...params
    });
    setModelData(orderPaymentTender);
    setTotal(totalCount);
    setLoading(false);
  };

  const onSelectModel = async () => {
    if (props.eventType == 5) {
      const {data} = await Api.getDictType('ecs_tender')
      setEcsTender(data || [])
      setEcsModelData(tenderList.map(i => i.tenderCode))
      setECSVisible(true)
    } else {
      setVisible(true)
      form?.resetFields()
      onQuery()
    }
  };

  const onDelete = () => {
    let selectData = showTable.current.selected;
    if (selectData.length === 0) {
      message.warning('请选择');
      return;
    }
    const newData = tenderList.filter(i => !selectData.some(j => i.tenderCode === j));

    setTenderList(newData)
    showTable.current?.initSelected();
  };

  const onOk = () => {
    const selectData = selectTable.current.selectedRow;
    if (selectData.length === 0) {
      message.warning('请选择至少一个');
      return;
    }
    const res = selectTable.current.compareArr(tenderList, selectData, 'tenderCode');
    if (res.length < (selectData.length + tenderList.length)) {
      message.warning('智能过滤');
    }

    setTenderList(res.map(i => ({tenderCode: i.tenderCode})))
    setVisible(false);
  };

  const onPageChange = (page, pageSize) => {
    onQuery({
      pageNo: page,
      pageSize: pageSize
    });
    setPages({
      pageNo: page,
      pageSize: pageSize
    });
  };


  const selectModel = () => {
    return <Modal
      destroyOnClose
      title='选择TenderCode'
      centered
      visible={visible}
      onOk={onOk}
      onCancel={() => setVisible(false)}
      width={1000}
    >
      <Spin spinning={loading}>

        <Form
          form={form}
          layout='vertical'
          preserve={false}
          onFinish={val => onPageChange(1, 10)}
        >
          <Row gutter={24}>
            <Col span={8}>
              <Form.Item name='tenderCode' label={`Tender Code`}>
                <Input placeholder='请输入Tender Code'/>
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item name='tenderName' label={`tender名称`}>
                <Input placeholder='请输入tender名称'/>
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item name='invoiceAllowed' label={`是否可以开发票`}>
                <Select style={{width: '100%'}} placeholder='请选择' allowClear>
                  <Select.Option value='0'>不可开票</Select.Option>
                  <Select.Option value='1'>可开票</Select.Option>
                </Select>
              </Form.Item>
            </Col>
          </Row>
          <Row>
            <Col span={24} style={{textAlign: 'right'}}>
              <Button type='primary' htmlType='submit'>查询</Button>
              <Button style={{margin: '0 8px'}} onClick={() => form.resetFields()}>重置</Button>
            </Col>
          </Row>
        </Form>

        <CondsTable
          ref={selectTable}
          rowKey={row => row.tenderCode}
          columns={modelColumns}
          data={modelData}
          isShowRowSelect={true}
          total={total}
          onPageChange={onPageChange}
          isControlled={true}
          current={pages.pageNo}
          pageSize={pages.pageSize}
        >
        </CondsTable>
      </Spin>
    </Modal>;
  };

  const selectECSModel = () => {
    return <Modal
      title="选择支付方式"
      centered
      visible={ecsVisible}
      onOk={ecsOnOk}
      onCancel={() => setECSVisible(false)}
      width={1000}
    >
      <div style={{ margin: '10px 0' }}>
        <Checkbox.Group
          style={{ width: '100%' }}
          value={ecsModelData}
          onChange={val => setEcsModelData(val)}
        >
          <Row>
            {ecsTender?.map((i, index) => (
              <Col span={6} key={index}>
                <Checkbox value={i.dictValue}>
                  {local === 'cn' ? i.dictLabelCn : i.dictLabelEn}
                </Checkbox>
              </Col>
            ))}
          </Row>
        </Checkbox.Group>
      </div>
    </Modal>
  };

  const ecsOnOk = () => {
    if (ecsModelData.length === 0) {
      message.warning('请选择至少一个');
      return;
    }

    const difData = _.differenceBy(ecsModelData.map(i => ({tenderCode: i})), tenderList, 'tenderCode');

    if (difData.length < ecsModelData.length) {
      message.warning('存在');
    }
    const newData = difData.concat(tenderList)

    setTenderList(newData)
    setECSVisible(false);
  }

  const onChoose = e => {
    setType(e.target.value)
  };

  const handleExport = () => {
    onExport([{tenderCode: ''}], 'tenderCode');
  };


  const handleUpload = async (e) => {
    onUpload(e.target.files, (res) => {
      if (res.length === 0) {
        message.warning('excel无数据或模版不对');
      } else {
        try {

          let obj = {};
          //  去重
          let uploadData = res.reduce((cur, next) => {
            obj[next.tenderCode] ? '' : obj[next.tenderCode] = true && cur.push(next);
            return cur;
          }, []).map(i => ({tenderCode: i['tenderCode'].toString().trim()}));

          const result = showTable.current.compareArr(tenderList, uploadData, 'tenderCode');
          if (result.length < (uploadData.length + tenderList.length)) {
            message.warning('已智能过滤重复数据');
          }

          setTenderList(result.map(i => ({tenderCode: i.tenderCode})))
        } catch (e) {
          message.warning('导入失败');
        }
      }
    });
  };

  return (
    <div>
      <div className='conditions-common-style'>
        <Radio.Group onChange={onChoose} value={type}>
          <Radio value={1}>包含</Radio>
          <Radio value={2}>排除</Radio>
          <Radio value={3}>全部</Radio>
        </Radio.Group>

        <div>
          <div style={{padding: '10px 0'}}>
            <Button type='primary' onClick={onSelectModel} style={{marginRight: '10px'}}>选择</Button>
            <Button type='primary' danger onClick={onDelete} style={{marginRight: '10px'}}>删除选中</Button>
            <a style={{
              display: 'inline-block',
              position: 'relative',
              marginRight: '8px',
              width: '80px',
              height: '32px',
              lineHeight: '32px',
              border: '1px solid #d9d9d9',
              borderRadius: '4px',
              textAlign: 'center',
              background: '#fff',
              color: 'rgba(0, 0, 0, 0.85)',
              cursor: 'pointer'
            }}>
              导入
              <input type='file' onChange={handleUpload} onClick={e => e.target.value = ''} style={{
                width: '80px',
                height: '32px',
                position: 'absolute',
                top: '0',
                right: '0',
                cursor: 'pointer',
                fontSize: 0,
                opacity: 0
              }}/>
            </a>
            <Button onClick={handleExport}>下载模版</Button>
          </div>
          <CondsTable
            ref={showTable}
            rowKey={row => row.tenderCode}
            columns={columns}
            bordered
            data={tenderList}
            total={tenderList.length}
            isShowRowSelect={true}
          >
          </CondsTable>
        </div>
      </div>


      {visible && selectModel()}
      {ecsVisible && selectECSModel()}
    </div>
  );
}

export default Hoc(forwardRef(TenderCode));