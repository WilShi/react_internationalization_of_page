import CouponClass from './couponClass'
import EquityClass from './equityClass'
import PointClass from './pointClass'
import GoodsTag from './goodsTag'

export const Rewards = {
  CouponClass,
  EquityClass,
	PointClass,
  GoodsTag
}