import React, {useState, useRef, useImperativeHandle, forwardRef, useEffect, useMemo} from 'react';


import CondsTable from '../../condsTable';
import {
  Button,
  Col,
  Form,
  Input,
  message,
  Modal,
  Radio,
  Row,
  Select,
  Spin,
  Tooltip,
  Space,
  Checkbox
} from '@mcd/portal-components';

import Hoc from '../../conditions/Hoc';
import {getDictionaryLabel} from '@/utils';
import {getDictionaryListByType} from '@mcd/portal-components/dist/utils/DictUtil';


const key = 'couponId';
const beTypeList = getDictionaryListByType('crm_be_type');
const campaignTypeList = getDictionaryListByType('campaign_type'); // 活动大类
const couponCardTypeList = getDictionaryListByType('cp_coupon_obtaining_type'); // 获取类型

function CouponClass(props, ref) {
  // console.log('props', props)
  const [data, setData] = useState([]);
  const [type, setType] = useState(1);
  const [regularGoods, setRegularGoods] = useState(1);
  const [visible, setVisible] = useState(false);
  const [loading, setLoading] = useState(false);
  const [modelData, setModelData] = useState([]);
  const [total, setTotal] = useState([]);


  const showTable = useRef(null);
  const selectTable = useRef(null);

  const [pages, setPages] = useState({
    pageNo: 1,
    pageSize: 10
  });

  const [form] = Form.useForm();


  useEffect(() => {
    setData(props.ruleCoupon?.ruleCouponList ?? []);
    setType(props.ruleCoupon?.type ?? 1);
    setRegularGoods(props.ruleCoupon?.regularGoods ?? 1);
  }, [props.ruleCoupon]);

  useEffect(() => {
    props.onSetCoupon({
        type,
        ruleCouponList: data,
        regularGoods: type === 2 ? regularGoods : null
      }
    )
  }, [type, data, regularGoods])

  let ShyData = useRef()
  useEffect(() => {
    ShyData.current = data
  }, [data])

  const columns = [
    {
      title: '排序',
      dataIndex: 'sort',
      width: '80px',
      render: (_, __, index) => (<span>{index + 1}</span>)
    },
    {
      title: '优惠券ID',
      dataIndex: 'couponId',
      width: '300px',
      filter: true
    }, {
      title: '优惠券名称',
      dataIndex: 'couponName',
      filter: true
    }, {
      title: '促销编号',
      dataIndex: 'promotionId',
      width: '120px',
      filter: true
    }, {
      title: '操作',
      key: 'action',
      render: (text, row, ind) => {
        return <Space size="middle">
          <Radio.Group onChange={e => onChange(e, row)} value={row.grantType ?? '1'}>
            <Radio value={'1'}>直塞</Radio>
            <Radio value={'2'} disabled={props?.eventType == 2}>领取</Radio>
          </Radio.Group>
        </Space>
      },
    },
  ];


  const onChange = (e, row) => {
    row.grantType = e.target.value
    setData([...ShyData.current])
  }


  const modelColumns = [
    {
      title: '优惠券ID',
      dataIndex: 'couponId',
    }, {
      title: '优惠券名称',
      dataIndex: 'title',
    }, {
      title: '活动大类',
      dataIndex: 'campaignType',
      render: text => <span>{getDictionaryLabel('campaign_type', text)}</span>
    }, {
      title: 'BE type',
      dataIndex: 'beTypes',
      render: typeList => {
        const text = typeList?.map((i) => {
          return getDictionaryLabel('crm_be_type', i);
        }).join(',');
        return <Tooltip placement='topLeft' title={text || '-'}>{text || '-'}</Tooltip>;
      }
    }, {
      title: '会员活动名称',
      dataIndex: 'campaignName',
    }, {
      title: '促销编号',
      dataIndex: 'promotionId',
    }, {
      title: '获取类型',
      dataIndex: 'couponCardType',
      render: text => <span>{getDictionaryLabel('cp_coupon_obtaining_type', text)}</span>
    }, {
      title: '剩余数量',
      dataIndex: 'remainQuantity',
    }, {
      title: '优惠券促销类型',
      dataIndex: 'couponPromotionType',
      render: text => <span>{getDictionaryLabel('coupon_promotion_type', text)}</span>
    }, {
      title: '优惠券创建时间',
      dataIndex: 'createdDate',
    }
  ];

  useEffect(() => {
    showTable.current?.initSelected();
  }, []);


  const onQuery = async (params) => {
    setLoading(true);
    let fields = form.getFieldsValue();
    const {data} = await props.getCoupon({
      ...pages,
      ...fields,
      ...params
    });
    setModelData(data.list);
    setTotal(data.total);
    setLoading(false);
  };

  const onSelectModel = () => {
    setVisible(true);
    onQuery();
  };
  const onDelete = () => {
    let selectData = showTable.current.selected;
    const newData = data.filter(i => !selectData.some(j => i[key] === j));
    setData(newData);
    showTable.current?.initSelected();
  };

  const onOk = () => {
    const selectData = selectTable.current.selectedRow;
    if (selectData.length === 0) {
      message.warning('请选择至少一个');
      return;
    }
    const res = selectTable.current.compareArr(data, selectData, key);

    if (res.length > 10) {
      message.warning('最多选择10个');
      return;
    }

    if (res.length < (selectData.length + data.length)) {
      message.warning('存在');
    }

    const newData = JSON.parse(JSON.stringify(data))
    res.forEach(i => {
      const result = data.some(j => i.couponId === j.couponId)
      if (!result) {
        newData.push(i)
      }
    })

    setData(newData.map(i => ({
      couponId: i.couponId,
      couponName: i.couponName || i.title,
      promotionId: i.promotionId,
      grantType: i.grantType
    })))
    setVisible(false);
  };

  const onPageChange = (page, pageSize) => {
    onQuery({
      pageNo: page,
      pageSize: pageSize
    });
    setPages({
      pageNo: page,
      pageSize: pageSize
    });
  };

  const selectModel = () => {
    return <Modal
      title='选择优惠券'
      centered
      visible={visible}
      onOk={onOk}
      onCancel={() => setVisible(false)}
      width={1000}
    >
      <Spin spinning={loading}>

        <Form
          form={form}
          layout='vertical'
          onFinish={val => onPageChange(1, 10)}
        >
          <Row gutter={24}>
            <Col span={8}>
              <Form.Item name='couponId' label={`优惠券ID`}>
                <Input placeholder='优惠券ID'/>
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item name='campaignType' label={`活动大类`}>
                <Select allowClear
                        style={{width: '100%'}}
                        placeholder={`${$t(/*请选择*/ 'please_select')}${$t(/*活动大类*/ 'activity_categories')}`}>
                  {campaignTypeList.map((i) => (
                    <Select.Option value={i.dictValue} key={i.dictValue}>
                      {i.dictLabelCn}
                    </Select.Option>
                  ))}
                </Select>
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item name='beType' label={`BE Type`}>
                <Select style={{width: '100%'}} placeholder='请选择' allowClear>
                  {beTypeList.map((i) => (
                    <Select.Option value={i.dictValue} key={i.dictValue}>
                      {i.dictLabelCn}
                    </Select.Option>
                  ))}
                </Select>
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item name='couponCardType' label={`获取类型`}>
                <Select style={{width: '100%'}} placeholder='请选择' allowClear>
                  {couponCardTypeList.map((i) => (
                    <Select.Option value={i.dictValue} key={i.dictValue}>
                      {i.dictLabelCn}
                    </Select.Option>
                  ))}
                </Select>
              </Form.Item>
            </Col>
          </Row>
          <Row>
            <Col span={24} style={{textAlign: 'right'}}>
              <Button type='primary' htmlType='submit'>查询</Button>
              <Button style={{margin: '0 8px'}} onClick={() => form.resetFields()}>重置</Button>
            </Col>
          </Row>
        </Form>

        <CondsTable
          ref={selectTable}
          rowKey={row => row[key]}
          columns={modelColumns}
          data={modelData}
          isShowRowSelect={true}
          total={total}
          onPageChange={onPageChange}
          isControlled={true}
          current={pages.pageNo}
          pageSize={pages.pageSize}
        >
        </CondsTable>
      </Spin>
    </Modal>;
  };

  const Table = useMemo(() => {
    return <CondsTable
      style={{marginLeft: '20px'}}
      ref={showTable}
      bordered
      rowKey={row => row.couponId}
      columns={columns}
      data={data}
      // total={props.coupon.couponList.length}
      isShowRowSelect={true}
      isDrag={true}
      pagination={{hideOnSinglePage: true}}
      moveRow={r => {
        setData(r)
      }}
    />
  }, [data])

  return (
    <div>
      <div>{props.children}</div>

      {
        props.checked && <div style={{margin: '10px 0'}}>
          {
            props?.eventType !== 2 &&
            <Radio.Group onChange={e => setType(e.target.value)} value={type} style={{marginLeft: '20px'}}>
              <Radio value={1}>按次发放</Radio>
              {
                props?.eventType === 1 && <Radio value={2}>按商品数量发放</Radio>
              }
            </Radio.Group>
          }


          <div style={{padding: '10px 0', marginLeft: '20px'}}>
            {
              data.length < 10 &&
              <Button type='primary' onClick={onSelectModel}>选择</Button>
            }

            <Button type='primary' danger onClick={onDelete}>删除选中</Button>
          </div>

          {Table}

          <div style={{display: 'flex', justifyContent: 'space-between', marginTop: '10px'}}>
            {
              type === 2 ? <Checkbox
                style={{marginLeft: '30px'}}
                onChange={e => setRegularGoods(e.target.checked ? 2 : 1)}
                checked={regularGoods == 2}
              >非正价商品不计算</Checkbox> : <span></span>
            }
            <div style={{textAlign: 'right'}}>剩余添加条数：{10 - data.length}</div>
          </div>
        </div>
      }


      {visible && selectModel()}
    </div>
  );
}


export default Hoc(CouponClass);
