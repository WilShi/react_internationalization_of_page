import React, {useState, useImperativeHandle, forwardRef, useEffect, useRef} from 'react';

import {Row, Col, DatePicker, Radio, Space, InputNumber, Select, Modal, Badge} from '@mcd/portal-components';
import moment from 'moment';

import './index.less'
import {isNullishCoalesce} from 'typescript';
import Tender from '../user-defined/tender'
import Product from '../user-defined/product'

function PointClass(props, ref) {
  // console.log('props', props)
  const [grantType, setGrantType] = useState(1)
  const [visibleTen, setVisibleTen] = useState(false)
  const [visiblePro, setVisiblePro] = useState(false)
  const [pointType, setPointType] = useState({
    '1': '',
    '2': '',
    '3': ''
  })
  const [pointNum, setPointNum] = useState({
    '1': '',
    '2': '',
    '3': ''
  })
  const [amount, setAmount] = useState('')
  const [expireType, setExpireType] = useState('')
  const [expireNum, setExpireNum] = useState({
    '1': '',
    '2': ''
  })
  const [expireDate, setExpireDate] = useState('')
  const [pointParams, setPointParams] = useState({
    pointAttribute: 1, // 财务结算方式 1:有偿 2:无偿
    pointRuleExpireType: { // 过期方式
      expireDate: "",
      num: '',
      type: ''
    },
    pointRuleGrantType: { // 发放方式
      amount: '',
      pointNum: '',
      pointType: '',
      pointTypeName: "",
      type: ''
    }
  })
  const [pointTender, setPointTender] = useState(null)
  const [pointProduct, setPointProduct] = useState(null)
  const tenderRef = useRef()
  const productRef = useRef()
  const grantList = [{
    key: 10, value: '麦享会积分'
  }, {
    key: 20, value: '麦咖啡积点'
  }, {
    key: 40, value: '会员日积点'
  }, {
    key: 50, value: '甜品站积点'
  }]

  useEffect(() => {
    setGrantType(props?.reviewInfo?.ruleGrantType?.type ?? 1)
    setPointType({...{[props?.reviewInfo?.ruleGrantType?.type]: props?.reviewInfo?.ruleGrantType?.pointType}})
    setPointNum({...{[props?.reviewInfo?.ruleGrantType?.type]: props?.reviewInfo?.ruleGrantType?.pointNum}})
    setAmount(props?.reviewInfo?.ruleGrantType?.amount ? props?.reviewInfo?.ruleGrantType?.amount : null)
    setPointParams({...{pointAttribute: props?.reviewInfo?.pointRuleAction?.pointAttribute ?? 1}})
    setExpireType(props?.reviewInfo?.ruleExpireType?.type)
    setExpireNum({...{[props?.reviewInfo?.ruleExpireType?.type]: props?.reviewInfo?.ruleExpireType?.num}})
    setExpireDate(props?.reviewInfo?.ruleExpireType?.type == 4 ? '' : props?.reviewInfo?.ruleExpireType?.expireDate)
    setPointProduct(props?.reviewInfo?.pointProduct)
    setPointTender(props?.reviewInfo?.pointTender)
  }, [props.reviewInfo])

  // 暴露出去的方法
  useImperativeHandle(ref, () => ({
    pointClassParams: () => {
      // 发放方式
      let pointRuleGrantTypeTem = {
        amount: amount,
        pointNum: pointNum[grantType],
        pointType: pointType[grantType],
        pointTypeName: '',
        type: grantType
      }
      grantList.forEach(item => {
        if (item.key == pointType[grantType]) {
          pointRuleGrantTypeTem.pointTypeName = item.value
        }
      })
      // 过期方式
      let pointRuleExpireTypeTem = {
        expireDate: expireType == 3 ? expireDate : '',
        num: (expireType == 1 || expireType == 2) ? expireNum[expireType] : '',
        type: expireType
      }
      return {
        ...pointParams, ...{
          pointRuleGrantType: pointRuleGrantTypeTem,
          pointRuleExpireType: pointRuleExpireTypeTem
        },
        pointTender, pointProduct
      }
    }
  }));

  const onchangeGrantType = (e) => {
    // setGrantType(e.target.value)
    setGrantType(e)
  }

  const onChangePointType = (e, type) => {
    // 目前只有麦咖啡积点有非正价商品
    if (type == 3 && e != 20 && pointProduct) {
      pointProduct.regularGoods = 1
    }
    setPointType({...pointType, ...{[type]: e}})
  }

  const onChangePointNum = (e, type) => {
    setPointNum({...pointNum, ...{[type]: e}})
  }

  const onChangeAmount = (e) => {
    setAmount(e)
  }

  const onChangeExpireType = (e) => {
    setExpireType(e.target.value)
  }

  const onChangeExpireNum = (e, type) => {
    setExpireNum({...expireNum, ...{[type]: e}})
  }

  const onChangeExpireDate = (date, dateString) => {
    setExpireDate(dateString)
  }

  const onChangePointAttribute = (e) => {
    setPointParams({...pointParams, ...{pointAttribute: e.target.value}})
  }

  const disabledDate = (current) => {
    return current && moment(current).year() > '2036'
  }

  const onSaveTen = () => {
    setPointTender(tenderRef.current.refs.pointTender)
    setVisibleTen(false)
  }
  const onSavePro = () => {
    setPointProduct(productRef.current.refs.pointProduct)
    setVisiblePro(false)
  }

  const ModalTender = () => {
    return <Modal
      title="自定义配置"
      centered
      visible={visibleTen}
      onOk={onSaveTen}
      onCancel={() => setVisibleTen(false)}
      width={800}
    >
      <Tender ref={tenderRef} pointTender={pointTender} eventType={props.eventType}></Tender>
    </Modal>
  }
  const ModalProduct = () => {
    return <Modal
      title="自定义配置"
      centered
      visible={visiblePro}
      onOk={onSavePro}
      onCancel={() => setVisiblePro(false)}
      width={800}
    >
      <Product ref={productRef} pointProduct={pointProduct} pointType={pointType['3']}></Product>
    </Modal>
  }
  return (
    <div className="point-class">
      <div>{props.children}</div>
      {props.checked && <div className="ml-20">
        <Row gutter={60}>
          <Col span={24}>
            <p><span className="colo-red">* </span>发放方式</p>
            <div className="mode-container">
              <Space direction="vertical">
                <Space direction="horizontal">
                  <Radio value={1} checked={grantType == 1} onChange={() => onchangeGrantType(1)}></Radio>
                  发放
                  <Select className="wid-200" value={pointType[1]} onChange={(e) => onChangePointType(e, '1')}>
                    {grantList.map(item => {
                      return (
                        <Select.Option value={item.key} key={item.key}>{item.value}</Select.Option>
                      )
                    })}
                  </Select> ，
                  每次发放
                  <InputNumber step={pointType[1] == 10 ? '0.01' : '1'} precision={pointType[1] == 10 ? 2 : 0}
                               min={pointType[1] == 10 ? 0.01 : 1} max={pointType[1] == 10 ? 99999.99 : 99999}
                               value={pointNum[1]} onChange={(e) => onChangePointNum(e, '1')}/>
                  个。
                </Space>
                {
                  props?.eventType !== 2 && <>
                    <Space direction="horizontal">
                      <Radio value={2} checked={grantType == 2} onChange={() => onchangeGrantType(2)}></Radio>
                      发放
                      <Select className="wid-200" value={pointType[2]} onChange={(e) => onChangePointType(e, '2')}>
                        {grantList.map(item => {
                          return (
                            <Select.Option value={item.key} key={item.key}>{item.value}</Select.Option>
                          )
                        })}
                      </Select> ，
                      按每支付
                      <InputNumber step={'0.01'} precision={2} min={0.01} max={99999.99} value={amount}
                                   onChange={onChangeAmount}/>
                      元发放(
                      <Badge count={pointTender?.tenderList.length || '全部'} size="small" offset={[-12, 0]}>
                        <a onClick={() => setVisibleTen(true)} style={{marginRight: '30px'}}>自定义配置</a>
                      </Badge>
                      )
                      <InputNumber step={pointType[2] == 10 ? '0.01' : '1'} precision={pointType[2] == 10 ? 2 : 0}
                                   min={pointType[2] == 10 ? 0.01 : 1} max={pointType[2] == 10 ? 99999.99 : 99999}
                                   value={pointNum[2]} onChange={(e) => onChangePointNum(e, '2')}/>
                      个。
                    </Space>
                    {
                      props?.eventType !== 5 &&
                      <Space direction="horizontal">
                        <Radio value={3} checked={grantType == 3} onChange={() => onchangeGrantType(3)}></Radio>
                        发放
                        <Select className="wid-200" value={pointType[3]} onChange={(e) => onChangePointType(e, '3')}>
                          {grantList.map(item => {
                            return (
                              <Select.Option value={item.key} key={item.key}>{item.value}</Select.Option>
                            )
                          })}
                        </Select> ，
                        按每个商品(

                        <Badge count={pointProduct?.productList.length || '全部'} size="small" offset={[-12, 0]}>
                          <a onClick={() => setVisiblePro(true)} style={{marginRight: '30px'}}>自定义配置</a>
                        </Badge>)发放
                        <InputNumber step={pointType[3] == 10 ? '0.01' : '1'} precision={pointType[3] == 10 ? 2 : 0}
                                     min={pointType[3] == 10 ? 0.01 : 1} max={pointType[3] == 10 ? 99999.99 : 99999}
                                     value={pointNum[3]} onChange={(e) => onChangePointNum(e, '3')}/>
                        个。
                      </Space>
                    }

                  </>
                }
              </Space>
            </div>
          </Col>
        </Row>
        <Row gutter={60}>
          <Col span={24}>
            <p><span className="colo-red">* </span>过期方式</p>
            <Radio.Group className="mode-container" value={expireType} onChange={onChangeExpireType}>
              <Space direction="vertical">
                <Radio value={1}>
                  &nbsp;按月过期，在T+&nbsp;
                  <InputNumber min={1} max={99} value={expireNum[1]} onChange={(e) => onChangeExpireNum(e, '1')}/>
                  &nbsp;个自然月的月底过期。
                </Radio>
                <Radio value={2}>
                  &nbsp;按天过期，在T+&nbsp;
                  <InputNumber min={1} max={99} value={expireNum[2]} onChange={(e) => onChangeExpireNum(e, '2')}/>
                  &nbsp;个自然日的24点过期。
                </Radio>
                <Radio value={3}>
                  &nbsp;按固定日期，在&nbsp;
                  <DatePicker className="wid-200" disabledDate={disabledDate}
                              value={expireDate ? moment(expireDate, 'yyyy-MM-DD') : ''} onChange={onChangeExpireDate}/>
                  &nbsp;的24点过期。
                </Radio>
                <Radio value={4}>
                  &nbsp;不过期。
                </Radio>
              </Space>
            </Radio.Group>
          </Col>
        </Row>
        <Row gutter={60}>
          <Col span={24}>
            <p>财务结算方式</p>
            <Radio.Group className="mode-container" value={pointParams.pointAttribute}
                         onChange={onChangePointAttribute}>
              <Radio value={1}>有偿</Radio>
              <Radio value={2}>无偿</Radio>
            </Radio.Group>
          </Col>
        </Row>
      </div>}

      {ModalTender()}
      {ModalProduct()}

    </div>
  )
}

export default forwardRef(PointClass)
