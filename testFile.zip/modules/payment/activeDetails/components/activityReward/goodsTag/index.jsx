import React, {useState, useEffect, forwardRef, useImperativeHandle, useCallback} from 'react';
import {Radio, Space, Input, Button} from '@mcd/portal-components';
import {copyMsg} from '@/utils/index'

function GoodsTag(props, ref) {

  const [type, setType] = useState(1);
  const [value, setValue] = useState('')
  const [valueEn, setValueEn] = useState('')
  const [discountCodeVal, setDiscountCodeVal] = useState('')
  const [discountCodeType, setDiscountCodeType] = useState(1)

  // 暴露出去的方法
  useImperativeHandle(ref, () => ({
    paymentDiscount: {
      discountCode: discountCodeType == 1 ? props?.reviewInfo?.pointRule?.pointRuleId : discountCodeVal,
      discountMsg: value,
      discountMsgEn: valueEn,
      type: discountCodeType
    }
  }));

  useEffect(() => {
    setValue(props?.reviewInfo?.paymentDiscount?.discountMsg || '')
    setValueEn(props?.reviewInfo?.paymentDiscount?.discountMsgEn || '')
    setDiscountCodeVal(props?.reviewInfo?.paymentDiscount?.discountCode || '')
    setDiscountCodeType(props?.reviewInfo?.paymentDiscount?.type || 1)
  }, [props.reviewInfo])

  const onChangeDiscountCodeType = (e) => {
    setDiscountCodeType(e.target.value)
  }

  return (
    <div style={{marginTop: '20px'}}>
      <div>{props.children}</div>

      {
        props.checked &&
         <div style={{margin: '10px 0'}}>
          <Radio.Group onChange={onChangeDiscountCodeType} value={discountCodeType} style={{marginLeft: '20px'}}>
            <Space direction="vertical">
              <Radio value={1}>
                固定优惠标记：<span id="goodTagsId">{props?.reviewInfo?.pointRule?.pointRuleId}</span>【<Button type="link" onClick={() => copyMsg('goodTagsId')}>复制</Button>】
              </Radio> 
              <Radio value={2}>
                自定义优惠标记：<Input maxLength={50} value={discountCodeVal} onChange={e => setDiscountCodeVal(e.target.value)} suffix={<span style={{color: '#999999'}}>{discountCodeVal.length}/50</span>}
                />
              </Radio>
            </Space>
          </Radio.Group>
          <div style={{marginLeft: '20px', marginTop: '10px'}}>C端文案</div>
          <Space direction="vertical">
            <Space direction="horizontal" style={{margin: '10px 0 0 60px'}}>
              中文：<Input maxLength={10} value={value} onChange={e => setValue(e.target.value)} style={{ width: '300px' }} suffix={<span style={{color: '#999999'}}>{value.length}/10</span>} />
            </Space>
            <Space direction="horizontal" style={{margin: '10px 0 0 60px'}}>
              英文：<Input maxLength={20} value={valueEn} onChange={e => setValueEn(e.target.value.replace(/[\u4E00-\u9FA5]|[\uFE30-\uFFA0]/g, ''))} style={{ width: '300px' }} suffix={<span style={{color: '#999999'}}>{valueEn.length}/20</span>} />
            </Space>
          </Space>
        </div>
      }
    </div>
  );
};

export default forwardRef(GoodsTag);
