/* eslint-disable react-hooks/rules-of-hooks */
import React, {useEffect, useState, useRef, forwardRef, useImperativeHandle, useCallback} from 'react';
import {Table, Input, Button, Space} from '@mcd/portal-components';
import {SearchOutlined, FilterOutlined} from '@ant-design/icons';
import {compareArr} from './conditions';
import {DndProvider, useDrag, useDrop} from 'react-dnd';
import {HTML5Backend} from 'react-dnd-html5-backend';
import update from 'immutability-helper';

// import Highlighter from 'react-highlight-words';


const type = 'DragableBodyRow';

const DragableBodyRow = ({index, moveRow, className, style, ...restProps}) => {
  const ref = useRef();
  const [{isOver, dropClassName}, drop] = useDrop({
    accept: type,
    collect: monitor => {
      const {index: dragIndex} = monitor.getItem() || {};
      if (dragIndex === index) {
        return {};
      }
      return {
        isOver: monitor.isOver(),
        dropClassName: dragIndex < index ? ' drop-over-downward' : ' drop-over-upward'
      };
    },
    drop: item => {
      moveRow(item.index, index);
    }
  });
  const [, drag] = useDrag({
    type,
    item: {index},
    collect: monitor => ({
      isDragging: monitor.isDragging()
    })
  });
  drop(drag(ref));

  return (
    <tr
      ref={ref}
      className={`${className}${isOver ? dropClassName : ''}`}
      style={{cursor: 'move', ...style}}
      {...restProps}
    />
  );
};


function condsTable(props, ref) {
  const [columns, setColumns] = useState([]); // 表头
  const [selectedRowKeys, setSelectedRowKeys] = useState([]);
  const [selectedRow, setSelectedRow] = useState([]);
  const [uniqKey, setUniqKey] = useState(0);

  const [filter, setFilter] = useState({
    searchText: '',
    searchedColumn: ''
  });

  let inputRef = useRef(null);
  let tableRef = useRef(null);

  useEffect(() => {
    init();
  }, []);

  //设置暴露给父组件的值
  useImperativeHandle(ref, () => ({
    selected: selectedRowKeys,
    selectedRow: selectedRow,
    initSelected: () => {
      if (selectedRow.length > 0) {
        setUniqKey(uniqKey + 1)
      }
      setSelectedRow([]);
      setSelectedRowKeys([]);
    },
    initPage: () => {
      setUniqKey(uniqKey + 1)
    },
    // todo优化
    setSelected: data => setSelectedRowKeys(data),
    compareArr
  }));

  const init = () => {
    const initCol = props.columns.map(i => {
      if (i.filter) {
        return {
          ...i,
          ...getColumnSearchProps(i.dataIndex, i.shy)
        };
      }
      return i;
    });
    setColumns(initCol);
  };

  const components = {
    body: {
      row: DragableBodyRow
    }
  };

  const moveRow = useCallback(
    (dragIndex, hoverIndex) => {
      const dragRow = props.data[dragIndex];
      const newData = update(props.data, {
        $splice: [
          [dragIndex, 1],
          [hoverIndex, 0, dragRow]
        ]
      });
      props.moveRow(newData);
    },
    [props.data]
  );


  const getColumnSearchProps = (dataIndex, shy) => ({
    filterDropdown: ({setSelectedKeys, selectedKeys, confirm, clearFilters}) => (
      <div style={{padding: 8}}>
        <Input
          ref={dom => inputRef = dom}
          placeholder={'筛选'}
          value={selectedKeys[0]}
          onChange={e => setSelectedKeys(e.target.value ? [e.target.value] : [])}
          onPressEnter={() => handleSearch(selectedKeys, confirm, dataIndex)}
          style={{marginBottom: 8, display: 'block'}}
        />
        <Space>
          <Button
            type='primary'
            onClick={() => handleSearch(selectedKeys, confirm, dataIndex)}
            icon={<SearchOutlined/>}
            size='small'
            style={{width: 90}}
          >确认</Button>
          <Button onClick={() => handleReset(clearFilters)} size='small' style={{width: 90}}>重置</Button>
        </Space>
      </div>
    ),
    filterIcon: filtered => <FilterOutlined style={{color: filtered ? 'red' : '#1890ff', fontSize: '20px'}}/>,
    onFilter: (value, record) => {
      const res = record[dataIndex]?.toString().toLowerCase().indexOf(value.trim().toLowerCase());
      if (res > -1) {
        return record[dataIndex];
      }
      if (shy) {
        const res2 = record[shy]?.toString().toLowerCase().indexOf(value.trim().toLowerCase());
        if (res2 > -1) {
          return record[shy];
        }
      }
      return '';
    },
    onFilterDropdownVisibleChange: visible => {
      if (visible) {
        setTimeout(() => inputRef.select(), 100);
      }
    }
    // render: text => text
  });

  const handleSearch = (selectedKeys, confirm, dataIndex) => {
    confirm();
    setFilter({
      searchText: selectedKeys[0],
      searchedColumn: dataIndex
    });
  };

  const handleReset = clearFilters => {
    clearFilters();
    setFilter({
      ...filter,
      searchText: ''
    });
  };

  const onSelectChange = (selectedRowKeys, selectedRows) => {
    setSelectedRowKeys(selectedRowKeys);
    setSelectedRow(selectedRows);
  };

  const rowSelection = {
    selectedRowKeys,
    onChange: onSelectChange
  };

  const paginationSetting = {
    defaultPageSize: 10,
    total: props.total,
    pageSizeOptions: [10, 20],
    // hideOnSinglePage: true,
    onChange: (page, pageSize) => {
      props.onPageChange?.(page, pageSize);
    }
  };


  return (
    <>
      <DndProvider backend={HTML5Backend}>
        <Table
          ref={tableRef}
          key={uniqKey}
          scroll={{x: '100%', y: '400px'}}
          dataSource={props.data}
          rowSelection={props.isShowRowSelect ? rowSelection : ''}
          pagination={
            props.isControlled ?
              {
                pageSize: props.pageSize ?? 10,
                current: props.current ?? 1,
                ...paginationSetting
              }
              : paginationSetting
          }
          components={props.isDrag ? components : null}
          onRow={props.isDrag ? (record, index) => ({index, moveRow}) : null}
          {...props}
          columns={columns}
        />
      </DndProvider>
    </>
  );
}

export default forwardRef(condsTable);