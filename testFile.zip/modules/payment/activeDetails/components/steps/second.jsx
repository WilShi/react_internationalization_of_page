import React from 'react';
import {
  Typography, Checkbox
} from '@mcd/portal-components';

import {Conds} from '../conditions';

const {Title} = Typography;

const eventTypeMap = {
  20: '支付活动'
};


function Second(props) {

  const onChange = (e, index) => {
    props.onChange(e.target.checked, index);
  };

  return (
    <div style={{padding: '20px 30px'}}>
      <Title level={4}>活动类型</Title>
      <div style={{margin: '0.5rem 1rem'}}>{eventTypeMap[props?.eventType]}</div>


      <Title level={4}>规则条件</Title>

      {
        props.checkStatus.map((i, index) => {
          switch (i.condition) {
            case '1':
              // return <Conds.Somebody key={i.condition} {...i}>
              //   <Checkbox style={{margin: '8px 0'}}>条件{index+1}：{$t(/*指定人群下单（暂不支持）*/ 'assign_people')}</Checkbox>
              // </Conds.Somebody>;
              return <Conds.Somebody key={i.condition} {...i}>
              <Checkbox
                style={{margin: '8px 0'}}
                checked={i.checked}
                onChange={e => onChange(e, index)}
              >条件{index+1}：{$t(/*指定人群下单（暂不支持）*/ 'assign_people')}</Checkbox>
            </Conds.Somebody>;
            case '2':
              return <Conds.Store key={i.condition} {...i}>
                <Checkbox
                  style={{margin: '8px 0'}}
                  checked={i.checked}
                  onChange={e => onChange(e, index)}
                >条件{index + 1}：指定支付门店</Checkbox>
              </Conds.Store>;
            case '3':
              return <Conds.Channel key={i.condition} {...i}>
                <Checkbox
                  style={{margin: '8px 0'}}
                  checked={i.checked}
                  onChange={e => onChange(e, index)}
                >条件{index + 1}：指定渠道</Checkbox>
              </Conds.Channel>;
            case '4':
              return <Conds.BeType key={i.condition} {...i}>
                <Checkbox
                  style={{margin: '8px 0'}}
                  checked={i.checked}
                  onChange={e => onChange(e, index)}
                >条件{index + 1}：指定业务类型</Checkbox>
              </Conds.BeType>;
            case '5':
              return <Conds.Goods key={i.condition} {...i}>
                <Checkbox
                  style={{margin: '8px 0'}}
                  checked={i.checked}
                  onChange={e => onChange(e, index)}
                >条件{index + 1}：{$t(/*购买指定商品*/ 'assign_product')}</Checkbox>
              </Conds.Goods>;
            case '6':
              return <Conds.Tender key={i.condition} {...i}>
                <Checkbox
                  style={{margin: '8px 0'}}
                  checked={i.checked}
                  onChange={e => onChange(e, index)}
                >条件{index + 1}：指定支付方式</Checkbox>
              </Conds.Tender>;
            case '7':
              return <Conds.TimeQuantum key={i.condition} {...i}>
                <Checkbox
                  style={{margin: '8px 0'}}
                  checked={i.checked}
                  onChange={e => onChange(e, index)}
                >条件{index + 1}：指定时段</Checkbox>
              </Conds.TimeQuantum>;
            case '8':
              return <Conds.Date key={i.condition} {...i}>
                <Checkbox
                  style={{margin: '8px 0'}}
                  checked={i.checked}
                  onChange={e => onChange(e, index)}
                >条件{index + 1}：指定日期</Checkbox>
              </Conds.Date>;
            case '9':
              return <Conds.Amount key={i.condition} {...i}>
                <Checkbox
                  disabled
                  style={{margin: '8px 0'}}
                  checked={i.checked}
                  onChange={e => onChange(e, index)}
                >条件{index + 1}：支付满指定金额</Checkbox>
              </Conds.Amount>;
            case '10':
              return <Conds.Coupon key={i.condition} {...i}>
                <Checkbox
                  style={{margin: '8px 0'}}
                  checked={i.checked}
                  onChange={e => onChange(e, index)}
                >条件{index + 1}：{$t(/*订单使用指定优惠券*/ 'assign_coupon')}</Checkbox>
              </Conds.Coupon>;
            case '11':
              return <Conds.EquityCard key={i.condition} {...i}>
                <Checkbox
                  style={{margin: '8px 0'}}
                  checked={i.checked}
                  onChange={e => onChange(e, index)}
                >条件{index + 1}：{$t(/*订单使用指定权益卡*/ 'assign_card')}</Checkbox>
              </Conds.EquityCard>;
          }
        })
      }
    </div>
  );
}

export default Second;