import React, {useState, useRef, useImperativeHandle, forwardRef, useEffect,} from 'react';

import { Row, Col, DatePicker, Checkbox, InputNumber, Divider, message, Input, Radio } from '@mcd/portal-components';
import moment from 'moment';
import {Rewards} from '../../activityReward'

import './index.less'
import Api from '@/api/point/index';

const {RangePicker} = DatePicker
const dateFormat = 'YYYY-MM-DD'
const eventTypeMap = {
  20: '支付活动'
};

function Third(props, ref) {
  // console.log('props', props)
  const getUser = JSON.parse(localStorage.getItem("USER_INFO"));// 获取登录名账号信息
  const pointRef = useRef()
  const couponRef = useRef()
  const equityRef = useRef()
  const goodsTagRef = useRef()
  const [ruleCoupon, setRuleCoupon] = useState(null)
  const [ruleCard, setRuleCard] = useState(null)
  const [personTime, setPersonTime] = useState([])
  const [userTime, setUserTime] = useState([])
  const [initFrequency, setInitFrequency] = useState({})
  const [limitQty, setLimitQty] = useState({
    1: '',
    2: '',
    3: '',
    4: '',
    5: '',
    6: '',
    7: '',
    8: ''
  })
  const [rewardsChecked, setRewardsChecked] = useState({
    'coupon': false,
    'equity': false,
    'point': false,
    'goodstag': false
  })
  const [params, setParams] = useState({
    levelNo: '',
    operationUser: getUser.nickName,
    pointRuleId: '',
    startTime: '', // 活动时间-开始时间
    endTime: '', // 活动时间-结束时间
    activityRestrictionsList: [], // 活动频次,
    paymentPriority: {}, // 优先级
  })
  const personTimeList = [{
    type: '1', text: '设置活动最大参与人次'
  },
    {
      type: '2', text: '设置每天最大参与人次'
    },
    {
      type: '3', text: '设置每周最大参与人次'
    },
    {
      type: '4', text: '设置每月最大参与人次'
    }]

  const userTimeList = [{
    type: '5', text: '同一用户最大参与次数'
  },
    {
      type: '6', text: '同一用户每日参与次数'
    },
    {
      type: '7', text: '同一用户每周参与次数'
    },
    {
      type: '8', text: '同一用户每月参与次数'
    }]

  useEffect(() => {
    // 初始化数据
    let userTimeTep = []
    let personTimeTep = []
    let limitQtyTep = {}
    props?.reviewInfo?.activityFrequencyList?.forEach(item => {
      if (item.type >= 1 && item.type <= 4) {
        personTimeTep.push(item.type + '')
      } else {
        userTimeTep.push(item.type + '')
      }
      limitQtyTep[item.type] = item.limitQty
    })
    setInitFrequency(limitQtyTep)
    setLimitQty({...limitQtyTep})
    let startTimeTep = props?.reviewInfo?.pointRule?.startTime ? moment(props?.reviewInfo?.pointRule?.startTime).format('YYYY-MM-DD HH:mm:ss') : ''
    let endTimeTep = props?.reviewInfo?.pointRule?.endTime ? moment(props?.reviewInfo?.pointRule?.endTime).format('YYYY-MM-DD HH:mm:ss') : ''
    setPersonTime(personTimeTep)
    setUserTime(userTimeTep)
    setRewardsChecked({
      'coupon': props?.reviewInfo?.ruleCoupon ? true : false,
      'equity': props?.reviewInfo?.ruleCard ? true : false,
      'point': props?.reviewInfo?.ruleExpireType || props?.reviewInfo?.ruleGrantType ? true : false,
      'goodstag': props?.reviewInfo?.paymentDiscount ? true : false
    })

    setParams({
      ...{
        startTime: startTimeTep,
        endTime: endTimeTep,
        levelNo: props?.reviewInfo?.pointRule?.levelNo,
        pointRuleId: props?.reviewInfo?.pointRule?.pointRuleId,
        paymentPriority: props?.reviewInfo?.paymentPriority || {
          discountAmount: 0,
          type: 1 // 1:金额优惠
        }
      }
    })
    setRuleCard(props.reviewInfo.ruleCard)
    setRuleCoupon(props.reviewInfo.ruleCoupon)
  }, [props.reviewInfo])

  // 暴露出去的方法
  useImperativeHandle(ref, () => ({
    onNext: async () => {
      // 活动频次
      let checkLimit = personTime.concat(userTime)
      let activityRestrictionsList = []
      for (let i = 0; i < checkLimit.length; i++) {
        if (!limitQty[checkLimit[i]]) {
          message.warning('请完善人次限制！')
          return
        }
        activityRestrictionsList.push({limitQty: limitQty[checkLimit[i]], type: checkLimit[i], used: 1})
      }
      // 活动奖励
      let pointClass = rewardsChecked['point'] ? pointRef.current.pointClassParams() : {}
      let couponClass = rewardsChecked['coupon'] ? ruleCoupon : {}
      let equityClass = rewardsChecked['equity'] ? ruleCard : {}
      let paymentDiscount = rewardsChecked['goodstag'] ? goodsTagRef.current.paymentDiscount : {}



      let paramsTem = {
        ...params,
        activityRestrictionsList: activityRestrictionsList,
        ...pointClass,
        ruleCoupon: couponClass,
        ruleCard: equityClass,
        paymentDiscount,
        operationUser: getUser.nickName
      }

      // console.log('paramsTem', paramsTem)
      // return

      paramsTem.startTime = paramsTem.startTime ? moment(paramsTem.startTime).format('YYYY-MM-DD') + ' 00:00:00' : ''
      setParams(paramsTem)
      paramsTem.endTime = paramsTem.endTime ? moment(paramsTem.endTime).format('YYYY-MM-DD') + ' 23:59:59' : ''

      // point类必填校验
      if (!validatePointClass(paramsTem)) {
        return
      }

      if (paramsTem.pointRuleGrantType?.type == 1 || paramsTem.pointRuleGrantType?.type == 2) {
        paramsTem.pointProduct = null
      }
      if (paramsTem.pointRuleGrantType?.type == 1 || paramsTem.pointRuleGrantType?.type == 3) {
        paramsTem.pointTender = null
      }

      const data = await Api.createPaymentCommonInfo(paramsTem)
      return data
    },
  }));

  const validatePointClass = (paramsTem) => {
    if (!rewardsChecked['point'] && !rewardsChecked['coupon'] && !rewardsChecked['equity'] && !rewardsChecked['goodstag']) {
      message.warning('至少选择一个活动奖励')
      return false
    }
    if (rewardsChecked['point']) {
      if (!paramsTem.pointRuleGrantType || !paramsTem.pointRuleGrantType.type) {
        message.warning('至少选择一个发放方式')
        return false
      }

      if (!paramsTem.pointRuleGrantType.pointNum || !paramsTem.pointRuleGrantType.pointType || !paramsTem.pointRuleGrantType.pointTypeName) {
        message.warning('请完善发放方式')
        return false
      }
      if (paramsTem.pointRuleGrantType.type == 2 && !paramsTem.pointRuleGrantType.amount) {
        message.warning('请完善发放方式')
        return false
      }

      if (!paramsTem.pointRuleExpireType || !paramsTem.pointRuleExpireType.type) {
        message.warning('至少选择一个过期方式')
        return false
      }

      if ((paramsTem.pointRuleExpireType.type == 1 || paramsTem.pointRuleExpireType.type == 2) && !paramsTem.pointRuleExpireType.num) {
        message.warning('请完善过期方式')
        return false
      }
      if (paramsTem.pointRuleExpireType.type == 3 && !paramsTem.pointRuleExpireType.expireDate) {
        message.warning('请完善过期方式')
        return false
      }

      if (!paramsTem.pointAttribute) {
        message.warning('至少选择一个财务结算方式')
        return false
      }
    }
    if (rewardsChecked['coupon'] && !paramsTem.ruleCoupon?.ruleCouponList.length) {
      message.warning('请选择优惠券')
      return false
    }
    if (rewardsChecked['equity'] && !paramsTem.ruleCard?.ruleCardList.length) {
      message.warning('请选择权益卡')
      return false
    }
    if (rewardsChecked['goodstag'] && !paramsTem.paymentDiscount?.discountCode) {
      message.warning('请填写优惠标记')
      return false
    }
    if (!paramsTem.paymentPriority || !paramsTem.paymentPriority.discountAmount) {
      message.warning('请填写优先级')
      return false
    }
    if (!paramsTem.startTime && !paramsTem.endTime) {
      message.warning('请填写活动时间')
      return false
    }
    return true
  }

  const onChangeActivityTime = (date, dateString) => {
    setParams({...params, ...{startTime: dateString[0], endTime: dateString[1]}})
  }

  const onChangePersonTime = (e) => {
    setPersonTime(e)
  }

  const onChangeUserTime = (e) => {
    setUserTime(e)
  }

  const onChangePersonTimeQty = (type, val) => {
    setLimitQty({...limitQty, ...{[type]: val}})
  }

  const onChangeUserTimeQty = (type, val) => {
    setLimitQty({...limitQty, ...{[type]: val}})
  }

  const onChangeRewards = (e, key) => {
    setRewardsChecked({...rewardsChecked, ...{[key]: e.target.checked}})
  }

  const disabledDate = (current) => {
    return current && ((moment(current).year() < moment().format("YYYY")) || (moment(current).year() > moment().add(2, 'y').format("YYYY")))
  }

  const onSetCoupon = (val) => {
      setRuleCoupon(val)
  }
  const onSetCard = (val) => {
      setRuleCard(val)
  }

  return (
    <div className="third-container">
      <Row>
        <Col span={24}>
          <p className="title">活动奖励</p>
          <div className="ml-20">
            {/*<Rewards.CouponClass ref={couponRef} ruleCoupon={props.reviewInfo.ruleCoupon}*/}
            {/*                     eventType={props.reviewInfo?.pointRule?.eventType} checked={rewardsChecked['coupon']} onSetCoupon={onSetCoupon}>*/}
            {/*  <Checkbox checked={rewardsChecked['coupon']}*/}
            {/*            onChange={(e) => onChangeRewards(e, 'coupon')}>优惠券类</Checkbox>*/}
            {/*</Rewards.CouponClass>*/}
            {/*<Rewards.EquityClass ref={equityRef} ruleCard={props.reviewInfo.ruleCard}*/}
            {/*                     eventType={props.reviewInfo?.pointRule?.eventType} checked={rewardsChecked['equity']} onSetCard={onSetCard}>*/}
            {/*  <Checkbox checked={rewardsChecked['equity']}*/}
            {/*            onChange={(e) => onChangeRewards(e, 'equity')}>权益卡类</Checkbox>*/}
            {/*</Rewards.EquityClass>*/}
            {/*<Rewards.PointClass ref={pointRef} reviewInfo={props.reviewInfo}*/}
            {/*                    eventType={props.reviewInfo?.pointRule?.eventType} checked={rewardsChecked['point']}>*/}
            {/*  <Checkbox checked={rewardsChecked['point']}*/}
            {/*            onChange={(e) => onChangeRewards(e, 'point')}>Point类</Checkbox>*/}
            {/*</Rewards.PointClass>*/}
            <Rewards.GoodsTag ref={goodsTagRef} reviewInfo={props.reviewInfo}
                                eventType={props.reviewInfo?.pointRule?.eventType} checked={rewardsChecked['goodstag']}>
              <Checkbox checked={rewardsChecked['goodstag']}
                        onChange={(e) => onChangeRewards(e, 'goodstag')}>支付优惠标记</Checkbox>
            </Rewards.GoodsTag>
          </div>
        </Col>
      </Row>
      <Divider/>
      <Row>
        <Col span={24}>
          <p className="title"><span className="col-red">* </span>优先级</p>
          <div className="ml-20">
            <Checkbox value={1} checked>
              支付方式存在多条规则时，优先命中优惠金额较大的规则
              <div style={{margin: '10px 0 0 60px'}}>
                优惠金额：
                <InputNumber
                  min={0.01}
                  max={99999.99}
                  style={{ width: 150 }}
                  value={params.paymentPriority.discountAmount || ''}
                  onChange={val => {
                    setParams({
                      ...params,
                      paymentPriority: {
                        ...params.paymentPriority,
                        discountAmount: val?.toString().replace(/^(\d+)\.(\d\d).*$/, "$1.$2")
                      }
                    })
                  }
                } />
                （0.01~99999.99元）
              </div>
            </Checkbox>
          </div>
        </Col>
      </Row>

      <Divider/>
      <Row>
        <Col span={8}>
          <p className="title"><span className="col-red">* </span>活动时间</p>
          <RangePicker className="ml-20" disabledDate={disabledDate} format={dateFormat}
                       value={[params.startTime ? moment(params.startTime, dateFormat) : '', params.endTime ? moment(params.endTime, dateFormat) : '']}
                       onChange={onChangeActivityTime}/>
        </Col>
      </Row>
      <Divider/>
      {/*<Row>*/}
      {/*  <Col span={16}>*/}
      {/*    <p className="title">活动人次限制</p>*/}
      {/*    <Checkbox.Group className="ml-20" value={personTime} onChange={onChangePersonTime}>*/}
      {/*      {personTimeList.map(item => {*/}
      {/*        return (*/}
      {/*          <Row className="mb-10" key={item.type}>*/}
      {/*            <Col>*/}
      {/*              <Checkbox value={item.type} disabled={initFrequency[item.type]}>{item.text}：</Checkbox>*/}
      {/*            </Col>*/}
      {/*            <Col>*/}
      {/*              <InputNumber min={1} max={1000000000} value={limitQty[item.type]}*/}
      {/*                           onChange={(e) => onChangePersonTimeQty(item.type, e)}/>*/}
      {/*            </Col>*/}
      {/*          </Row>*/}
      {/*        )*/}
      {/*      })}*/}
      {/*    </Checkbox.Group>*/}
      {/*  </Col>*/}
      {/*</Row>*/}
      {/*<Divider/>*/}
      {/*<Row>*/}
      {/*  <Col span={16}>*/}
      {/*    <p className="title">用户参与限制</p>*/}
      {/*    <Checkbox.Group className="ml-20" value={userTime} onChange={onChangeUserTime}>*/}
      {/*      {userTimeList.map(item => {*/}
      {/*        return (*/}
      {/*          <Row className="mb-10" key={item.type}>*/}
      {/*            <Col>*/}
      {/*              <Checkbox value={item.type} disabled={initFrequency[item.type]}>{item.text}：</Checkbox>*/}
      {/*            </Col>*/}
      {/*            <Col>*/}
      {/*              <InputNumber min={1} max={1000} value={limitQty[item.type]}*/}
      {/*                           onChange={(e) => onChangeUserTimeQty(item.type, e)}/>*/}
      {/*            </Col>*/}
      {/*          </Row>*/}
      {/*        )*/}
      {/*      })}*/}
      {/*    </Checkbox.Group>*/}
      {/*  </Col>*/}
      {/*</Row>*/}
      {/*<Divider/>*/}
      <Row gutter={30}>
        <Col span={16}>
          <p className="title">发布方式</p>
          <p className="ml-20">审核后自动发布</p>
        </Col>
      </Row>
    </div>
  )
}

export default forwardRef(Third)
