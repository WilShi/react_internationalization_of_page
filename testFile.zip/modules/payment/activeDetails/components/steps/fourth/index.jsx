import React, {useState, useRef, useImperativeHandle, forwardRef, useEffect} from 'react';

import {
  Row,
  Col,
  DatePicker,
  Checkbox,
  InputNumber,
  Divider,
  Descriptions,
  Table,
  Space,
  Modal,
  Spin,
  Button,
  Radio,
  Tag
} from '@mcd/portal-components';

import './index.less';
import CondsTable from '@/modules/refactor/activeDetails/components/condsTable';
import {TagOutlined} from '@ant-design/icons';
import Hoc from '../../conditions/Hoc';
import {getDictionaryLabel} from '@/utils';
import moment from 'moment';
import {getDictionaryListByType} from '@mcd/portal-components/dist/utils/DictUtil';
import Api from '@/api/point/index';
import DescriptionModal from './components/descriptionModal';

const beTypeList = getDictionaryListByType('crm_be_type');
const channelList = getDictionaryListByType('portal_channels');

function Fourth(props) {
  const {reviewInfo} = props;
  const [personTimeData, setPersonTimeData] = useState([]);
  const [userTimeData, setUserTimeData] = useState([]);
  const [title, setTitle] = useState('');
  const [visible, setVisible] = useState(false);
  const [modelData, setModelData] = useState([]);
  const [total, setTotal] = useState([]);
  const [loading, setLoading] = useState(false);
  const [columns, setColumns] = useState([]);
  const [configVisible, setConfigVisible] = useState(false);
  const [currentProductTags, setCurrentProductTags] = useState()
  const [crowdList, setCrowdList] = useState([])
  const [descriptionVisible, setDescriptionVisible] = useState(false)
  const eventTypeMap = {
    20: '支付活动'
  };

  const activityFrequencyMap = {
    1: '活动次数',
    2: '每天参与次数',
    3: '每周参与次数',
    4: '每月参与次数',
    5: '同一用户最大参与次数',
    6: '同一用户每天参与次数',
    7: '同一用户每周参与次数',
    8: '同一用户每月参与次数'
  };

  const grantMap = {
    '10': '麦享会积分',
    '20': '麦咖啡积点',
    '40': '会员日积点',
    '50': '甜品站积点'
  };

  const pointAttributeMap = {
    1: '有偿',
    2: '无偿'
  };

  const typeMap = new Map([
    [1, '包含'],
    [2, '排除']
  ]);
  const CouponRewardMap = new Map([
    [1, '按次发放'],
    [2, '按商品数量发放']
  ]);

  const [pages, setPages] = useState({
    pageNo: 1,
    pageSize: 10
  });

  const personTimeColumns = [
    {
      title: '名称',
      dataIndex: 'name',
      key: 'name',
      render: text => <span>{text}</span>
    },
    {
      title: '最大限制',
      dataIndex: 'limitQty',
      key: 'limitQty',
      render: text => <span>{text}</span>
    }
  ];

  const userTimeColumns = [
    {
      title: '名称',
      dataIndex: 'name',
      key: 'name',
      render: text => <span>{text}：</span>
    },
    {
      title: '次数',
      dataIndex: 'limitQty',
      key: 'limitQty',
      render: text => <span>{text}</span>
    }
  ];

  const columns1 = [
    {
      title: '餐厅编号',
      dataIndex: 'storeCode',
      filter: true
    }
  ];

  const columns2 = [
    {
      title: '商品标签/商品名称',
      dataIndex: 'productName',
      shy: 'labelName',
      filter: true,
      render: (_, row) => {
        if (row.labelId) {
          return <span>
            {row.labelName}
            (标签)
            {/*<TagOutlined style={{ color: '#52c41a' }} />*/}
          </span>;
        }
        return <span>{row.productName}</span>;
      }
    }, {
      title: '商品Code',
      dataIndex: 'productCode',
      shy: 'labelId',
      filter: true,
      render: (_, row) => {
        if (row.labelId) {
          return <span>-</span>;
        }
        return <span>{row.productCode}</span>;
      }
    }, {
      title: '操作',
      key: 'action',
      render: (_, row) => {
        if (row.labelId) {
          return <Space size='middle'>
            <a onClick={() => onViewGoods(row)}>查看商品</a>
          </Space>;
        }
        return <span>-</span>;
      }
    }
  ];

  const columns2Dialog = [
    {
      title: '商品标签/商品名称',
      dataIndex: 'productName',
      render: (_, row) => {
        if (row.labelId) {
          return <span>
            {row.labelName}
            (标签)
            {/*<TagOutlined style={{ color: '#52c41a' }} />*/}
          </span>;
        }
        return <span>{row.productName}</span>;
      }
    }, {
      title: '商品Code',
      dataIndex: 'productCode',
      render: (_, row) => {
        if (row.labelId) {
          return <span>-</span>;
        }
        return <span>{row.productCode}</span>;
      }
    }
  ]


  const columns3 = [
    {
      title: 'Tender Code',
      dataIndex: 'tenderCode',
      filter: true
    }
  ];

  const columns4 = [
    {
      title: '优惠券ID',
      dataIndex: 'couponId',
      filter: true,
      width: '300px'
    }, {
      title: '优惠券名称',
      dataIndex: 'couponName',
      filter: true
    }, {
      title: '促销编号',
      dataIndex: 'promotionId',
      filter: true
    }, {
      title: '操作',
      dataIndex: 'grantType',
      render: r => {
        console.log('rrr', r)
        if (r == 2) {
          return <span>领取</span>
        } else {
          return <span>直塞</span>
        }
      }
    }
  ];

  const columns5 = [
    {
      title: '权益卡ID',
      dataIndex: 'cardId',
      width: '350px',
      filter: true
    }, {
      title: '权益卡名称',
      dataIndex: 'cardName',
      filter: true
    }, {
      title: '操作',
      key: 'action',
      render: (_, row) => <Space size='middle'>
        <a onClick={() => onViewCoupon(row)}>查看优惠券</a>
      </Space>
    }
  ];

  const couponColumns = [
    {
      title: '权益编号',
      dataIndex: 'interestsId'
    }, {
      title: '优惠券ID',
      width: '320px',
      dataIndex: 'refInterestsId'
    }, {
      title: '权益名称',
      dataIndex: 'interestsName'
    }, {
      title: '权益类型',
      width: '120px',
      dataIndex: 'interestsType',
      render: text => <span>{getDictionaryLabel('it_card_interests_type', text)}</span>
    }
  ];

  useEffect(() => {
    init();
  }, []);

  const init = async () => {
    const { data } = await Api.getCrowdList();
    setCrowdList(data)
  };

  useEffect(() => {
    let personList = [];
    let userList = [];
    reviewInfo?.activityFrequencyList?.forEach(item => {
      item.name = activityFrequencyMap[item.type];
      if (item.type > 4) {
        userList.push(item);
      } else {
        personList.push(item);
      }
    });
    setPersonTimeData(personList);
    setUserTimeData(userList);
  }, [props.reviewInfo]);

  const onViewCoupon = async (row) => {
    const {data} = await props.getEquityById({
      cardId: row.cardId,
      pageNo: 1,
      pageSize: 999
    });
    console.log(data);
    setColumns(couponColumns);
    setModelData(data.list);
    setTitle(row.cardName);
    setVisible(true);
  };

  const onViewGoods = (row) => {
    setCurrentProductTags(row.labelName)
    onView(row.labelId);
    setTitle(row.labelName);
    setColumns(columns2Dialog);
    setVisible(true);
  };

  const onView = (productTags) => {
    onQuery({
      pageNo: 1,
      pageSize: 10,
      productTags
    });
    setPages({
      pageNo: 1,
      pageSize: 10
    });
  };
  const onPageChange = (page, pageSize) => {
    onQuery({
      pageNo: page,
      pageSize: pageSize,
      productTags: currentProductTags
    });
    setPages({
      pageNo: page,
      pageSize: pageSize
    });
  };
  const onQuery = async (params) => {
    setLoading(true);
    const {data} = await props.getGoods(params);
    console.log(data);
    const handleData = data.productList?.map(i => {
      return {
        productName: i.productNameCn,
        productCode: i.productCode
      };
    });

    setModelData(handleData);
    setTotal(data.total);
    setLoading(false);
  };


  const showGoodsModel = () => {
    return <Modal
      title={title}
      centered
      visible={visible}
      onOk={() => setVisible(false)}
      onCancel={() => setVisible(false)}
      width={1000}
    >
      <Spin spinning={loading}>
        <CondsTable
          rowKey={row => row.labelId || row.productCode}
          columns={columns}
          data={modelData}
          isShowRowSelect={false}
          total={total}
          onPageChange={onPageChange}
        >
        </CondsTable>
      </Spin>
    </Modal>;
  };

  const showConfigModel = () => {
    return <Modal
      title={'自定义配置'}
      centered
      visible={configVisible}
      onOk={() => setConfigVisible(false)}
      onCancel={() => setConfigVisible(false)}
      width={1000}
    >
      <Radio
        checked>{reviewInfo?.pointProduct ? typeMap.get(reviewInfo?.pointProduct?.type) : typeMap.get(reviewInfo?.pointTender?.type)}</Radio>
      <CondsTable
        rowKey={row => reviewInfo?.pointProduct ? row.productCode : row.tenderCode}
        columns={reviewInfo?.pointProduct ? columns2 : columns3}
        data={reviewInfo?.pointProduct ? reviewInfo?.pointProduct?.productList : reviewInfo?.pointTender?.tenderList}
        isShowRowSelect={false}
        total={reviewInfo?.pointProduct ? reviewInfo?.pointProduct?.productList?.length : reviewInfo?.pointTender?.tenderList?.length}
        // onPageChange={onPageChange}
      >
      </CondsTable>
    </Modal>;
  };

  const renderGrantType = (type) => {
    if (type == 1) {
      return (
        <span>每次发放{reviewInfo?.ruleGrantType?.pointNum}个</span>
      );
    } else if (type == 2) {
      return (
        <span>按每支付{reviewInfo?.ruleGrantType?.amount}元发放{reviewInfo?.ruleGrantType?.pointNum}个</span>
      );
    } else {
      return (
        <span>按每个商品发放{reviewInfo?.ruleGrantType?.pointNum}个</span>
      );
    }
  };

  const renderExpireType = (type) => {
    if (type == 1) {
      return (
        <span>按月过期，在T+{reviewInfo?.ruleExpireType?.num}个自然月的月底过期</span>
      );
    } else if (type == 2) {
      return (
        <span>按天过期，在T+{reviewInfo?.ruleExpireType?.num}个自然日的24点过期</span>
      );
    } else if (type == 3) {
      return (
        <span>按固定日期，在{moment(reviewInfo?.ruleExpireType?.expireDate).format('YYYY-MM-DD')}的24点过期</span>
      );
    } else {
      return (
        <span>不过期</span>
      );
    }
  };

  const StatusShow = (props) => {
    const {type} = props
    if (type == 1) {
      return <Tag color="#008000">{typeMap.get(type)}</Tag>
    }
    if (type == 2) {
      return <Tag color="#ff0000">{typeMap.get(type)}</Tag>
    }
    return <></>
  }

  return (
    <div className='fourth-container'>
      <Descriptions title='基本信息' layout='vertical' column={3}>
        <Descriptions.Item label='事件类型'>{eventTypeMap[reviewInfo?.pointRule?.eventType]}</Descriptions.Item>
        <Descriptions.Item label='活动ID'>{reviewInfo?.pointRule?.pointRuleId}</Descriptions.Item>
        <Descriptions.Item
          label='审核状态'>{getDictionaryLabel('review_status_type', reviewInfo?.pointRule?.verificationStatus)}</Descriptions.Item>
        <Descriptions.Item label='活动名称'>{reviewInfo?.pointRule?.title}</Descriptions.Item>
        <Descriptions.Item label='活动版本'>V{reviewInfo?.pointRule?.levelNo}</Descriptions.Item>
        <Descriptions.Item
          label='活动状态'>{getDictionaryLabel('member_active_status_type', reviewInfo?.pointRule?.status)}</Descriptions.Item>
        <Descriptions.Item label='活动描述'>{reviewInfo?.pointRule?.shortDescription || '-'}</Descriptions.Item>
        <Descriptions.Item label='创建时间'>{reviewInfo?.pointRule?.createdDate ? moment(reviewInfo?.pointRule?.createdDate).format('YYYY-MM-DD HH:mm:ss') : '-'}</Descriptions.Item>
        <Descriptions.Item label='更新时间'>{reviewInfo?.pointRule?.updatedDate ? moment(reviewInfo?.pointRule?.updatedDate).format('YYYY-MM-DD HH:mm:ss') : '-'}</Descriptions.Item>
        <Descriptions.Item label='活动规则'><Button type="link" onClick={() => setDescriptionVisible(true)}>查看活动规则</Button></Descriptions.Item>
      </Descriptions>
      <Divider/>
      <Row>
        <Col span={24}>
          <p className='title'>规则条件</p>
        </Col>
        <Col span={24}>
          {
            props.checkStatus.map((i, index) => {
              if (i.checked) {
                switch (i.condition) {
                  case '1':
                    return <>
                      <div>
                        <span style={{paddingRight: '10px'}}>条件{index + 1}：{$t(/*指定人群下单（暂不支持）*/ 'assign_people')}</span>
                      </div>
                      <div style={{margin: '20px'}}>
                        <div>活动人群包</div>
                        <div>
                          {
                            reviewInfo.crowd.crowdList.map(i => {
                              return <Tag key={i.crowdCode}>
                                {
                                  crowdList[reviewInfo.crowd.type-1]?.filter(j => {
                                    return j.crowdCode === i.crowdCode
                                  })[0]?.crowdName || i.crowdCode
                                }
                              </Tag>
                            })
                          }
                        </div>
                      </div>
                    </>
                  case '2':
                    return <div key={index}>
                      <div>
                        <span style={{paddingRight: '10px'}}>条件{index + 1}：{$t(/*指定餐厅下单*/ 'assign_store')}</span>
                        <StatusShow type={reviewInfo.store?.type}/>
                      </div>
                      <div style={{margin: '20px'}}>
                        <CondsTable
                          rowKey={row => row.storeCode}
                          columns={columns1}
                          data={reviewInfo.store.storeList}
                          total={reviewInfo.store.storeList.length}
                        >
                        </CondsTable>
                      </div>
                    </div>
                  case '3':
                    return <div key={index}>
                      <div>
                        <span style={{paddingRight: '10px'}}>条件{index + 1}：{$t(/*指定渠道下单*/ 'assign_channel')}</span>
                        <StatusShow type={reviewInfo.channel?.type}/>
                      </div>

                      <div style={{margin: '20px'}}>
                        {
                          reviewInfo.channel?.channelList.map(i => getDictionaryLabel('portal_channels', i.channel)).join(',') ?? '-'
                        }
                      </div>
                    </div>
                  case '4':
                    return <div key={index}>
                      <div>
                        <span style={{paddingRight: '10px'}}>条件{index + 1}：{$t(/*订单符合指定BeType*/ 'assign_beType')}</span>
                        <StatusShow type={reviewInfo.beType?.type}/>
                      </div>

                      <div style={{margin: '20px'}}>
                        {
                          reviewInfo.beType?.beTypeList.map(i => getDictionaryLabel('crm_be_type', i.beType)).join(',') ?? '-'
                        }
                      </div>
                    </div>
                  case '5':
                    return <div key={index}>
                      <div>
                        <span style={{paddingRight: '10px'}}>条件{index + 1}：{$t(/*购买指定商品*/ 'assign_product')}</span>
                        <StatusShow type={reviewInfo.product?.type}/>
                      </div>

                      <div style={{margin: '20px'}}>
                        <CondsTable
                          rowKey={row => row.productCode || row.labelId}
                          columns={columns2}
                          data={reviewInfo.product.productList}
                          total={reviewInfo.product.productList.length}
                        >
                        </CondsTable>
                      </div>
                    </div>
                  case '6':
                    return <div key={index}>
                      <div>
                        <span style={{paddingRight: '10px'}}>条件{index + 1}：{$t(/*使用指定Tender*/ 'assign_tender')}</span>
                        <StatusShow type={reviewInfo.tender?.type}/>
                      </div>

                      <div style={{margin: '20px'}}>
                        <CondsTable
                          rowKey={row => row.tenderCode}
                          columns={columns3}
                          data={reviewInfo.tender.tenderList}
                          total={reviewInfo.tender.tenderList.length}
                        >
                        </CondsTable>
                      </div>
                    </div>
                  case '7':
                    return <div key={index}>
                      <div>
                        <span style={{paddingRight: '10px'}}>条件{index + 1}：{$t(/*指定时段内下单*/ 'assign_datePeriod')}</span>
                        <StatusShow type={reviewInfo.datePeriod?.type}/>
                      </div>
                      <div style={{margin: '20px'}}>
                        {
                          reviewInfo.datePeriod?.timeList.map(i => {
                            return <div>{i.startTime}~{i.endTime}</div>;
                          }) ?? '-'
                        }
                      </div>
                    </div>
                  case '8':
                    return <div key={index}>
                      <div>
                        <span
                          style={{paddingRight: '10px'}}>条件{index + 1}：{$t(/*指定日期下单*/ 'assign_intervalPeriod')}</span>
                        <StatusShow type={reviewInfo.intervalPeriod?.type}/>
                      </div>
                      <div style={{margin: '20px'}}>
                        {
                          reviewInfo.intervalPeriod ? <>
                              {
                                reviewInfo.intervalPeriod.weekList.length > 0 &&
                                <div>每周
                                  <span style={{marginLeft: '10px'}}>
                                    {reviewInfo.intervalPeriod?.weekList.map(i => {
                                      return getDictionaryLabel('product_week', i);
                                    }).join(',') ?? '-'}
                                  </span>
                                </div>
                              }

                              {
                                reviewInfo.intervalPeriod.monthList.length > 0 &&
                                <div>每月
                                  <span style={{marginLeft: '10px'}}>
                                    {reviewInfo.intervalPeriod?.monthList.map(i => {
                                      return getDictionaryLabel('point-mouth-frequency', i);
                                    }).join(',') ?? '-'}
                                  </span>
                                </div>
                              }

                              {
                                reviewInfo.intervalPeriod.dateList.length > 0 &&
                                <div>每年
                                  <span style={{marginLeft: '10px'}}>
                                    {reviewInfo.intervalPeriod?.dateList.join(', ') ?? '-'}
                                  </span>
                                </div>
                              }
                            </>
                            : <>-</>
                        }

                      </div>
                    </div>
                  case '9':
                    return <div key={index}>
                      <div>
                        <span style={{paddingRight: '10px'}}>条件{index + 1}：{$t(/*订单支付满指定金额*/ 'assign_amount')}</span>
                        <StatusShow type={reviewInfo.amount?.type}/>
                      </div>
                      <div style={{margin: '20px'}}>
                        {
                          reviewInfo.amount ? <>{reviewInfo.amount.minAmount.toFixed(2)}
                            {`<=支付金额<=`}
                            {reviewInfo.amount.maxAmount.toFixed(2)}</> : '-'
                        }
                      </div>
                    </div>
                  case '10':
                    return <div key={index}>
                      <div>
                        <span style={{paddingRight: '10px'}}>条件{index + 1}：{$t(/*订单使用指定优惠券*/ 'assign_coupon')}</span>
                        <StatusShow type={reviewInfo.coupon?.type}/>
                      </div>

                      <div style={{margin: '20px'}}>
                        <CondsTable
                          rowKey={row => row.couponId}
                          columns={columns4}
                          data={reviewInfo.coupon.couponList}
                          total={reviewInfo.coupon.couponList.length}
                        >
                        </CondsTable>
                      </div>
                    </div>
                  case '11':
                    return <div key={index}>
                      <div>
                        <span style={{paddingRight: '10px'}}>条件{index + 1}：{$t(/*订单使用指定权益卡*/ 'assign_card')}</span>
                        <StatusShow type={reviewInfo.card?.type}/>
                      </div>

                      <div style={{margin: '20px'}}>
                        <CondsTable
                          rowKey={row => row.cardId}
                          columns={columns5}
                          data={reviewInfo.card.cardList}
                          total={reviewInfo.card.cardList.length}
                        >
                        </CondsTable>
                      </div>
                    </div>
                }


              }
            })
          }
        </Col>

      </Row>
      <Divider/>
      <Row>
        <Col span={24}>
          <p className='title'>奖励内容</p>
          {
            reviewInfo.ruleCoupon?.type &&
            <div>
              <p>
                优惠券类：{CouponRewardMap.get(reviewInfo.ruleCoupon?.type)}
                {reviewInfo.ruleCoupon?.regularGoods == 2 ? '(非正价商品不计算)' : ''}
              </p>
              {
                reviewInfo.ruleCoupon?.type ?
                  <CondsTable
                    className='m20'
                    rowKey={row => row.couponId}
                    columns={columns4}
                    data={reviewInfo.ruleCoupon.ruleCouponList}
                    total={reviewInfo.ruleCoupon.ruleCouponList.length}
                  >
                  </CondsTable> : <span className='m20'>-</span>
              }
            </div>
          }

          {
            reviewInfo.ruleCard?.type &&
            <div>
              <p>
                权益卡类：{CouponRewardMap.get(reviewInfo.ruleCard?.type)}
                {reviewInfo.ruleCard?.regularGoods == 2 ? ' (非正价商品不计算) ' : ''}
              </p>
              {
                reviewInfo.ruleCard?.type ?
                  <CondsTable
                    className='m20'
                    rowKey={row => row.cardId}
                    columns={columns5}
                    data={reviewInfo.ruleCard.ruleCardList}
                    total={reviewInfo.ruleCard.ruleCardList.length}
                  >
                  </CondsTable> : <span className='m20'>-</span>
              }
            </div>
          }

          {
            (reviewInfo?.ruleExpireType || reviewInfo?.ruleGrantType) &&
            <div>
              <p>point类：</p>
              <div className='m20'>
                <div>发放内容：{grantMap[reviewInfo?.ruleGrantType?.pointType]}</div>
                <div>
                  <span>发放方式：</span>
                  {renderGrantType(reviewInfo?.ruleGrantType?.type)}
                  {(reviewInfo?.pointProduct || reviewInfo?.pointTender) &&
                  <Button type="link" className='ml-20' onClick={() => setConfigVisible(true)}>自定义配置信息</Button>}
                </div>
                <div>
                  <span>过期方式：</span>
                  {renderExpireType(reviewInfo?.ruleExpireType?.type)}
                </div>
                <div>结算方式：{pointAttributeMap[reviewInfo?.pointRuleAction?.pointAttribute]}</div>
              </div>
            </div>
          }

          {
            reviewInfo?.paymentDiscount &&
            <div>
              <p>优惠标记：</p>
              <div className='m20'>
                <div>
                  <span style={{display: 'inline-block',width: '100px'}}>优惠标记：</span>
                  {reviewInfo?.paymentDiscount?.discountCode}
                </div>
                <div>
                  <span style={{display: 'inline-block',width: '100px'}}>C端中文文案：</span>
                  {reviewInfo?.paymentDiscount?.discountMsg}
                </div>
                <div>
                  <span style={{display: 'inline-block',width: '100px'}}>C端英文文案：</span>
                  {reviewInfo?.paymentDiscount?.discountMsgEn}
                  
                </div>
              </div>
            </div>
          }
        </Col>
      </Row>
      <Divider/>

      <Row>
        <Col span={16}>
          <p className='title'>优先级</p>
          <p className='ml-20'>优惠金额：{reviewInfo.paymentPriority?.discountAmount ?? '-'}</p>
        </Col>
      </Row>

      <Divider/>
      <Row>
        <Col span={16}>
          <p className='title'>活动时间</p>
          <p
            className='ml-20'>{reviewInfo?.pointRule?.startTime ? moment(reviewInfo?.pointRule?.startTime).format('YYYY年MM月DD日') : ''}~{reviewInfo?.pointRule?.endTime ? moment(reviewInfo?.pointRule?.endTime).format('YYYY年MM月DD日') : ''}</p>
        </Col>
      </Row>
      <Divider/>
      {/*<Row>*/}
      {/*  <Col span={8}>*/}
      {/*    <p className='title'>活动人次限制</p>*/}
      {/*    <Table bordered className='ml-20' columns={personTimeColumns} dataSource={personTimeData}/>*/}
      {/*  </Col>*/}
      {/*</Row>*/}
      {/*<Divider/>*/}
      {/*<Row>*/}
      {/*  <Col span={8}>*/}
      {/*    <p className='title'>用户参与限制</p>*/}
      {/*    <Table bordered className='ml-20' columns={userTimeColumns} dataSource={userTimeData}/>*/}
      {/*  </Col>*/}
      {/*</Row>*/}
      {/*<Divider/>*/}
      <Row>
        <Col span={16}>
          <p className='title'>发布方式</p>
          <p className='ml-20'>审核后自动发布</p>
        </Col>
      </Row>

      {visible && showGoodsModel()}
      {configVisible && showConfigModel()}
      {descriptionVisible && <DescriptionModal visible={descriptionVisible} data={reviewInfo?.pointRule?.description} onClose={() => setDescriptionVisible(false)}></DescriptionModal>}

    </div>
  );
}

export default Hoc(Fourth);
