import React from 'react';
import { Button, Modal, Descriptions } from '@mcd/portal-components';

const descriptionModal = (props) => {
  
  return (
    <Modal
      title={'活动规则'}
      visible={props.visible}
      onCancel={() => props.onClose()}
      width="40%"
      footer={[
        <Button key="close" onClick={() => props.onClose()}>{$t(/*关闭*/'crm_close')}</Button>
      ]}>
      <Descriptions layout='vertical' column={1}>
        <Descriptions.Item >{props.data}</Descriptions.Item>
      </Descriptions>
  </Modal>
  );
};

export default descriptionModal;
