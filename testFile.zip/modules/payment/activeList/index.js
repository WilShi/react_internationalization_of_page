import React, { useState, useRef, useEffect } from 'react';
import {
  Input,
  Form,
  Row,
  Col,
  Table,
  Button,
  DictSelect,
  Tooltip,
  TableFilter,
  Modal,
  Popconfirm,
  Radio
} from '@mcd/portal-components';

import ClickLink from '@/modules/components/click';
import VerticalLine from '@/modules/components/verticalLine';
import { getDictionaryLabel } from '@/utils';
import { getTableHeight } from '@mcd/portal-components/dist/utils/table';
import GenColumnsUtil from '@/utils/genColumnsUtil';
import moment from 'moment'
import { checkMyPermission } from '@mcd/portal-components/dist/utils/common';

import Api from '@/api/point/index';
import { message, Select } from 'antd';
import { useDidRecover } from 'react-router-cache-route'


const { TextArea } = Input
const { Option } = Select

function ActiveList (props) {
  const formRef = useRef()
  const getUser = JSON.parse(localStorage.getItem("USER_INFO"));// 获取登录名账号信息
  const [queryModel, setQueryModel] = useState({
    current: 1,
    pageSize: 50,
    total: 0
  })
  const [data, setData] = useState([])
  const [columns, setColumns] = useState([])

  const [copyVisible, setCopyVisible] = useState(false) // 复制弹框
  const [curOpRow, setCurOpRow] = useState({}) // 当前操作行
  const [title, setTitle] = useState('') // 活动名称

  const [auditVisible, setAuditVisible] = useState(false) // 审核弹框
  const [status, setStatus] = useState(1) // 审核状态
  const [description, setDescription] = useState('') // 驳回理由

  const activityStatusEum = [
    { key: 1, value: '待发布' },
    { key: 2, value: '发布中' },
    { key: 3, value: '发布失败' },
    { key: 4, value: '待执行' },
    { key: 5, value: '执行中' },
    { key: 6, value: '执行完成' },
    { key: 7, value: '作废' },
    { key: 8, value: '禁用' }
  ]

  const pointListColumns = [
    {
      title: '活动ID',
      // i18n: 'member_activity_id',
      dataIndex: 'pointRuleId',
      key: 'pointRuleId',
      width: 120,
    },
    {
      title: '活动名称',
      // i18n: 'member_activity_name',
      dataIndex: 'title',
      ellipsis: true,
      key: 'title',
      function: 'activeNameRender',
    },
    {
      title: '活动类型',
      // i18n: 'active_type',
      dataIndex: 'eventType',
      ellipsis: true,
      key: 'eventType',
      function: 'activeTypeRender',
    },
    {
      title: '开始日期-结束日期',
      // i18n: 'member_active_start_time/member_active_end_time',
      dataIndex: 'startEndTime',
      key: 'startEndTime',
      width: 200,
      ellipsis: true,
      function: 'startEndTimeRender',
    },
    // {
    //   title: '累计参与人次',
    //   // i18n: 'member_activity_id',
    //   dataIndex: 'cumulativeCount',
    //   key: 'cumulativeCount',
    //   render: text => <span>{text == null ? '-' : text}</span>
    // },
    {
      title: '活动状态',
      // i18n: 'member_active_status',
      dataIndex: 'status',
      key: 'status',
      ellipsis: true,
      function: 'activeStatusRender',
    },
    {
      title: '活动版本',
      // i18n: 'member_active_status',
      dataIndex: 'levelNo',
      key: 'levelNo',
      render: text => <span>V{text}</span>
    },
    {
      title: '审核状态',
      // i18n: 'review_status',
      dataIndex: 'verificationStatus',
      key: 'verificationStatus',
      ellipsis: true,
      function: 'verificationStatusRender',
    },
    {
      title: '创建人',
      dataIndex: 'createdUser',
      key: 'createdUser',
      render: text => <span>{text}</span>
    },
    {
      title: '操作',
      width: 260,
      i18n: 'opertaion',
      dataIndex: 'operation',
      key: 'operation',
      function: 'operationRender',
    },
  ];
  const filterOptions = GenColumnsUtil.genFilterOptions(pointListColumns)
  const [columnsIndex, setColumnsIndex] = useState(GenColumnsUtil.genColumnsIndex(pointListColumns))
  const initColumns = (columns) => {
    return GenColumnsUtil.genColumns([...columns], {
      activeNameRender: activeNameRender,
      activeTypeRender: activeTypeRender,
      startEndTimeRender: startEndTimeRender,
      activeStatusRender: activeStatusRender,
      verificationStatusRender: verificationStatusRender,
      operationRender: operationRender,
    });
  };

  useEffect(() => {
    onFinish()
  }, [])

  useEffect(() => {
    return () => {
      sessionStorage.removeItem('pointCheckedColumns')
    }
  }, [])

  useDidRecover(() => {
    onFinish()
  })

  /**
   * 表头渲染函数 活动名称
   * @param {*} text
   * @param {*} record
   */
  const activeNameRender = (text, record) => {
    if (record.verificationStatus === 0) {
      return <Tooltip title={text}>{text}</Tooltip>;
    } else {
      return (
        <Tooltip title={text}>
          <a onClick={() => toDetailPage(record, 'check')}>
            {text}
          </a>
        </Tooltip>
      );
    }
  }

  /**
   * 表头渲染函数 活动类型
   * @param {*} text
   * @param {*} record
   */
  const activeTypeRender = (text, record) => {
    const activeType = getDictionaryLabel('activity_type', text);
    return activeType ?? '-';
  };

  /**
   * 表头渲染函数 开始日期-结束日期
   * @param {*} text
   * @param {*} record
   */
  const startEndTimeRender = (text, record) => {
    return (
      <div>
        <span>{record.startTime ? moment(record.startTime).format('YYYY-MM-DD') + ' ~ ' : '-'}</span>
        <span>{record.endTime ? moment(record.endTime).format('YYYY-MM-DD') : '-'}</span>
      </div>
    );
  }

  /**
   * 表头渲染函数 活动状态
   * @param {*} text
   * @param {*} record
   */
  const activeStatusRender = (text, record) => {
    let activeStatus = '-'
    activityStatusEum.forEach(item => {
      if (text && item.key == text) {
        activeStatus = item.value
      }
    })
    return record.verificationStatus == 2 ? activeStatus : '-';
  }

  /**
   * 表头渲染函数 审核状态
   * @param {*} text
   * @param {*} record
   */
  const verificationStatusRender = (text, record) => {
    const auditStatus = getDictionaryLabel('review_status_type', text);
    return auditStatus ?? '-';
  }

  /**
   * 表头渲染函数 操作
   * @param {*} text
   * @param {*} record
   */
  const operationRender = (text, record) => {
    // 审核状态    活动状态      可执行的操作
    // 草稿 	      /	        编辑、复制、删除
    // 待审核	      /	        复制、查看、审核
    // 审核驳回	    /	         编辑、复制、删除
    // 审核通过	  待发布	    复制、查看、更新、发布、作废
    // 审核通过	  发布中	    复制、查看、更新、发布、作废
    // 审核通过	  待执行	    复制、查看、更新、作废
    // 审核通过	  执行中	    复制、查看、更新、作废
    // 审核通过	  执行完成	  复制、查看、更新
    // 审核通过	  已作废	    复制、查看、更新
    // verificationStatus 审核状态 0：草稿 1：待审核 2：通过 3：拒绝
    // status  1待发布 2发布中 3发布失败 4待执行 5执行中 6执行完成 7作废 8作废
    if (record.verificationStatus == 0 || record.verificationStatus == 3) {
      return (
        <div>
          {checkMyPermission('loyaltyManage:activeList:edit') &&
            <ClickLink onClick={() => toDetailPage(record, 'edit')}>
              {$t(/*编辑*/ 'portal_edit')}
            </ClickLink>}
          <VerticalLine />
          {checkMyPermission('loyaltyManage:activeList:copy') && <ClickLink onClick={() => toCopyActivity(record)}>
            复制
          </ClickLink>}
          <VerticalLine />
          <Popconfirm
            title="删除后无法恢复，你还要继续吗？"
            onConfirm={() => toDelete(record)}
            okText="继续"
            cancelText="取消">
            {checkMyPermission('loyaltyManage:activeList:delete') && <ClickLink>删除</ClickLink>}
          </Popconfirm>
        </div>
      )
    }
    if (record.verificationStatus == 1) {
      return (
        <div>
          {checkMyPermission('loyaltyManage:activeList:copy') && <ClickLink onClick={() => toCopyActivity(record)}>
            复制
          </ClickLink>}
          <VerticalLine />
          {checkMyPermission('loyaltyManage:activeList:check') &&
            <ClickLink onClick={() => toDetailPage(record, 'check')}>
              {$t(/*查看*/ 'portal_check')}
            </ClickLink>}
          <VerticalLine />
          {checkMyPermission('loyaltyManage:activeList:audit') && <ClickLink onClick={() => toAudit(record)}>
            {$t(/*审核*/ 'audit')}
          </ClickLink>}
        </div>
      )
    }
    if (record.verificationStatus == 2 && [1, 2].indexOf(record.status) > -1) {
      return (
        <div>
          {checkMyPermission('loyaltyManage:activeList:copy') && <ClickLink onClick={() => toCopyActivity(record)}>
            复制
          </ClickLink>}
          <VerticalLine />
          {checkMyPermission('loyaltyManage:activeList:check') &&
            <ClickLink onClick={() => toDetailPage(record, 'check')}>
              {$t(/*查看*/ 'portal_check')}
            </ClickLink>}
          <VerticalLine />
          {checkMyPermission('loyaltyManage:activeList:update') && <ClickLink onClick={() => toUpdate(record)}>
            更新
          </ClickLink>}
          <VerticalLine />
          {checkMyPermission('loyaltyManage:activeList:publish') && <ClickLink onClick={() => toPublish(record)}>
            {$t(/*发布*/ 'publish')}
          </ClickLink>}
          <VerticalLine />
          <Popconfirm
            title="作废后无法恢复，你还要继续吗？"
            onConfirm={() => toVoid(record)}
            okText="继续"
            cancelText="取消">
            {checkMyPermission('loyaltyManage:activeList:cancel') && record.status == 2 ?
              <ClickLink> {$t(/*作废*/ 'invalid')}</ClickLink> : ''}
          </Popconfirm>
        </div>
      )
    }
    if (record.verificationStatus == 2 && [4, 5].indexOf(record.status) > -1) {
      return (
        <div>
          {checkMyPermission('loyaltyManage:activeList:copy') && <ClickLink onClick={() => toCopyActivity(record)}>
            复制
          </ClickLink>}
          <VerticalLine />
          {checkMyPermission('loyaltyManage:activeList:check') &&
            <ClickLink onClick={() => toDetailPage(record, 'check')}>
              {$t(/*查看*/ 'portal_check')}
            </ClickLink>}
          <VerticalLine />
          {checkMyPermission('loyaltyManage:activeList:update') && <ClickLink onClick={() => toUpdate(record)}>
            更新
          </ClickLink>}
          <VerticalLine />
          <Popconfirm
            title="作废后无法恢复，你还要继续吗？"
            onConfirm={() => toVoid(record)}
            okText="继续"
            cancelText="取消">
            {checkMyPermission('loyaltyManage:activeList:cancel') && record.status == 5 ?
              <ClickLink> {$t(/*作废*/ 'invalid')}</ClickLink> : ''}
          </Popconfirm>
        </div>
      )
    }
    if (record.verificationStatus == 2 && [6, 7].indexOf(record.status) > -1) {
      return (
        <div>
          {checkMyPermission('loyaltyManage:activeList:copy') && <ClickLink onClick={() => toCopyActivity(record)}>
            复制
          </ClickLink>}
          <VerticalLine />
          {checkMyPermission('loyaltyManage:activeList:check') &&
            <ClickLink onClick={() => toDetailPage(record, 'check')}>
              {$t(/*查看*/ 'portal_check')}
            </ClickLink>}
          <VerticalLine />
          {checkMyPermission('loyaltyManage:activeList:update') && <ClickLink onClick={() => toUpdate(record)}>
            更新
          </ClickLink>}
        </div>
      )
    }
  }



  const openDetailTab = (toPath, name = '支付活动详情') => {
    const params = {
      tabNameZh: name,
      tabNameEn: "payment activity details",
      path: toPath,
    }
    window.EventBus && window.EventBus.emit("setAppTab", null, params)
  }

  /**
   * 进入活动流程页
   */
  const toDetailPage = (record, operation) => {
    switch (operation) {
      case 'edit':
        openDetailTab(`/point/paymentActiveDetails/${record.pointRuleId}/${record.levelNo}`, '编辑支付活动')
        break;
      case 'create':
        openDetailTab(`/point/paymentActiveDetails`, '创建支付活动')
        break;
      case 'check':
        sessionStorage.setItem('currentStep', 3);
        openDetailTab(`/point/paymentActiveDetails/${record.pointRuleId}/${record.levelNo}/true`, '支付活动详情')
        break;
    }
  }

  /**
   * 复制活动按钮
   */
  const toCopyActivity = async (record) => {
    setCopyVisible(true)
    setTitle(record.title)
    setCurOpRow(record)
  }

  /**
   * 作废
   */
  const toVoid = async (record) => {
    const params = {
      activityId: record.pointRuleId,
      levelNo: record.levelNo,
      operationUser: getUser.nickName
    }
    await Api.cancelPaymentActivity(params)
    onFinish()
  }

  /**
   * 删除
   */
  const toDelete = async (record) => {
    const params = {
      activityId: record.pointRuleId,
      levelNo: record.levelNo,
      operationUser: getUser.nickName
    }
    await Api.delPaymentActivity(params)
    onFinish()
  }

  /**
   * 更新
   */
  const toUpdate = async (record) => {
    const params = {
      activityId: record.pointRuleId,
      levelNo: record.levelNo,
      operationUser: getUser.nickName
    }
    const data = await Api.updatePaymentActivity(params)
    if (data.code == 'SUCCESS') {
      message.success('已为您生成一个新版本的活动，新活动发布后老活动自动作废。')
    }
    onFinish()
  }

  /**
   * 审核
   * @param {} record
   */
  const toAudit = (record) => {
    setAuditVisible(true)
    setCurOpRow(record)
  }

  const onAudit = async () => {
    let params = {
      status: status,
      description: description,
      activityId: curOpRow.pointRuleId,
      levelNo: curOpRow.levelNo,
      operationUser: getUser.nickName
    }
    await Api.doPaymentAudit(params)
    setAuditVisible(false)
    onFinish()
  }

  /**
   * 发布
   */
  const toPublish = async (record) => {
    const params = {
      activityId: record.pointRuleId,
      levelNo: record.levelNo,
      operationUser: getUser.nickName
    }
    await Api.publishPaymentActivity(params)
    onFinish()
  }

  const onFinish = () => {
    let columnsIndexProp = [].concat(columnsIndex)
    let localCheckedColumns = JSON.parse(sessionStorage.getItem('pointCheckedColumns'))
    if (!localCheckedColumns) {
      sessionStorage.setItem('pointCheckedColumns', JSON.stringify(columnsIndex))
    } else {
      columnsIndexProp = localCheckedColumns
    }
    let tmpColumns = pointListColumns.filter(
      (item) => columnsIndexProp.findIndex((c) => c == item.dataIndex) != -1
    );
    setColumnsIndex(columnsIndexProp)
    setColumns(initColumns([...tmpColumns]));
    getActiveList()
  }

  /**
   * 获取活动列表
   * @param {*} pageNo
   * @param {*} pageSize
   */
  const getActiveList = async (pageNo = queryModel.current, pageSize = queryModel.pageSize) => {
    let params = formRef.current.getFieldsValue()
    // params.eventTypelist =
    //   params.eventType && params.eventType.length > 0
    //     ? params.eventType.join(',')
    //     : params.eventTypelist;
    params.activityTypeList =
      params.activityTypeList && params.activityTypeList.length > 0
        ? params.activityTypeList.join(',')
        : params.activityTypeList;
    params.activityStatusList =
      params.activityStatusList && params.activityStatusList
        ? params.activityStatusList.join(',')
        : params.activityStatusList;
    params.auditStatusList =
      params.auditStatusList && params.auditStatusList
        ? params.auditStatusList.join(',')
        : params.auditStatusList;
    params = { pageNo, pageSize, ...params }
    const { data } = await Api.getPaymentActiveList(params)
    data && data.content && setData(data.content)
    setQueryModel({
      current: data.pageNo,
      pageSize: data.pageSize,
      total: data.total
    })
  }

  /**
   * 重置搜索条件
   */
  const reset = () => {
    formRef.current.resetFields()
  };

  /**
   * 表头过滤器事件
   * @param {*} checkedValue
   */
  const onFilterChange = (checkedValue) => {
    sessionStorage.setItem('pointCheckedColumns', JSON.stringify(checkedValue))
    let columnsProp = initColumns(pointListColumns).filter((it) => {
      return (
        checkedValue.includes(it.dataIndex) || it.dataIndex === 'operation'
      );
    });
    setColumns(columnsProp)
  };

  /**
   * 表头过滤器重置
   */
  const resetColumns = () => {
    setColumns(initColumns(pointListColumns))
  };

  /**
   * 复制活动
   */
  const onCopyActivity = async () => {
    let params = {
      description: curOpRow.description,
      eventType: curOpRow.eventType,
      levelNo: curOpRow.levelNo,
      operationUser: getUser.nickName,
      pointRuleId: curOpRow.pointRuleId,
      shortDescription: curOpRow.shortDescription,
      title: title
    }
    await Api.copyPaymentActivity(params)
    setCopyVisible(false)
    onFinish()
  }

  /**
   * 关闭复制活动弹框
   */
  const onCancel = () => {
    setCopyVisible(false)
  }

  const showAuditModel = () => {
    return (
      <Modal
        title={`${$t(/*会员活动*/'member_active')}${$t(/*审核*/'audit')}`}
        visible={auditVisible}
        onCancel={() => setAuditVisible(false)}
        footer={null}>
        <div style={{ padding: '20px' }}>
          <Radio.Group onChange={(e) => setStatus(e.target.value)} value={status}>
            <Radio value={1}>{$t(/*审核通过*/'approved')}</Radio>
            <Radio value={2}>{$t(/*审核驳回*/'rejected')}</Radio>
          </Radio.Group>
        </div>
        {status == 2 && (
          <>
            <div style={{ padding: '0px 20px 10px 20px' }}>
              <span style={{ fontWeight: 'bold' }}>
                {$t(/*驳回理由*/'rejection_reason')}
                <span style={{ fontWeight: '500', color: 'rgb(204 204 204)' }}>
                  ({$t(/*请输入*/'please_type')}
                  {$t(/*驳回理由*/'rejection_reason')})
                </span>
              </span>
            </div>
            <div style={{ padding: '0px 20px 10px 20px' }}>
              <TextArea
                rows={3}
                onChange={(e) => setDescription(e.target.value)}
              />
            </div>
          </>
        )}
        <div style={{ padding: '20px 20px 10px 20px' }}>
          <Button
            type="primary"
            ghost
            style={{ padding: '0 20px', color: '#1890ff', borderColor: '#1890ff' }}
            onClick={() => setAuditVisible(false)}>
            {$t(/*取消*/'cancel')}
          </Button>
          <Button
            type="primary"
            style={{ marginLeft: '30px', padding: '0 20px' }}
            onClick={onAudit}
          >
            {$t(/*确认*/ 'portal_confirm')}
          </Button>
        </div>
      </Modal>
    );
  };

  return (
    <div className="table-container">
      <Form
        ref={formRef}
        className="search-form"
        onFinish={onFinish}
        layout="vertical"
        size="middle">
        <div className="search-area">
          <Row gutter={30}>
            <Col span={6}>
              <Form.Item
                label={'活动类型'}
                name="activityTypeList">
                <DictSelect
                  type="activity_type"
                  placeholder={`${$t(/*请选择*/ 'please_select')}${$t(
                    /*活动类型*/ 'event_type'
                  )}`}
                  multiple={true}
                />
              </Form.Item>
            </Col>
            <Col span={6}>
              <Form.Item
                label={$t(/*审核状态*/ 'review_status')}
                name="auditStatusList">
                <DictSelect
                  type="review_status_type"
                  placeholder={`${$t(/*请选择*/ 'please_select')}${$t(
                    /*审核状态*/ 'review_status'
                  )}`}
                  multiple={true}
                />
              </Form.Item>
            </Col>
            <Col span={6}>
              <Form.Item
                label={$t(/*会员活动状态*/ 'member_active_status')}
                name="activityStatusList">
                <Select
                  mode="multiple"
                  allowClear
                  style={{ width: '100%' }}
                  placeholder={`${$t(/*请选择*/ 'please_select')}${$t(
                    /*会员活动状态*/ 'member_active_status'
                  )}`}>
                  {
                    activityStatusEum.map(item => {
                      return (
                        <Option key={item.key}>{item.value}</Option>
                      )
                    })
                  }
                </Select>
              </Form.Item>
            </Col>
            <Col span={6}>
              <Form.Item
                label={$t(/*搜索会员活动*/ 'member_active_query')}
                name="activity">
                <Input
                  allowClear
                  placeholder='请输入会员活动ID/会员活动名称'
                />
              </Form.Item>
            </Col>
            <Col span={24}>
              <Button type="primary" onClick={() => getActiveList(1, 50)}>
                {$t('portal_search')}
              </Button>
              <Button onClick={() => reset()}>{$t('portal_reset')}</Button>
            </Col>
          </Row>
        </div>
      </Form>
      <div className="table-top-wrap">
        <div className="table-top">
          {checkMyPermission('loyaltyManage:activeList:create') &&
            <Button type="primary" onClick={() => toDetailPage('', 'create')}>{$t('portal_add')}</Button>}
          <TableFilter
            options={filterOptions}
            checkedValue={columnsIndex}
            onChange={onFilterChange}
            resetColumns={resetColumns}
            tableKey={'order'}
          />
        </div>
        <Table
          rowKey={row => row.pointRuleId + row.levelNo}
          columns={[...columns]}
          dataSource={[...data]}
          scroll={{
            x: '100%',
            y: `calc(100vh - ${getTableHeight('portal-point', 425)}px)`,
          }}
          pagination={{ ...queryModel }}
          onChange={(pagination) => getActiveList(pagination.current, pagination.pageSize)}
        />
      </div>
      <Modal
        title={'复制活动'}
        visible={copyVisible}
        onOk={onCopyActivity}
        onCancel={onCancel}>
        <div>
          <p>活动名称（{title.length}/32）：</p>
          <Input style={{ width: 300, marginTop: 8 }} allowClear placeholder={`${$t(/*请输入*/ 'please_type')}`}
            value={title} onChange={e => setTitle(e.target.value)} />
        </div>
      </Modal>
      {showAuditModel()}
    </div>
  )
}

export default ActiveList;
